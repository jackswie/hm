package com.glasslock.service

import android.app.PendingIntent
import android.graphics.Bitmap
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class LockNotification(
    val key: String,
    val pkg: String,
    val app: String,
    val title: String,
    val text: String,
    val whenMs: Long,
    val icon: Bitmap?,
    val intent: PendingIntent?,
) {
    companion object {
        /** Shown while editing so the notification cards can be styled. */
        val Sample = LockNotification("sample", "sample", "Messages", "Alex", "See you at 7? I booked the table.", 0L, null, null)
    }
}

/** Notifications mirrored from [MediaListenerService] for the lock screen. */
object NotificationRepository {
    private val _items = MutableStateFlow<List<LockNotification>>(emptyList())
    val state: StateFlow<List<LockNotification>> = _items.asStateFlow()

    fun replaceAll(list: List<LockNotification>) { _items.value = list.sortedByDescending { it.whenMs } }

    fun upsert(n: LockNotification) = _items.update { cur -> (cur.filter { it.key != n.key } + n).sortedByDescending { it.whenMs } }

    fun remove(key: String) = _items.update { cur -> cur.filter { it.key != key } }

    /** Swipe-to-dismiss: also clears it from the system shade. */
    fun dismiss(key: String) {
        remove(key)
        MediaListenerService.instance?.cancelNotification(key)
    }
}
