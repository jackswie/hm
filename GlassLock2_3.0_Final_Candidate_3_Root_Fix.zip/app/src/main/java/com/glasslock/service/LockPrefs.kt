package com.glasslock.service

import android.content.Context

/** Tiny flag store the boot receiver can read without DataStore. */
object LockPrefs {
    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences("lock", Context.MODE_PRIVATE)
    fun isEnabled(c: Context) = prefs(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, on: Boolean) = prefs(c).edit().putBoolean("enabled", on).apply()
}
