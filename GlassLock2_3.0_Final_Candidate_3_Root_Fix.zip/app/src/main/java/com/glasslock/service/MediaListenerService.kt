package com.glasslock.service

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.graphics.drawable.toBitmap
import com.glasslock.ui.media.MediaRepository

/**
 * Enabling this service in system settings authorises (1) reading the active media session and
 * (2) mirroring notifications onto the lock screen.
 */
class MediaListenerService : NotificationListenerService() {

    override fun onListenerConnected() {
        instance = this
        MediaRepository.start(this)
        NotificationRepository.replaceAll(activeNotifications.orEmpty().mapNotNull(::convert))
    }

    override fun onListenerDisconnected() {
        if (instance === this) instance = null
        MediaRepository.refresh()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        convert(sbn)?.let(NotificationRepository::upsert)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        NotificationRepository.remove(sbn.key)
    }

    private fun convert(sbn: StatusBarNotification): LockNotification? {
        val n = sbn.notification
        if (sbn.packageName == packageName) return null
        if ((n.flags and (Notification.FLAG_ONGOING_EVENT or Notification.FLAG_GROUP_SUMMARY)) != 0) return null
        if (n.category == Notification.CATEGORY_TRANSPORT) return null
        if (n.visibility == Notification.VISIBILITY_SECRET) return null

        val pm = packageManager
        val app = runCatching { pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString() }
            .getOrDefault(sbn.packageName)
        val extras = n.extras
        var title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        var text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: extras.getCharSequence(Notification.EXTRA_TEXT))
            ?.toString().orEmpty()
        if (n.visibility == Notification.VISIBILITY_PRIVATE) {
            title = app
            text = "Notification"
        }
        if (title.isBlank() && text.isBlank()) return null

        val icon = runCatching { pm.getApplicationIcon(sbn.packageName).toBitmap(96, 96) }.getOrNull()
        return LockNotification(sbn.key, sbn.packageName, app, title, text, sbn.postTime, icon, n.contentIntent)
    }

    companion object {
        @Volatile
        var instance: MediaListenerService? = null
    }
}
