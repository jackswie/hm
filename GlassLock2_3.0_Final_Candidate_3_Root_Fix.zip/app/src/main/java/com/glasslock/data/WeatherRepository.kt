package com.glasslock.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDateTime
import java.time.LocalTime

data class WeatherData(
    val tempC: Int,
    val rainPct: Int,
    val code: Int,
    val sunrise: LocalTime,
    val sunset: LocalTime,
    val place: String,
) {
    val emoji: String
        get() = when (code) {
            0 -> "☀️"; 1, 2 -> "🌤️"; 3 -> "☁️"; 45, 48 -> "🌫️"
            in 51..67, in 80..82 -> "🌧️"; in 71..77, 85, 86 -> "❄️"; in 95..99 -> "⛈️"; else -> "🌡️"
        }
    val condition: String
        get() = when (code) {
            0 -> "Clear"; 1, 2 -> "Mostly Clear"; 3 -> "Cloudy"; 45, 48 -> "Fog"
            in 51..67, in 80..82 -> "Rain"; in 71..77, 85, 86 -> "Snow"; in 95..99 -> "Thunderstorm"; else -> "—"
        }
}

sealed interface WeatherState {
    data object Loading : WeatherState
    data object NeedsLocation : WeatherState
    data object Unavailable : WeatherState
    data class Ready(val data: WeatherData) : WeatherState
}

/** Open-Meteo (no API key) + last known coarse location. Refreshes at most every 30 minutes. */
object WeatherRepository {
    private val _state = MutableStateFlow<WeatherState>(WeatherState.Loading)
    val state: StateFlow<WeatherState> = _state.asStateFlow()
    private var lastFetch = 0L

    suspend fun refresh(context: Context, force: Boolean = false) = withContext(Dispatchers.IO) {
        val fresh = _state.value is WeatherState.Ready && System.currentTimeMillis() - lastFetch < 30 * 60_000L
        if (!force && fresh) return@withContext
        val ctx = context.applicationContext
        if (ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            _state.value = WeatherState.NeedsLocation
            return@withContext
        }
        val loc = lastLocation(ctx)
        if (loc == null) {
            _state.value = WeatherState.Unavailable
            return@withContext
        }
        _state.value = runCatching<WeatherState> { WeatherState.Ready(fetch(ctx, loc)) }
            .getOrDefault(WeatherState.Unavailable)
        if (_state.value is WeatherState.Ready) lastFetch = System.currentTimeMillis()
    }

    private fun lastLocation(ctx: Context): Location? = try {
        val lm = ctx.getSystemService(LocationManager::class.java)
        lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time }
    } catch (_: SecurityException) {
        null
    }

    @Suppress("DEPRECATION")
    private fun fetch(ctx: Context, loc: Location): WeatherData {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}" +
            "&current=temperature_2m,weather_code&daily=sunrise,sunset,precipitation_probability_max" +
            "&timezone=auto&forecast_days=1"
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 8_000
        conn.readTimeout = 8_000
        val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
        conn.disconnect()

        val cur = json.getJSONObject("current")
        val daily = json.getJSONObject("daily")
        val place = runCatching {
            if (Geocoder.isPresent()) {
                Geocoder(ctx).getFromLocation(loc.latitude, loc.longitude, 1)?.firstOrNull()
                    ?.let { it.locality ?: it.subAdminArea }
            } else null
        }.getOrNull() ?: "Current location"

        return WeatherData(
            tempC = Math.round(cur.getDouble("temperature_2m")).toInt(),
            rainPct = daily.getJSONArray("precipitation_probability_max").optInt(0, 0),
            code = cur.getInt("weather_code"),
            sunrise = LocalDateTime.parse(daily.getJSONArray("sunrise").getString(0)).toLocalTime(),
            sunset = LocalDateTime.parse(daily.getJSONArray("sunset").getString(0)).toLocalTime(),
            place = place,
        )
    }
}
