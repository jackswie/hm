package com.glasslock.data.model

import kotlinx.serialization.Serializable
import java.util.UUID

/** Clock height limits, as a fraction of screen height. 55% is the "towering" iPadOS 26 maximum. */
const val CLOCK_MIN_HEIGHT = 0.08f
const val CLOCK_MAX_HEIGHT = 0.55f

@Serializable
enum class GlassMode { LIQUID, SOLID }

@Serializable
enum class GlassAppearance { CLEAR, TINTED }

/** Optical source used by Liquid Glass. REFERENCE falls back to LIVE when no valid image is configured. */
@Serializable
enum class GlassOpticalMode { LIVE, REFERENCE, HYBRID }

@Serializable
enum class NumeralScript(val label: String, val digits: String) {
    WESTERN("0 1 2 3", "0123456789"),
    EASTERN_ARABIC("٠ ١ ٢ ٣", "٠١٢٣٤٥٦٧٨٩"),
    DEVANAGARI("० १ २ ३", "०१२३४५६७८९"),
    BENGALI("০ ১ ২ ৩", "০১২৩৪৫৬৭৮৯"),
}

@Serializable
enum class ClockFontId {
    SF_PRO, ROUNDED, SERIF, SLAB, CONDENSED, STENCIL, RAILS, HANDWRITTEN,
    SF_SOFT, RAILS_ROUNDED, SERIF_SOFT, SLAB_SOFT, ADAPTIVE, ADAPTIVE_SOFT,
}

/**
 * Material description used independently by the clock/text, widgets, media card and notifications.
 *  - LIQUID: [intensity] 0 = ultra-clear refractive glass, 1 = heavy frost.
 *  - SOLID : opaque-ish fill of [solidColor] at [opacity] (10%..100%).
 *  - [tintColor] overrides the auto-sampled wallpaper tint when appearance is TINTED.
 */
@Serializable
data class GlassStyle(
    val mode: GlassMode = GlassMode.LIQUID,
    val intensity: Float = 0.35f,
    val appearance: GlassAppearance = GlassAppearance.CLEAR,
    val tintColor: Int? = null,
    val solidColor: Int = 0xFFFFFFFF.toInt(),
    val opacity: Float = 0.9f,
    /** Strength of the subtle edge highlight; works in both translucent and solid modes. */
    val rimStrength: Float = 1f,
    /** Fine control over optical edge bending; 0 disables lens displacement. */
    val refractionStrength: Float = 1f,
    /** Width of the displaced edge band, normalized to the renderer's safe range. */
    val edgeDisplacement: Float = 1f,
    /** Chromatic separation at the bevel; kept subtle for readability. */
    val dispersionStrength: Float = 1f,
    /** Optional app-private image path used as the reference optical source. */
    val referenceImagePath: String? = null,
    val opticalMode: GlassOpticalMode = GlassOpticalMode.LIVE,
)

@Serializable
data class ClockConfig(
    val font: ClockFontId = ClockFontId.CONDENSED,
    val weight: Int = 400,
    val script: NumeralScript = NumeralScript.WESTERN,
    val heightFraction: Float = 0.38f,
    /** Width of the clock canvas relative to the available hero area; independently stretched from height. */
    val widthFraction: Float = 1f,
    /** Used only by the compact album-player clock to retain its original proportions. */
    val keepAspectRatio: Boolean = false,
    val topFraction: Float = 0.13f,
    val use24Hour: Boolean = true,
    val depthEffect: Boolean = true,
    val style: GlassStyle = GlassStyle(),
)

@Serializable
enum class AlbumArtworkStyle { COVER, VINYL }

@Serializable
enum class AlbumCoverPosition { CENTER, LEFT }

@Serializable
enum class ScenePreset(val label: String, val description: String) {
    BALANCED("Balanced", "A clean everyday lock screen"),
    FOCUS("Focus", "Quieter notifications and a calmer layout"),
    SLEEP("Sleep", "Dim, minimal and low-distraction"),
    CINEMATIC("Cinematic", "Full-depth clock with atmospheric motion"),
}

@Serializable
enum class WallpaperKind(val label: String) {
    PHOTO("Photo"), WEATHER("Weather"), ASTRONOMY("Astronomy"), EMOJI("Emoji"), GRADIENT("Color Gradient")
}

@Serializable
enum class WallpaperFilter(val label: String) {
    NATURAL("Natural"), MONO("B&W"), DUOTONE("Duotone"), WASH("Color Wash")
}

/** [file] is an absolute path in app storage; for kind PHOTO a null file means the built-in demo skyline. */
@Serializable
data class WallpaperConfig(
    val file: String? = null,
    val zoom: Float = 1f,
    val panX: Float = 0f,
    val panY: Float = 0f,
    val kind: WallpaperKind = WallpaperKind.PHOTO,
    val emoji: String = "😀",
    val color1: Int = 0xFF1E3A8A.toInt(),
    val color2: Int = 0xFFEC4899.toInt(),
    val filter: WallpaperFilter = WallpaperFilter.NATURAL,
    val dim: Boolean = false,
    val blur: Boolean = false,
    /** Fit the whole photo and fill the remaining canvas with a blurred copy. */
    val extend: Boolean = false,
    /** Optional low-cost animated ambience layered over procedural wallpaper types. */
    val atmosphereEnabled: Boolean = false,
    val atmosphereIntensity: Float = 0.45f,
    /** Disable sensor-driven wallpaper drift for a still, battery-friendly scene. */
    val parallaxEnabled: Boolean = true,
    /** Prefer immediate scene changes and reduced decorative motion. */
    val reducedMotion: Boolean = false,
)

/**
 * One lock screen. Later passes add widgets, media-card style, focus link, filters, etc.
 * as new fields with defaults, so profiles saved by Pass 1 keep loading.
 */
@Serializable
data class LockProfile(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Lock Screen",
    val wallpaper: WallpaperConfig = WallpaperConfig(),
    val clock: ClockConfig = ClockConfig(),
    /** Independent typography and styling for the compact clock shown in album mode. */
    val albumClock: ClockConfig = ClockConfig(heightFraction = 0.22f, depthEffect = false),
    val widgets: List<WidgetConfig> = defaultWidgets(),
    val quickLeft: QuickActionConfig = QuickActionConfig(QuickAction.FLASHLIGHT),
    val quickRight: QuickActionConfig = QuickActionConfig(QuickAction.CAMERA),
    val mediaStyle: GlassStyle = GlassStyle(intensity = 0.5f),
    /** Hide the player card surface in album mode so controls float directly over the artwork backdrop. */
    val albumPlayerBlend: Boolean = true,
    /** Album artwork presentation in the full-screen player. */
    val albumArtworkStyle: AlbumArtworkStyle = AlbumArtworkStyle.COVER,
    /** Horizontal placement of album art in the full-screen player. */
    val albumCoverPosition: AlbumCoverPosition = AlbumCoverPosition.CENTER,
    /** User-imported AI outpainted backdrop; generated externally and never requested automatically. */
    val albumExpansionPath: String? = null,
    /** Maximum notification cards shown on the lock screen and in album mode. */
    val notificationLimit: Int = 4,
    /** Automatically selects a visual scene from local time; never changes system DND. */
    val autoSceneByTime: Boolean = false,
    val statusText: String = "🌙 Do Not Disturb",
    val inlineText: String = "",
    val notificationStyle: GlassStyle = GlassStyle(intensity = 0.5f),
    /** Independent optical material for standalone text surfaces. */
    val textStyle: GlassStyle = GlassStyle(intensity = 0.25f),
    val focusEmoji: String = "",
    val focusLabel: String = "",
)
