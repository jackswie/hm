package com.glasslock.ui.media

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import kotlinx.coroutines.delay
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.background
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.glasslock.data.model.GlassStyle
import com.glasslock.data.model.AlbumArtworkStyle
import com.glasslock.data.model.AlbumCoverPosition
import com.glasslock.data.model.ClockConfig
import com.glasslock.ui.clock.ClockFonts
import com.glasslock.ui.clock.ClockTypefaces
import com.glasslock.service.LockNotification
import com.glasslock.ui.clock.ClockPlacement
import com.glasslock.ui.notifications.NotificationStack

/**
 * Album mode for tablets. Artwork occupies the left half; the right column is deliberately ordered
 * clock -> playback controls -> notifications. Each region has its own constraints and entrance
 * motion, so resizing the lock-screen clock cannot affect this layout.
 */
@Composable
fun BoxScope.FullPlayer(
    np: NowPlaying,
    artwork: android.graphics.Bitmap?,
    style: GlassStyle,
    placement: ClockPlacement,
    clockText: String,
    clockConfig: ClockConfig,
    notifications: List<LockNotification>,
    notificationStyle: GlassStyle,
    onNotificationOpen: (LockNotification) -> Unit,
    onNotificationDismiss: (LockNotification) -> Unit,
    onClose: () -> Unit,
    onEditClock: () -> Unit,
    showEditHint: Boolean,
    editing: Boolean,
    blendPlayerBackground: Boolean,
    artworkStyle: AlbumArtworkStyle,
    coverPosition: AlbumCoverPosition,
    notificationLimit: Int,
    reducedMotion: Boolean = false,
    onEditMedia: () -> Unit,
    onImportExpansion: () -> Unit,
    onEditNotifications: () -> Unit,
    onOutput: () -> Unit,
) {
    val art = remember(artwork) { artwork?.asImageBitmap() } ?: return
    var lyricsVisible by remember(np.key) { mutableStateOf(false) }
    var lyricPosition by remember(np.key) { mutableStateOf(np.positionNow()) }
    val lyricLines = remember(np.key, np.lyrics) { parseLyrics(np.lyrics) }
    val lyricAccent = remember(artwork) { artworkAccent(artwork) }
    LaunchedEffect(np.key, np.isPlaying, np.positionMs, np.stamp) {
        while (true) {
            lyricPosition = np.positionNow()
            delay(250)
        }
    }
    val context = LocalContext.current
    val albumFont = remember(context, clockConfig.font, clockConfig.weight) {
        FontFamily(ClockTypefaces.create(context, ClockFonts.spec(clockConfig.font), clockConfig.weight))
    }
    val scale by animateFloatAsState(
        targetValue = if (np.isPlaying) 1f else 0.90f,
        animationSpec = if (reducedMotion) tween(0) else spring(dampingRatio = 0.78f, stiffness = 260f),
        label = "albumCoverScale",
    )

    // Background dismiss target; interactive content is composed above it.
    Box(
        Modifier.fillMaxSize().clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null,
            onClick = onClose,
        )
    )

    // Unified composition: CENTER is measured against the full canvas, not a side column.
    BoxWithConstraints(Modifier.fillMaxSize().padding(start = 30.dp, end = 30.dp, top = 58.dp, bottom = 78.dp)) {
        val compactLandscape = maxWidth > maxHeight
        val dateLabel = remember { java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("EEEE, MMMM d", java.util.Locale.getDefault())) }
        if (coverPosition == AlbumCoverPosition.LEFT && compactLandscape) {
            // Restore the original split-screen LEFT composition: artwork owns the left pane,
            // while date, clock, playback and notifications form a compact right column.
            Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(34.dp),
                verticalAlignment = Alignment.CenterVertically) {
                BoxWithConstraints(Modifier.weight(1.08f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize()) {
                        drawRect(Brush.radialGradient(
                            colors = listOf(lyricAccent.copy(alpha = 0.30f), lyricAccent.copy(alpha = 0.08f), Color.Transparent),
                            center = Offset(size.width * 0.5f, size.height * 0.5f), radius = size.minDimension * 0.9f))
                    }
                    if (lyricsVisible && lyricLines.isNotEmpty()) {
                        LyricsPanel(lyricLines, lyricPosition, lyricAccent, Modifier.fillMaxSize()) { MediaRepository.seekTo(it) }
                    } else {
                        CoverArt(art, minOf(maxWidth * 0.94f, maxHeight * 0.94f), scale, np.isPlaying, artworkStyle)
                    }
                    LyricsToggle(lyricsVisible, lyricLines.isNotEmpty(), Modifier.align(Alignment.TopEnd)) { lyricsVisible = !lyricsVisible }
                }
                Column(Modifier.weight(0.92f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterVertically)) {
                    Text(dateLabel, color = Color.White.copy(alpha = 0.88f), fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                    Text(clockText, color = Color.White, fontSize = 66.sp, lineHeight = 70.sp,
                        fontFamily = albumFont, fontWeight = FontWeight(clockConfig.weight.coerceIn(1, 1000)),
                        modifier = Modifier.clickable(onClick = onEditClock))
                    if (showEditHint) Text("EDIT DATE & TIME", color = Color.White.copy(alpha = 0.58f), fontSize = 9.sp,
                        letterSpacing = 1.4.sp, modifier = Modifier.clickable(onClick = onEditClock))
                    if (editing) Text("TAP PLAYER TO EDIT", color = Color.White.copy(alpha = 0.54f), fontSize = 9.sp)
                    if (editing) Text("IMPORT EXPANDED ARTWORK", color = Color.White.copy(alpha = 0.78f), fontSize = 10.sp,
                        modifier = Modifier.clickable(onClick = onImportExpansion))
                    AnimatedVisibility(visible = true, enter = fadeIn(tween(if (reducedMotion) 0 else 260)) + slideInVertically(
                        animationSpec = if (reducedMotion) tween(0) else spring(dampingRatio = 0.84f, stiffness = 330f), initialOffsetY = { if (reducedMotion) 0 else it / 8 })) {
                        NowPlayingCard(np = np, style = style, interactive = !editing, onDismiss = onClose,
                            onOutput = onOutput, onEditTap = onEditMedia, expanded = true,
                            showSurface = !blendPlayerBackground, modifier = Modifier.fillMaxWidth())
                    }
                    AnimatedVisibility(visible = notifications.isNotEmpty(), enter = fadeIn(tween(if (reducedMotion) 0 else 240, delayMillis = if (reducedMotion) 0 else 80)) +
                        slideInVertically(animationSpec = if (reducedMotion) tween(0) else spring(dampingRatio = 0.88f, stiffness = 360f), initialOffsetY = { if (reducedMotion) 0 else -it / 8 })) {
                        Column(Modifier.fillMaxWidth()) {
                            if (editing) Text("TAP NOTIFICATIONS TO EDIT", color = Color.White.copy(alpha = 0.54f), fontSize = 9.sp,
                                letterSpacing = 1.4.sp, modifier = Modifier.padding(bottom = 5.dp))
                            NotificationStack(items = notifications.take(notificationLimit), style = notificationStyle,
                                interactive = !editing, onOpen = onNotificationOpen, onDismiss = onNotificationDismiss,
                                onEditTap = onEditNotifications, modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
            }
        } else {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(if (compactLandscape) 7.dp else 11.dp)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = if (compactLandscape) 18.dp else 8.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                Text(dateLabel, color = Color.White.copy(alpha = 0.92f), fontSize = if (compactLandscape) 15.sp else 17.sp,
                    fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text(clockText, color = Color.White, fontSize = if (compactLandscape) 39.sp else 43.sp,
                    lineHeight = if (compactLandscape) 42.sp else 46.sp, fontFamily = albumFont,
                    fontWeight = FontWeight(clockConfig.weight.coerceIn(1, 1000)), modifier = Modifier.clickable(onClick = onEditClock))
            }
            if (showEditHint) Text("EDIT ALBUM DATE & TIME", color = Color.White.copy(alpha = 0.58f), fontSize = 9.sp,
                letterSpacing = 1.6.sp, modifier = Modifier.clickable(onClick = onEditClock))
            if (editing) Text("TAP PLAYER TO EDIT", color = Color.White.copy(alpha = 0.54f), fontSize = 9.sp, letterSpacing = 1.5.sp)
            if (editing) Text("IMPORT GEMINI EXPANSION", color = Color.White.copy(alpha = 0.78f), fontSize = 10.sp, letterSpacing = 1.2.sp, modifier = Modifier.clickable(onClick = onImportExpansion).padding(vertical = 3.dp))
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth(),
                contentAlignment = if (coverPosition == AlbumCoverPosition.LEFT) Alignment.CenterStart else Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    drawRect(Brush.radialGradient(colors = listOf(lyricAccent.copy(alpha = 0.30f), lyricAccent.copy(alpha = 0.09f), Color.Transparent),
                        center = Offset(if (coverPosition == AlbumCoverPosition.LEFT) size.width * 0.28f else size.width * 0.5f, size.height * 0.5f),
                        radius = size.minDimension * 0.88f))
                }
                if (lyricsVisible && lyricLines.isNotEmpty()) {
                    LyricsPanel(lyricLines, lyricPosition, lyricAccent, Modifier.fillMaxSize()) { MediaRepository.seekTo(it) }
                } else {
                    val coverSide = if (compactLandscape) minOf(maxWidth * 0.40f, maxHeight * 0.94f) else minOf(maxWidth * 0.72f, maxHeight * 0.94f)
                    CoverArt(art, coverSide, scale, np.isPlaying, artworkStyle)
                }
                LyricsToggle(lyricsVisible, lyricLines.isNotEmpty(), Modifier.align(Alignment.TopEnd)) { lyricsVisible = !lyricsVisible }
            }
            AnimatedVisibility(visible = true, enter = fadeIn(tween(if (reducedMotion) 0 else 280, delayMillis = if (reducedMotion) 0 else 80)) +
                slideInVertically(animationSpec = if (reducedMotion) tween(0) else spring(dampingRatio = 0.84f, stiffness = 330f), initialOffsetY = { if (reducedMotion) 0 else it / 7 }) +
                scaleIn(animationSpec = if (reducedMotion) tween(0) else spring(dampingRatio = 0.88f, stiffness = 320f), initialScale = if (reducedMotion) 1f else 0.975f)) {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Box(Modifier.fillMaxWidth(if (compactLandscape) 0.62f else 0.88f).widthIn(max = if (compactLandscape) 520.dp else 460.dp)) {
                        NowPlayingCard(np = np, style = style, interactive = !editing, onDismiss = onClose,
                            onOutput = onOutput, onEditTap = onEditMedia, expanded = true,
                            showSurface = !blendPlayerBackground, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
            AnimatedVisibility(visible = notifications.isNotEmpty(), enter = fadeIn(tween(if (reducedMotion) 0 else 240, delayMillis = if (reducedMotion) 0 else 120)) +
                slideInVertically(animationSpec = if (reducedMotion) tween(0) else spring(dampingRatio = 0.88f, stiffness = 360f), initialOffsetY = { if (reducedMotion) 0 else -it / 6 })) {
                Column(Modifier.fillMaxWidth(if (compactLandscape) 0.62f else 0.88f).widthIn(max = if (compactLandscape) 520.dp else 460.dp)) {
                    if (editing) Text("TAP NOTIFICATIONS TO EDIT", color = Color.White.copy(alpha = 0.54f), fontSize = 9.sp,
                        letterSpacing = 1.5.sp, modifier = Modifier.padding(bottom = 5.dp))
                    NotificationStack(items = notifications.take(notificationLimit), style = notificationStyle,
                        interactive = !editing, onOpen = onNotificationOpen, onDismiss = onNotificationDismiss,
                        onEditTap = onEditNotifications, modifier = Modifier.fillMaxWidth())
                }
            }
        }
        }
    }
}

@Composable
private fun CoverArt(art: ImageBitmap, side: Dp, scale: Float, playing: Boolean, artworkStyle: AlbumArtworkStyle) {
    val shape = RoundedCornerShape(28.dp)
    // A directional, spring-settled handoff: the previous cover stays composed beneath
    // the incoming one, so metadata churn never exposes an empty/black placeholder frame.
    AnimatedContent(
        targetState = art,
        transitionSpec = {
            (fadeIn(tween(300)) +
                slideInHorizontally(animationSpec = spring(dampingRatio = 0.86f, stiffness = 260f)) { it / 12 } +
                scaleIn(animationSpec = spring(dampingRatio = 0.86f, stiffness = 280f), initialScale = 1.035f)) togetherWith
                (fadeOut(tween(240)) +
                    slideOutHorizontally(animationSpec = spring(dampingRatio = 0.9f, stiffness = 300f)) { -it / 16 } +
                    scaleOut(animationSpec = spring(dampingRatio = 0.9f, stiffness = 300f), targetScale = 0.975f))
        },
        label = "albumArtworkSpatialTransition",
    ) { cover ->
        if (artworkStyle == AlbumArtworkStyle.VINYL) {
            VinylArtwork(cover, side, scale, playing)
        } else {
            Image(
                cover, null,
                Modifier
                    .size(side)
                    .graphicsLayer { scaleX = scale; scaleY = scale }
                    .shadow(30.dp, shape, clip = false, ambientColor = Color.Black.copy(alpha = 0.34f), spotColor = Color.Black.copy(alpha = 0.42f))
                    .clip(shape),
                contentScale = ContentScale.Fit,
                filterQuality = FilterQuality.High,
            )
        }
    }
}


@Composable
private fun VinylArtwork(art: ImageBitmap, side: Dp, scale: Float, playing: Boolean) {
    val transition = rememberInfiniteTransition(label = "vinylRotation")
    val rotation by transition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(12_000, easing = LinearEasing)),
        label = "vinylRotationAngle",
    )
    Box(
        Modifier.size(side)
            .graphicsLayer { scaleX = scale; scaleY = scale; rotationZ = if (playing) rotation else 0f }
            .shadow(30.dp, CircleShape, clip = false, ambientColor = Color.Black.copy(alpha = 0.38f), spotColor = Color.Black.copy(alpha = 0.46f)),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(Color(0xFF111216))
            val maxR = size.minDimension * 0.47f
            for (i in 1..18) {
                val radius = maxR * (0.48f + i * 0.027f)
                drawCircle(Color.White.copy(alpha = if (i % 3 == 0) 0.13f else 0.055f), radius, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.dp.toPx()))
            }
            drawCircle(Color(0xFF292B30), maxR * 0.48f)
        }
        Image(
            art, null,
            Modifier.size(side * 0.46f).clip(CircleShape),
            contentScale = ContentScale.Crop, filterQuality = FilterQuality.High,
        )
    }
}


private data class TimedLyric(val timeMs: Long?, val text: String)

private fun parseLyrics(raw: String): List<TimedLyric> {
    if (raw.isBlank()) return emptyList()
    val timestamp = Regex("\\[(\\d{1,2}):(\\d{2})(?:[.:](\\d{1,3}))?]")
    val parsed = raw.lineSequence().flatMap { line ->
        val matches = timestamp.findAll(line).toList()
        val text = timestamp.replace(line, "").trim()
        if (matches.isEmpty()) sequenceOf(TimedLyric(null, line.trim()).takeIf { it.text.isNotEmpty() })
            .filterNotNull()
        else matches.asSequence().map { match ->
            val minutes = match.groupValues[1].toLongOrNull() ?: 0L
            val seconds = match.groupValues[2].toLongOrNull() ?: 0L
            val fractionRaw = match.groupValues.getOrNull(3).orEmpty()
            val fraction = when (fractionRaw.length) {
                1 -> (fractionRaw.toLongOrNull() ?: 0L) * 100L
                2 -> (fractionRaw.toLongOrNull() ?: 0L) * 10L
                else -> fractionRaw.take(3).toLongOrNull() ?: 0L
            }
            TimedLyric(minutes * 60_000L + seconds * 1_000L + fraction, text)
        }
    }.sortedBy { it.timeMs ?: Long.MAX_VALUE }.toList()
    return parsed
}

@Composable
private fun LyricsToggle(visible: Boolean, available: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    if (!available) return
    Text(
        if (visible) "ARTWORK" else "LYRICS",
        color = Color.White.copy(alpha = 0.94f),
        fontSize = 10.sp,
        letterSpacing = 1.6.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = modifier.padding(8.dp).clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.34f))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 9.dp),
    )
}

/** Picks a restrained accent from the album art without adding a palette dependency. */
private fun artworkAccent(bitmap: android.graphics.Bitmap?): Color {
    if (bitmap == null || bitmap.isRecycled || bitmap.width <= 0 || bitmap.height <= 0) {
        return Color(0xFFB8C7FF)
    }
    val sampleW = 24
    val sampleH = 24
    val pixels = IntArray(sampleW * sampleH)
    return runCatching {
        var sampleIndex = 0
        for (y in 0 until sampleH) {
            for (x in 0 until sampleW) {
                val sourceX = (x * bitmap.width / sampleW).coerceIn(0, bitmap.width - 1)
                val sourceY = (y * bitmap.height / sampleH).coerceIn(0, bitmap.height - 1)
                pixels[sampleIndex++] = bitmap.getPixel(sourceX, sourceY)
            }
        }
        var best = android.graphics.Color.rgb(184, 199, 255)
        var bestScore = -1f
        for (pixel in pixels) {
            if (android.graphics.Color.alpha(pixel) < 180) continue
            val hsv = FloatArray(3)
            android.graphics.Color.colorToHSV(pixel, hsv)
            val saturation = hsv[1]
            val value = hsv[2]
            if (value !in 0.18f..0.92f) continue
            val score = saturation * (1f - kotlin.math.abs(value - 0.58f))
            if (score > bestScore) {
                bestScore = score
                best = pixel
            }
        }
        Color(best).copy(alpha = 1f)
    }.getOrDefault(Color(0xFFB8C7FF))
}

@Composable
private fun LyricsPanel(
    lines: List<TimedLyric>,
    positionMs: Long,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onSeek: (Long) -> Unit,
) {
    val timed = lines.any { it.timeMs != null }
    val active = if (timed) {
        lines.indexOfLast { (it.timeMs ?: Long.MAX_VALUE) <= positionMs }.coerceAtLeast(0)
    } else 0
    val accent by animateColorAsState(
        targetValue = accentColor,
        animationSpec = tween(650),
        label = "lyricsArtworkAccent",
    )
    val activeStart = lines.getOrNull(active)?.timeMs
    val nextStart = lines.getOrNull(active + 1)?.timeMs
    val lineProgress = if (timed && activeStart != null && nextStart != null && nextStart > activeStart) {
        ((positionMs - activeStart).toFloat() / (nextStart - activeStart).toFloat()).coerceIn(0f, 1f)
    } else 0f
    Column(
        modifier = modifier.padding(horizontal = 18.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            "NOW PLAYING",
            color = accent.copy(alpha = 0.82f),
            fontSize = 9.sp,
            letterSpacing = 2.4.sp,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(Modifier.height(22.dp))
        AnimatedContent(
            targetState = active,
            transitionSpec = {
                (fadeIn(tween(300)) + slideInVertically(tween(340)) { it / 3 }) togetherWith
                    (fadeOut(tween(210)) + androidx.compose.animation.slideOutVertically(tween(260)) { -it / 4 })
            },
            label = "lyricsLineFlow",
        ) { current ->
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                val previous = (current - 2).coerceAtLeast(0)
                val next = (current + 3).coerceAtMost(lines.lastIndex)
                for (index in previous until current.coerceAtMost(lines.size)) {
                    val line = lines[index]
                    Text(
                        line.text,
                        color = Color.White.copy(alpha = if (index == current - 1) 0.52f else 0.30f),
                        fontSize = 15.sp,
                        lineHeight = 21.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
                            .then(if (timed && line.timeMs != null) Modifier.clickable { onSeek(line.timeMs) } else Modifier),
                    )
                }
                if (current in lines.indices) {
                    val line = lines[current]
                    KaraokeLyricLine(
                        text = line.text,
                        progress = lineProgress,
                        accent = accent,
                        modifier = Modifier.fillMaxWidth()
                            .padding(vertical = 5.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(accent.copy(alpha = 0.13f))
                            .clickable(enabled = timed && line.timeMs != null) {
                                line.timeMs?.let(onSeek)
                            }
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                    )
                }
                for (index in (current + 1)..next) {
                    if (index in lines.indices) {
                        val line = lines[index]
                        Text(
                            line.text,
                            color = Color.White.copy(alpha = if (index == current + 1) 0.58f else 0.38f),
                            fontSize = if (index == current + 1) 17.sp else 15.sp,
                            lineHeight = 23.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                                .then(if (timed && line.timeMs != null) Modifier.clickable { onSeek(line.timeMs) } else Modifier),
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Text(
            if (timed) "TAP A LINE TO SEEK" else "LYRICS FROM YOUR MUSIC APP",
            color = Color.White.copy(alpha = 0.38f),
            fontSize = 9.sp,
            letterSpacing = 1.5.sp,
        )
    }
}


/**
 * Word-by-word karaoke emphasis estimated between adjacent LRC timestamps.
 * Standard LRC timestamps whole lines, not syllables, so the highlight interpolates
 * across the line instead of claiming exact vocal-level synchronization.
 */
@Composable
private fun KaraokeLyricLine(
    text: String,
    progress: Float,
    accent: Color,
    modifier: Modifier = Modifier,
) {
    val words = remember(text) { text.split(Regex("\\s+")).filter { it.isNotEmpty() } }
    val targetWord = if (words.isEmpty()) 0f else (progress * words.size).coerceIn(0f, (words.size - 1).toFloat())
    val animatedWord by animateFloatAsState(
        targetValue = targetWord,
        animationSpec = tween(190),
        label = "karaokeWordProgress",
    )
    val activeWord = animatedWord.toInt()
    val lyric = buildAnnotatedString {
        words.forEachIndexed { index, word ->
            val wordColor = when {
                index < activeWord -> Color.White.copy(alpha = 0.70f)
                index == activeWord -> accent
                else -> Color.White.copy(alpha = 0.76f)
            }
            withStyle(SpanStyle(color = wordColor)) { append(word) }
            if (index != words.lastIndex) append(" ")
        }
    }
    Text(
        text = lyric,
        color = Color.White,
        fontSize = 23.sp,
        lineHeight = 30.sp,
        fontWeight = FontWeight.Bold,
        textAlign = TextAlign.Center,
        style = TextStyle(shadow = Shadow(color = accent.copy(alpha = 0.72f), offset = Offset.Zero, blurRadius = 24f)),
        modifier = modifier,
    )
}
