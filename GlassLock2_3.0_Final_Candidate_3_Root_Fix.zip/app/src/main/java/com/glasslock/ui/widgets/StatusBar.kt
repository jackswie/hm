package com.glasslock.ui.widgets

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** iPadOS-style top-right status: Wi-Fi, battery percentage and a battery pill (yellow-green when charging). */
@Composable
fun StatusBar(modifier: Modifier = Modifier) {
    val battery by rememberBattery()
    val wifi by rememberOnWifi()
    Row(modifier.padding(horizontal = 24.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        if (wifi) {
            Canvas(Modifier.size(16.dp)) {
                val sw = Stroke(1.8.dp.toPx(), cap = StrokeCap.Round)
                for (i in 1..3) {
                    val r = size.width * i / 3f * 0.9f
                    drawArc(
                        Color.White, 225f, 90f, false,
                        topLeft = Offset(center.x - r, size.height - r), size = Size(r * 2, r * 2), style = sw,
                    )
                }
            }
            Spacer(Modifier.width(8.dp))
        }
        Text("${battery.percent}%", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.width(6.dp))
        Canvas(Modifier.size(width = 26.dp, height = 12.dp)) {
            val body = Size(size.width - 3.dp.toPx(), size.height)
            drawRoundRect(Color.White.copy(alpha = 0.4f), size = body, cornerRadius = CornerRadius(4.dp.toPx()), style = Stroke(1.2.dp.toPx()))
            val pad = 2.dp.toPx()
            drawRoundRect(
                if (battery.charging) Color(0xFFFFD60A) else Color.White,
                topLeft = Offset(pad, pad),
                size = Size((body.width - 2 * pad) * battery.percent / 100f, body.height - 2 * pad),
                cornerRadius = CornerRadius(2.dp.toPx()),
            )
            drawRoundRect(Color.White.copy(alpha = 0.4f), Offset(body.width + 1.dp.toPx(), size.height * 0.33f), Size(1.6.dp.toPx(), size.height * 0.34f), CornerRadius(1.dp.toPx()))
        }
    }
}
