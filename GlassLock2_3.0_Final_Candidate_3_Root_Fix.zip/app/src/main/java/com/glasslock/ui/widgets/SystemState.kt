package com.glasslock.ui.widgets

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

data class BatteryInfo(val percent: Int = 0, val charging: Boolean = false)

private fun parse(i: Intent): BatteryInfo {
    val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
    val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
    val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
    val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
    return BatteryInfo(level * 100 / scale, charging)
}

/** Real Android battery level, updated by the sticky ACTION_BATTERY_CHANGED broadcast. */
@Composable
fun rememberBattery(): State<BatteryInfo> {
    val context = LocalContext.current
    val state = remember { mutableStateOf(BatteryInfo()) }
    DisposableEffect(context) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, intent: Intent) {
                state.value = parse(intent)
            }
        }
        val sticky = ContextCompat.registerReceiver(
            context, receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        sticky?.let { state.value = parse(it) }
        onDispose { context.unregisterReceiver(receiver) }
    }
    return state
}

@Composable
fun rememberOnWifi(): State<Boolean> {
    val context = LocalContext.current
    return produceState(false) {
        val cm = context.getSystemService(ConnectivityManager::class.java)
        while (true) {
            val caps = cm?.activeNetwork?.let { cm.getNetworkCapabilities(it) }
            value = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
            delay(5_000)
        }
    }
}
