package com.glasslock.ui.clock

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.remember
import androidx.compose.ui.draw.blur
import androidx.compose.ui.unit.dp
import com.glasslock.ui.glass.Palette
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import com.glasslock.data.model.WallpaperConfig
import java.io.File
import java.util.UUID
import kotlin.math.max
import kotlin.random.Random

/**
 * The wallpaper and its cutout must use identical transforms and filters or the subject drifts off the photo.
 * [isCutout] layers skip the blurred "extend" fill and the blur toggle, so only the real wallpaper gets them.
 */
@Composable
fun WallpaperImage(
    bitmap: ImageBitmap,
    config: WallpaperConfig,
    palette: Palette,
    modifier: Modifier = Modifier,
    isCutout: Boolean = false,
) {
    val filter = remember(config.filter, config.dim, palette) { wallpaperColorFilter(config, palette) }
    val scale = if (config.extend) ContentScale.Fit else ContentScale.Crop
    Box(
        modifier
            .fillMaxSize()
            .graphicsLayer {
                scaleX = config.zoom
                scaleY = config.zoom
                translationX = config.panX * size.width
                translationY = config.panY * size.height
            },
    ) {
        if (config.extend && !isCutout) {
            Image(bitmap, null, Modifier.fillMaxSize().blur(40.dp), contentScale = ContentScale.Crop, colorFilter = filter)
        }
        Image(
            bitmap, null,
            Modifier.fillMaxSize().then(if (config.blur && !isCutout) Modifier.blur(18.dp) else Modifier),
            contentScale = scale, colorFilter = filter,
        )
    }
}

object WallpaperLoader {
    /** Copies a picked photo into app storage so access never expires. */
    fun importFrom(context: Context, uri: Uri): File {
        val dir = File(context.filesDir, "wallpapers").apply { mkdirs() }
        val out = File(dir, "${UUID.randomUUID()}.img")
        val input = context.contentResolver.openInputStream(uri) ?: error("Cannot open $uri")
        input.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
        return out
    }

    /** Software bitmap (needed for palette sampling and segmentation), longest side <= [maxSide]. */
    fun decode(file: File, maxSide: Int = 2560): Bitmap =
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(file)) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val longest = max(info.size.width, info.size.height)
            if (longest > maxSide) {
                val f = maxSide.toFloat() / longest
                decoder.setTargetSize((info.size.width * f).toInt(), (info.size.height * f).toInt())
            }
        }
}

/**
 * Procedural night skyline so the app is fully testable with no photo: returns the full picture and
 * a cutout holding only the foreground towers (what ML Kit would produce for a real photo).
 */
object DemoWallpaper {
    fun create(w: Int = 2400, h: Int = 1500): Pair<Bitmap, Bitmap> {
        val full = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val fore = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        draw(Canvas(full), w, h, sky = true, far = true)
        draw(Canvas(fore), w, h, sky = false, far = false)
        return full to fore
    }

    private fun draw(c: Canvas, w: Int, h: Int, sky: Boolean, far: Boolean) {
        val W = w.toFloat()
        val H = h.toFloat()
        val ground = H * 0.9f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        if (sky) {
            p.shader = LinearGradient(
                0f, 0f, 0f, H,
                intArrayOf(0xFF05070F.toInt(), 0xFF111B36.toInt(), 0xFF51405E.toInt(), 0xFFD98457.toInt()),
                floatArrayOf(0f, 0.45f, 0.78f, 1f),
                Shader.TileMode.CLAMP,
            )
            c.drawRect(0f, 0f, W, H, p)
            p.shader = null
        }
        if (far) {
            val rnd = Random(3)
            var x = -20f
            while (x < W) {
                val bw = 50f + rnd.nextFloat() * 110f
                val bh = H * (0.14f + rnd.nextFloat() * 0.18f)
                p.color = 0xFF1B2540.toInt()
                c.drawRect(x, ground - bh, x + bw, ground, p)
                windows(c, p, rnd, x, ground - bh, bw, bh, 0.20f, 0x99FFD9A0.toInt())
                x += bw + 6f
            }
        }

        // Foreground: the part a subject cutout would keep.
        val rnd = Random(11)
        p.color = 0xFF080B14.toInt()
        val cx = W * 0.47f
        val tower = Tower(cx, ground, W, H)
        tower.draw(c, p)
        windows(c, p, rnd, cx - W * 0.05f, H * 0.36f, W * 0.10f, ground - H * 0.36f, 0.30f, 0xCCFFC76B.toInt())

        val sides = listOf(
            Triple(0.05f, 0.11f, 0.34f), Triple(0.17f, 0.09f, 0.28f), Triple(0.30f, 0.08f, 0.22f),
            Triple(0.62f, 0.09f, 0.30f), Triple(0.73f, 0.11f, 0.38f), Triple(0.87f, 0.10f, 0.26f),
        )
        for ((fx, fw, fh) in sides) {
            val bx = W * fx
            val bw = W * fw
            val top = ground - H * fh
            p.color = 0xFF080B14.toInt()
            c.drawRect(bx, top, bx + bw, ground + 2f, p)
            windows(c, p, rnd, bx, top, bw, ground - top, 0.34f, 0xBBFFD28A.toInt())
        }
        p.color = 0xFF05070C.toInt()
        c.drawRect(0f, ground, W, H, p)
    }

    private fun windows(c: Canvas, p: Paint, rnd: Random, x: Float, y: Float, w: Float, h: Float, density: Float, color: Int) {
        val step = 22f
        var yy = y + 18f
        while (yy < y + h - 10f) {
            var xx = x + 12f
            while (xx < x + w - 12f) {
                if (rnd.nextFloat() < density) {
                    p.color = color
                    c.drawRect(xx, yy, xx + 9f, yy + 12f, p)
                }
                xx += step
            }
            yy += step * 1.5f
        }
    }

    /** Stepped Empire-State-style tower with a spire. */
    private class Tower(val cx: Float, val ground: Float, val W: Float, val H: Float) {
        fun draw(c: Canvas, p: Paint) {
            val tiers = listOf(
                Triple(0.100f, 0.36f, 0.90f),
                Triple(0.070f, 0.29f, 0.36f),
                Triple(0.045f, 0.23f, 0.29f),
                Triple(0.026f, 0.19f, 0.23f),
            )
            for ((wf, topF, botF) in tiers) {
                val half = W * wf / 2f
                c.drawRect(cx - half, H * topF, cx + half, H * botF, p)
            }
            c.drawRect(cx - W * 0.003f, H * 0.12f, cx + W * 0.003f, H * 0.19f, p)
            c.drawRect(cx - W * 0.0008f, H * 0.075f, cx + W * 0.0008f, H * 0.12f, p)
        }
    }
}
