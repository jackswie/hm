package com.glasslock.ui.clock

import android.content.Context
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import com.glasslock.data.model.ClockFontId

/** Extra outline treatment for faces Android has no system font for. */
enum class GlyphEffect { NONE, ROUND, STENCIL, RAILS }

/**
 * One selectable clock face.
 *
 * Resolution order: (1) the variable font in app/src/main/assets/<assetPath>, using its real `wght`
 * axis (plus [axes], e.g. a narrower `wdth`); (2) the Android system family if the file is missing
 * or cannot be rendered.
 */
data class ClockFontSpec(
    val id: ClockFontId,
    val label: String,
    val systemFamily: String,
    val assetPath: String,
    val effect: GlyphEffect = GlyphEffect.NONE,
    val weightBias: Int = 0,
    /** Extra variation axes appended to the weight, e.g. ", 'wdth' 56". */
    val axes: String = "",
)

object ClockFonts {
    val all: List<ClockFontSpec> = listOf(
        ClockFontSpec(ClockFontId.SF_PRO, "SF Pro", "sans-serif", "fonts/clock_sans.otf"),
        ClockFontSpec(ClockFontId.CONDENSED, "Condensed", "sans-serif-condensed", "fonts/clock_sans.otf", axes = ", 'wdth' 56"),
        ClockFontSpec(ClockFontId.ROUNDED, "Rounded", "sans-serif", "fonts/clock_rounded.otf"),
        ClockFontSpec(ClockFontId.SF_SOFT, "Soft", "sans-serif", "fonts/clock_sf_soft.otf"),
        ClockFontSpec(ClockFontId.ADAPTIVE, "Adaptive", "sans-serif", "fonts/clock_adaptive.otf"),
        ClockFontSpec(ClockFontId.ADAPTIVE_SOFT, "Adaptive Soft", "sans-serif", "fonts/clock_adaptive_soft.otf"),
        ClockFontSpec(ClockFontId.SERIF, "Serif", "serif", "fonts/clock_serif.otf"),
        ClockFontSpec(ClockFontId.SERIF_SOFT, "Serif Soft", "serif", "fonts/clock_serif_soft.otf"),
        ClockFontSpec(ClockFontId.SLAB, "Slab", "serif", "fonts/clock_slab.otf"),
        ClockFontSpec(ClockFontId.SLAB_SOFT, "Slab Soft", "serif", "fonts/clock_slab_soft.otf"),
        ClockFontSpec(ClockFontId.STENCIL, "Stencil", "sans-serif-condensed", "fonts/clock_stencil.otf"),
        ClockFontSpec(ClockFontId.RAILS, "Rails", "sans-serif", "fonts/clock_rails.otf"),
        ClockFontSpec(ClockFontId.RAILS_ROUNDED, "Rails Rounded", "sans-serif", "fonts/clock_rails_rounded.otf"),
        ClockFontSpec(ClockFontId.HANDWRITTEN, "Handwritten", "cursive", "fonts/clock_hand.ttf"),
    )

    fun spec(id: ClockFontId): ClockFontSpec = all.first { it.id == id }

    fun effectiveWeight(spec: ClockFontSpec, weight: Int): Int = (weight + spec.weightBias).coerceIn(1, 1000)

    /** The full variation string for [spec] at [weight]. */
    fun variations(spec: ClockFontSpec, weight: Int): String = "'wght' ${effectiveWeight(spec, weight)}${spec.axes}"
}

object ClockTypefaces {
    private val cache = HashMap<String, Typeface>()

    @Synchronized
    fun create(context: Context, spec: ClockFontSpec, weight: Int): Typeface {
        val w = ClockFonts.effectiveWeight(spec, weight)
        return cache.getOrPut("${spec.id}:$w") {
            val fromAsset = runCatching {
                Typeface.Builder(context.applicationContext.assets, spec.assetPath)
                    .setFontVariationSettings(ClockFonts.variations(spec, weight))
                    .setWeight(w)
                    .build()
            }.getOrNull()?.takeIf { rendersDigits(it) }
            fromAsset ?: Typeface.create(Typeface.create(spec.systemFamily, Typeface.NORMAL), w, false)
        }
    }

    /** Guards against a font file the platform accepts but cannot draw: its "0" must have an outline. */
    private fun rendersDigits(tf: Typeface): Boolean = runCatching {
        val p = Paint().apply { typeface = tf; textSize = 100f }
        val path = Path()
        p.getTextPath("0", 0, 1, 0f, 0f, path)
        !path.isEmpty
    }.getOrDefault(false)
}
