package com.glasslock.ui.glass

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.view.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlin.math.abs

/**
 * Smoothed device tilt from the accelerometer, mapped to screen axes (x = right, y = up) and
 * clamped to -1..1. Only listens while the screen is resumed. Updates are quantised so the rim
 * light does not trigger redraws for sub-pixel changes.
 */
@Composable
fun rememberTilt(): State<Offset> {
    val context = LocalContext.current
    val view = LocalView.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val state = remember { mutableStateOf(Offset.Zero) }

    DisposableEffect(context, lifecycle) {
        val manager = context.getSystemService(SensorManager::class.java)
        val sensor = manager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (manager == null || sensor == null) {
            return@DisposableEffect onDispose { }
        }

        var fx = 0f
        var fy = 0f
        val listener = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val ax = e.values[0]
                val ay = e.values[1]
                val (right, up) = when (view.display?.rotation ?: Surface.ROTATION_0) {
                    Surface.ROTATION_90 -> -ay to ax
                    Surface.ROTATION_180 -> -ax to -ay
                    Surface.ROTATION_270 -> ay to -ax
                    else -> ax to ay
                }
                fx += ((right / 9.81f).coerceIn(-1f, 1f) - fx) * 0.12f
                fy += ((up / 9.81f).coerceIn(-1f, 1f) - fy) * 0.12f
                val cur = state.value
                if (abs(fx - cur.x) > 0.004f || abs(fy - cur.y) > 0.004f) {
                    state.value = Offset(fx, fy)
                }
            }

            override fun onAccuracyChanged(s: Sensor?, accuracy: Int) = Unit
        }

        fun register() {
            manager.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_GAME)
        }

        fun unregister() = manager.unregisterListener(listener)

        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> register()
                Lifecycle.Event.ON_PAUSE -> unregister()
                else -> Unit
            }
        }
        lifecycle.addObserver(observer)
        onDispose {
            lifecycle.removeObserver(observer)
            unregister()
        }
    }
    return state
}
