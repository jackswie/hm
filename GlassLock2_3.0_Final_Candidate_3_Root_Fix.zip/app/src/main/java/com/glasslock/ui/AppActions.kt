package com.glasslock.ui

import android.content.Intent
import androidx.compose.runtime.staticCompositionLocalOf

/** Things the UI asks the host Activity to do. On the lock screen, [launch] and [unlockThen] go through the keyguard first. */
class AppActions(
    val launch: (Intent) -> Unit,
    val requestLocation: () -> Unit,
    val openNotificationAccess: () -> Unit,
    val pickPhotos: (widgetId: String) -> Unit,
    val unlockThen: ((() -> Unit)) -> Unit = { it() },
    val openSetup: () -> Unit = {},
)

val LocalAppActions = staticCompositionLocalOf { AppActions({}, {}, {}, {}) }
