package com.glasslock.ui.clock

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import com.glasslock.data.model.WallpaperKind
import kotlin.math.PI
import kotlin.math.sin

/** Subtle, optional ambience. It is intentionally lightweight and only animates while composed. */
@Composable
fun AmbientAtmosphere(kind: WallpaperKind, intensity: Float, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "wallpaperAtmosphere")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(18000, easing = LinearEasing), RepeatMode.Restart),
        label = "atmospherePhase",
    )
    val strength = intensity.coerceIn(0f, 1f)
    Canvas(modifier) {
        val count = when (kind) {
            WallpaperKind.ASTRONOMY -> 34
            WallpaperKind.WEATHER -> 26
            else -> 18
        }
        for (i in 0 until count) {
            val seed = i * 0.6180339f
            val x = ((seed * 1.73f) % 1f) * size.width
            val baseY = ((seed * 2.41f) % 1f)
            when (kind) {
                WallpaperKind.ASTRONOMY -> {
                    val twinkle = (0.35f + 0.65f * ((sin((phase * 2f * PI + i).toDouble()).toFloat() + 1f) / 2f))
                    val y = baseY * size.height
                    drawCircle(Color.White.copy(alpha = strength * 0.48f * twinkle), radius = (1.1f + (i % 3) * 0.55f) * density, center = Offset(x, y))
                }
                WallpaperKind.WEATHER -> {
                    val y = ((baseY + phase * (0.65f + (i % 4) * 0.08f)) % 1f) * size.height
                    val drift = sin((phase * 2f * PI + i * 0.7).toDouble()).toFloat() * 9f * density
                    drawLine(Color.White.copy(alpha = strength * 0.20f), Offset(x + drift, y), Offset(x + drift - 3f * density, y + (8f + i % 5 * 2f) * density), strokeWidth = 1.2f * density)
                }
                else -> {
                    val y = ((baseY + phase * 0.12f) % 1f) * size.height
                    drawCircle(Color.White.copy(alpha = strength * 0.12f), radius = (1.4f + (i % 2)) * density, center = Offset(x, y))
                }
            }
        }
    }
}
