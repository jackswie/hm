package com.glasslock.ui.glass

import android.graphics.Bitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import kotlin.math.abs

/** [swatches] are wallpaper-sampled colours for the pickers; [tint] drives Tinted glass. */
data class Palette(val swatches: List<Color>, val tint: Color) {
    companion object {
        val Default = Palette(
            swatches = listOf(Color(0xFF3A4A66), Color(0xFFE0875A), Color(0xFF8E7CC3), Color(0xFF4F8F8B)),
            tint = Color(0xFF2B3A55),
        )
    }
}

object WallpaperPalette {
    fun from(source: Bitmap): Palette {
        val n = 56
        val small = Bitmap.createScaledBitmap(source, n, n, true)
        val px = IntArray(n * n)
        small.getPixels(px, 0, n, 0, 0, n, n)

        // 8x8x8 colour buckets, weighted towards saturated, bright pixels so a dark photo
        // still yields interesting swatches instead of eight shades of black.
        val buckets = HashMap<Int, FloatArray>()
        val hsv = FloatArray(3)
        for (c in px) {
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            android.graphics.Color.colorToHSV(c, hsv)
            val w = 0.35f + hsv[1] * hsv[2]
            val key = ((r shr 5) shl 6) or ((g shr 5) shl 3) or (b shr 5)
            val a = buckets.getOrPut(key) { FloatArray(4) }
            a[0] += w
            a[1] += r * w
            a[2] += g * w
            a[3] += b * w
        }

        val ranked = buckets.values
            .sortedByDescending { it[0] }
            .map { Color(it[1] / it[0] / 255f, it[2] / it[0] / 255f, it[3] / it[0] / 255f) }

        val swatches = ArrayList<Color>()
        for (c in ranked) {
            if (swatches.none { distance(it, c) < 0.22f }) swatches += c
            if (swatches.size == 6) break
        }
        if (swatches.isEmpty()) return Palette.Default

        // Tint = dominant colour pulled to a mid-dark value so white text keeps its contrast.
        android.graphics.Color.colorToHSV(swatches.first().toArgb(), hsv)
        val tint = Color.hsv(hsv[0], hsv[1].coerceAtLeast(0.15f), hsv[2].coerceIn(0.18f, 0.5f))
        return Palette(swatches, tint)
    }

    private fun distance(a: Color, b: Color): Float =
        abs(a.red - b.red) + abs(a.green - b.green) + abs(a.blue - b.blue)
}
