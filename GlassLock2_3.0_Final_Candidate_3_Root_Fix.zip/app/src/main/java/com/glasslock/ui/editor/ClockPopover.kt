package com.glasslock.ui.editor

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.glasslock.data.model.ClockConfig
import com.glasslock.data.model.NumeralScript
import com.glasslock.ui.clock.ClockFonts
import com.glasslock.ui.clock.ClockTypefaces
import com.glasslock.ui.glass.Palette
import kotlin.math.roundToInt

/** Every clock control, applied live. */
@Composable
fun ClockPopover(
    config: ClockConfig,
    palette: Palette,
    depthAvailable: Boolean,
    segmenting: Boolean,
    onChange: ((ClockConfig) -> ClockConfig) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    title: String = "Clock",
) {
    val context = LocalContext.current
    SheetFrame(title, onDismiss, modifier) {
        SectionTitle("Font")
        ChipFlow(
            options = ClockFonts.all.map { it.id },
            selected = config.font,
            onSelect = { f -> onChange { it.copy(font = f) } },
            label = { ClockFonts.spec(it).label },
            fontFor = { id -> FontFamily(ClockTypefaces.create(context, ClockFonts.spec(id), 500)) },
        )

        SectionTitle("Thickness")
        GlassSlider("Weight", config.weight.toString(), config.weight.toFloat(), 100f..900f) { w ->
            onChange { it.copy(weight = w.roundToInt()) }
        }

        SectionTitle("Free transform")
        GlassSlider("Width · horizontal stretch", "${(config.widthFraction * 100).roundToInt()}%", config.widthFraction * 100f, 8f..100f) { width ->
            onChange { it.copy(widthFraction = (width / 100f).coerceIn(0.08f, 1f)) }
        }
        GlassSlider("Height · vertical stretch", "${(config.heightFraction * 100).roundToInt()}%", config.heightFraction * 100f, 8f..55f) { height ->
            onChange { it.copy(heightFraction = (height / 100f).coerceIn(0.08f, 0.55f)) }
        }

        SectionTitle("Numerals")
        ChipFlow(NumeralScript.entries, config.script, { s -> onChange { it.copy(script = s) } }, { it.label })

        StyleControls(config.style, palette) { f -> onChange { it.copy(style = f(it.style)) } }

        SectionTitle("Options")
        ToggleRow(
            label = "Depth Effect",
            checked = config.depthEffect,
            enabled = !segmenting,
            note = when {
                segmenting -> "Finding the subject in your photo…"
                depthAvailable -> "Subject overlaps the clock"
                else -> "No subject detected in this photo"
            },
        ) { on -> onChange { it.copy(depthEffect = on) } }
        ToggleRow("24-hour time", config.use24Hour) { on -> onChange { it.copy(use24Hour = on) } }
        Spacer(Modifier.height(6.dp))
    }
}

