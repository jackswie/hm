package com.glasslock.ui.clock

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import com.glasslock.data.model.WallpaperConfig
import com.glasslock.data.model.WallpaperFilter
import com.glasslock.data.model.WallpaperKind
import com.glasslock.ui.glass.Palette
import kotlin.random.Random

/**
 * One colour filter for the wallpaper AND its cutout: Natural / B&W / Duotone / Color Wash, plus dimming.
 * Done as a 4x5 matrix so transparent cutout pixels stay transparent.
 */
fun wallpaperColorFilter(cfg: WallpaperConfig, palette: Palette): ColorFilter? {
    val d = if (cfg.dim) 0.62f else 1f
    if (cfg.filter == WallpaperFilter.NATURAL && !cfg.dim) return null
    val lr = 0.299f; val lg = 0.587f; val lb = 0.114f
    val m: FloatArray = when (cfg.filter) {
        WallpaperFilter.NATURAL -> floatArrayOf(
            d, 0f, 0f, 0f, 0f,
            0f, d, 0f, 0f, 0f,
            0f, 0f, d, 0f, 0f,
            0f, 0f, 0f, 1f, 0f,
        )
        WallpaperFilter.MONO -> floatArrayOf(
            lr * d, lg * d, lb * d, 0f, 0f,
            lr * d, lg * d, lb * d, 0f, 0f,
            lr * d, lg * d, lb * d, 0f, 0f,
            0f, 0f, 0f, 1f, 0f,
        )
        WallpaperFilter.DUOTONE -> {
            val c1 = palette.tint
            val c2 = palette.swatches.getOrNull(1) ?: Color.White
            fun row(a: Float, b: Float) = floatArrayOf(lr * (b - a) * d, lg * (b - a) * d, lb * (b - a) * d, 0f, a * 255f * d)
            row(c1.red, c2.red) + row(c1.green, c2.green) + row(c1.blue, c2.blue) + floatArrayOf(0f, 0f, 0f, 1f, 0f)
        }
        WallpaperFilter.WASH -> {
            val w = palette.swatches.firstOrNull() ?: palette.tint
            val k = 0.7f
            floatArrayOf(
                k * d, 0f, 0f, 0f, w.red * 0.3f * 255f * d,
                0f, k * d, 0f, 0f, w.green * 0.3f * 255f * d,
                0f, 0f, k * d, 0f, w.blue * 0.3f * 255f * d,
                0f, 0f, 0f, 1f, 0f,
            )
        }
    }
    return ColorFilter.colorMatrix(ColorMatrix(m))
}

/** Procedural wallpapers for the non-photo lock screen types. Returns an opaque bitmap. */
object WallpaperFactory {
    fun create(cfg: WallpaperConfig, w: Int = 1600, h: Int = 1000): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val W = w.toFloat()
        val H = h.toFloat()
        when (cfg.kind) {
            WallpaperKind.GRADIENT, WallpaperKind.PHOTO -> {
                p.shader = LinearGradient(0f, 0f, W, H, cfg.color1, cfg.color2, Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, W, H, p)
            }
            WallpaperKind.WEATHER -> {
                p.shader = LinearGradient(0f, 0f, 0f, H, 0xFF2B6FD6.toInt(), 0xFFBFE0FF.toInt(), Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, W, H, p)
                val rnd = Random(5)
                repeat(9) {
                    val cx = rnd.nextFloat() * W
                    val cy = H * (0.2f + rnd.nextFloat() * 0.6f)
                    val r = H * (0.12f + rnd.nextFloat() * 0.18f)
                    p.shader = RadialGradient(cx, cy, r, 0xCCFFFFFF.toInt(), 0x00FFFFFF, Shader.TileMode.CLAMP)
                    c.drawCircle(cx, cy, r, p)
                }
            }
            WallpaperKind.ASTRONOMY -> {
                p.shader = LinearGradient(0f, 0f, 0f, H, 0xFF020208.toInt(), 0xFF0B1030.toInt(), Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, W, H, p)
                p.shader = null
                val rnd = Random(9)
                repeat(380) {
                    p.color = android.graphics.Color.argb(80 + rnd.nextInt(175), 255, 255, 255)
                    c.drawCircle(rnd.nextFloat() * W, rnd.nextFloat() * H, 0.6f + rnd.nextFloat() * 1.8f, p)
                }
                val cx = W * 0.72f
                val cy = H * 0.62f
                val r = H * 0.34f
                p.shader = RadialGradient(cx - r * 0.3f, cy - r * 0.3f, r * 1.3f, 0xFFF2C98B.toInt(), 0xFF2A1A30.toInt(), Shader.TileMode.CLAMP)
                c.drawCircle(cx, cy, r, p)
            }
            WallpaperKind.EMOJI -> {
                p.shader = null
                p.color = cfg.color1
                c.drawRect(0f, 0f, W, H, p)
                p.textSize = 96f
                p.textAlign = Paint.Align.CENTER
                p.color = android.graphics.Color.WHITE
                val step = 170f
                var row = 0
                var y = step / 2
                while (y < H + step) {
                    var x = if (row % 2 == 0) step / 2 else step
                    while (x < W + step) {
                        c.drawText(cfg.emoji.ifBlank { "😀" }, x, y + 32f, p)
                        x += step
                    }
                    y += step * 0.9f
                    row++
                }
            }
        }
        return bmp
    }
}
