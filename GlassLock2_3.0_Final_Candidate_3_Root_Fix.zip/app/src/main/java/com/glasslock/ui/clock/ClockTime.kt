package com.glasslock.ui.clock

import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import kotlinx.coroutines.delay
import java.time.LocalTime
import java.util.Locale

/** Emits at every minute boundary (or every second when [everySecond]). */
@Composable
fun rememberNow(everySecond: Boolean = false): State<LocalTime> =
    produceState(LocalTime.now(), everySecond) {
        val period = if (everySecond) 1_000L else 60_000L
        while (true) {
            value = LocalTime.now()
            delay((period - System.currentTimeMillis() % period).coerceAtLeast(50L))
        }
    }

object ClockText {
    /** "19:59" in 24h mode, "7:08" in 12h mode (no leading zero, as on iPadOS). Western digits. */
    fun format(time: LocalTime, use24Hour: Boolean): String {
        val hour = if (use24Hour) time.hour else (time.hour % 12).let { if (it == 0) 12 else it }
        val hh = if (use24Hour) "%02d".format(Locale.ROOT, hour) else hour.toString()
        return "$hh:" + "%02d".format(Locale.ROOT, time.minute)
    }
}
