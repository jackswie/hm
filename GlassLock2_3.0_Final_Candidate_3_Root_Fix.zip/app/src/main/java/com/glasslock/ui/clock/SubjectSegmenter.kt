package com.glasslock.ui.clock

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.math.max

/** Wraps ML Kit Subject Segmentation: returns the wallpaper with everything but the subject made transparent. */
object SubjectSegmenter {
    private const val MAX_SIDE = 1536

    suspend fun cutout(source: Bitmap): Bitmap? {
        val scaled = downscale(source)
        val segmenter = SubjectSegmentation.getClient(
            SubjectSegmenterOptions.Builder().enableForegroundBitmap().build()
        )
        return try {
            suspendCancellableCoroutine<Bitmap?> { cont ->
                segmenter.process(InputImage.fromBitmap(scaled, 0))
                    .addOnSuccessListener { cont.resume(it.foregroundBitmap) }
                    .addOnFailureListener { cont.resume(null) }
            }
        } finally {
            segmenter.close()
        }
    }

    private fun downscale(src: Bitmap): Bitmap {
        val longest = max(src.width, src.height)
        if (longest <= MAX_SIDE) return src
        val f = MAX_SIDE.toFloat() / longest
        return Bitmap.createScaledBitmap(src, (src.width * f).toInt(), (src.height * f).toInt(), true)
    }
}

/** Disk cache so a photo is only segmented once. Cutouts keep the wallpaper's aspect ratio. */
class CutoutRepository(context: Context) {
    private val dir = File(context.applicationContext.filesDir, "cutouts").apply { mkdirs() }

    private fun cacheFile(wallpaper: File) = File(dir, wallpaper.name + ".png")

    fun cached(wallpaper: File): Bitmap? =
        cacheFile(wallpaper).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }

    suspend fun generate(wallpaper: File, source: Bitmap): Bitmap? = withContext(Dispatchers.Default) {
        val cut = SubjectSegmenter.cutout(source) ?: return@withContext null
        cacheFile(wallpaper).outputStream().use { cut.compress(Bitmap.CompressFormat.PNG, 100, it) }
        cut
    }
}
