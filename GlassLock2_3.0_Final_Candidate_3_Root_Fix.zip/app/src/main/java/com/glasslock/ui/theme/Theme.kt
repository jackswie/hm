package com.glasslock.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Ink {
    val primary = Color.White
    val secondary = Color.White.copy(alpha = 0.66f)
    val hairline = Color.White.copy(alpha = 0.18f)
}

@Composable
fun GlassLockTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color.White,
            onPrimary = Color.Black,
            background = Color.Black,
            surface = Color.Black,
            onSurface = Color.White,
        ),
        typography = Typography(),
        content = content,
    )
}
