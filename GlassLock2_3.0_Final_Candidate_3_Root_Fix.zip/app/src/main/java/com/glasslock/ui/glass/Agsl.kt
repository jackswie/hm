package com.glasslock.ui.glass

/**
 * Multi-sample optical lens shaders. The backdrop remains sharp and colourful through the body;
 * displacement, chromatic dispersion and a narrow Fresnel-like edge response create the glass rim.
 */
internal object Agsl {
    private const val COMMON = """
uniform shader content;
uniform shader reference;
uniform float uSourceMode;
uniform float uRefract;
uniform float uBand;
uniform float uDisp;

half4 shade(float2 p, float2 inward, float edge) {
    // A broad, soft lens shoulder plus a tighter bright bevel. Keep the centre almost untouched.
    float shoulder = smoothstep(0.0, 1.0, edge);
    float bevel = exp(-pow((1.0 - edge) * 5.0, 2.0));
    float2 tangent = float2(-inward.y, inward.x);
    float wave = sin(dot(p, tangent) * 0.035 + dot(p, inward) * 0.018);
    float2 bend = inward * (shoulder * uRefract * uBand * 0.72);
    bend += tangent * (wave * shoulder * uBand * 0.055);
    float2 split = inward * (bevel * uBand * uDisp * 2.2);

    half4 liveR = content.eval(p + bend + split);
    half4 liveG = content.eval(p + bend);
    half4 liveB = content.eval(p + bend - split);
    half4 refR = reference.eval(p + bend + split);
    half4 refG = reference.eval(p + bend);
    half4 refB = reference.eval(p + bend - split);
    half blend = half(clamp(uSourceMode, 0.0, 1.0));
    half3 liveCol = half3(liveR.r, liveG.g, liveB.b);
    half3 refCol = half3(refR.r, refG.g, refB.b);
    half3 col = mix(liveCol, refCol, blend);

    // Subtle edge caustic: brighter on the bevel, with a restrained cool/warm colour split.
    half3 cool = half3(0.72, 0.86, 1.0);
    half3 warm = half3(1.0, 0.91, 0.78);
    half3 glint = mix(cool, warm, half(clamp(0.5 + inward.x * 0.5, 0.0, 1.0)));
    col += glint * half(bevel * 0.105);
    col *= half(1.0 + shoulder * 0.025);
    return half4(col, 1.0);
}
"""

    const val ROUND_RECT = COMMON + """
uniform float2 uSize;
uniform float2 uOrigin;
uniform float uRadius;

float sdRoundRect(float2 p, float2 halfSize, float r) {
    float2 q = abs(p) - halfSize + float2(r);
    return min(max(q.x, q.y), 0.0) + length(max(q, float2(0.0))) - r;
}

half4 main(float2 frag) {
    float2 hs = uSize * 0.5;
    float2 p = frag - (uOrigin + hs);
    float d = sdRoundRect(p, hs, uRadius);
    float2 gr = float2(
        sdRoundRect(p + float2(1.0, 0.0), hs, uRadius) - sdRoundRect(p - float2(1.0, 0.0), hs, uRadius),
        sdRoundRect(p + float2(0.0, 1.0), hs, uRadius) - sdRoundRect(p - float2(0.0, 1.0), hs, uRadius));
    float gl = length(gr);
    float2 inward = gl > 0.0001 ? -gr / gl : float2(0.0);
    float edge = gl > 0.0001 ? 1.0 - clamp(-d / uBand, 0.0, 1.0) : 0.0;
    return shade(frag, inward, edge);
}
"""

    const val MASK = COMMON + """
uniform shader mask;

half4 main(float2 frag) {
    float2 g = float2(0.0);
    float cov = 0.0;
    for (int i = 0; i < 12; i++) {
        float a = 0.5235988 * float(i);
        float2 dir = float2(cos(a), sin(a));
        float s1 = mask.eval(frag + dir * uBand * 0.45).a;
        float s2 = mask.eval(frag + dir * uBand * 0.9).a;
        g += dir * (s1 + s2);
        cov += s1 + s2;
    }
    cov = cov / 24.0;
    float gl = length(g);
    float2 inward = gl > 0.0001 ? g / gl : float2(0.0);
    float edge = gl > 0.0001 ? 1.0 - smoothstep(0.42, 0.96, cov) : 0.0;
    return shade(frag, inward, edge);
}
"""
}
