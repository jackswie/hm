package com.glasslock.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

private val Presets = listOf(
    Color.White, Color(0xFF1C1C1E), Color(0xFF8E8E93), Color(0xFFFF453A),
    Color(0xFFFF9F0A), Color(0xFFFFD60A), Color(0xFF30D158), Color(0xFF64D2FF), Color(0xFF0A84FF), Color(0xFFBF5AF2),
)

/** Wallpaper-sampled swatches first, then system presets, then a full HSB wheel with a brightness slider. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ColorPickerSection(current: Color, wallpaperSwatches: List<Color>, onPick: (Color) -> Unit) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            (wallpaperSwatches + Presets).forEach { swatch ->
                val selected = swatch.toArgb() == current.toArgb()
                Box(
                    Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(swatch)
                        .border(if (selected) 3.dp else 1.dp, if (selected) Color.White else Color.White.copy(alpha = 0.35f), CircleShape)
                        .clickable { onPick(swatch) }
                )
            }
        }
        HsbWheel(current, onPick)
    }
}

@Composable
private fun HsbWheel(color: Color, onColor: (Color) -> Unit) {
    val initial = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(color.toArgb(), it) } }
    var hue by remember { mutableStateOf(initial[0]) }
    var sat by remember { mutableStateOf(initial[1]) }
    var value by remember { mutableStateOf(initial[2].coerceAtLeast(0.05f)) }

    fun emit() = onColor(Color(android.graphics.Color.HSVToColor(floatArrayOf(hue, sat, value))))

    fun pick(pos: Offset, size: Float) {
        val c = size / 2f
        val dx = pos.x - c
        val dy = pos.y - c
        hue = ((Math.toDegrees(atan2(dy, dx).toDouble()).toFloat()) + 360f) % 360f
        sat = (hypot(dx, dy) / c).coerceIn(0f, 1f)
        emit()
    }

    val hueColors = remember { List(7) { Color.hsv((it * 60f) % 360f, 1f, 1f) } }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp), horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Canvas(
            Modifier
                .size(180.dp)
                .pointerInput(Unit) { detectTapGestures { pick(it, size.width.toFloat()) } }
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { pick(it, size.width.toFloat()) },
                        onDrag = { change, _ -> change.consume(); pick(change.position, size.width.toFloat()) },
                    )
                }
        ) {
            val r = min(size.width, size.height) / 2f
            drawCircle(Brush.sweepGradient(hueColors, center), radius = r)
            drawCircle(Brush.radialGradient(listOf(Color.White, Color.White.copy(alpha = 0f)), center, r), radius = r)
            drawCircle(Color.Black.copy(alpha = 1f - value), radius = r)

            val a = Math.toRadians(hue.toDouble())
            val cursor = Offset(center.x + (cos(a) * sat * r).toFloat(), center.y + (sin(a) * sat * r).toFloat())
            drawCircle(Color.White, 11.dp.toPx(), cursor, style = Stroke(3.dp.toPx()))
            drawCircle(Color(android.graphics.Color.HSVToColor(floatArrayOf(hue, sat, value))), 8.dp.toPx(), cursor)
        }
        GlassSlider("Brightness", "${(value * 100).toInt()}%", value, 0f..1f) { value = it; emit() }
    }
}
