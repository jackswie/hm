package com.glasslock.ui.gallery

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.glasslock.data.model.LockProfile
import com.glasslock.ui.clock.wallpaperColorFilter
import com.glasslock.ui.editor.GlassPill
import com.glasslock.ui.glass.Palette
import com.glasslock.ui.theme.Ink
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Wallpaper gallery: a horizontal carousel of lock screens. Swipe sideways to switch, swipe a card up to delete it,
 * "+" adds a new one, "Focus" links a status label, "Customize" opens the full editor for the centred card.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GalleryOverlay(
    profiles: List<LockProfile>,
    activeId: String,
    thumbs: Map<String, ImageBitmap>,
    palette: Palette,
    timeText: String,
    onSelect: (String) -> Unit,
    onCustomize: () -> Unit,
    onAdd: () -> Unit,
    onDelete: (String) -> Unit,
    onFocus: (String) -> Unit,
    onSetup: () -> Unit,
    onDismiss: () -> Unit,
) {
    val pager = rememberPagerState(initialPage = profiles.indexOfFirst { it.id == activeId }.coerceAtLeast(0)) { profiles.size }
    val latestProfiles = rememberUpdatedState(profiles)
    val latestSelect = rememberUpdatedState(onSelect)
    LaunchedEffect(pager) {
        snapshotFlow { pager.settledPage }.collect { page -> latestProfiles.value.getOrNull(page)?.let { latestSelect.value(it.id) } }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background85()
            .pointerInput(Unit) { detectTapGestures { onDismiss() } }
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Row(Modifier.fillMaxWidth().padding(24.dp).align(Alignment.TopCenter), horizontalArrangement = Arrangement.SpaceBetween) {
            GlassPill("+", onAdd)
            Text("Lock Screens", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterVertically))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GlassPill("Setup", onSetup)
                GlassPill("Done", onDismiss)
            }
        }

        HorizontalPager(
            state = pager,
            contentPadding = PaddingValues(horizontal = 96.dp),
            pageSpacing = 28.dp,
            modifier = Modifier.align(Alignment.Center).fillMaxWidth().fillMaxHeight(0.7f),
        ) { page ->
            val p = profiles[page]
            ProfileCard(
                profile = p,
                thumb = thumbs[p.id],
                palette = palette,
                timeText = timeText,
                selected = p.id == activeId,
                canDelete = profiles.size > 1,
                onDelete = { onDelete(p.id) },
                onFocus = { onFocus(p.id) },
            )
        }

        GlassPill("Customize", onCustomize, Modifier.align(Alignment.BottomCenter).padding(bottom = 36.dp))
    }
}

private fun Modifier.background85(): Modifier = this.background(Color.Black.copy(alpha = 0.85f))

@Composable
private fun ProfileCard(
    profile: LockProfile,
    thumb: ImageBitmap?,
    palette: Palette,
    timeText: String,
    selected: Boolean,
    canDelete: Boolean,
    onDelete: () -> Unit,
    onFocus: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val y = remember { Animatable(0f) }
    val filter = remember(profile.wallpaper, palette) { wallpaperColorFilter(profile.wallpaper, palette) }

    Column(
        Modifier
            .offset { IntOffset(0, y.value.roundToInt()) }
            .graphicsLayer { alpha = 1f - (-y.value / 700f).coerceIn(0f, 1f) }
            .pointerInput(canDelete) {
                detectVerticalDragGestures(
                    onDragEnd = {
                        scope.launch {
                            if (canDelete && y.value < -220f) {
                                y.animateTo(-900f, tween(150))
                                onDelete()
                            } else y.animateTo(0f)
                        }
                    },
                    onDragCancel = { scope.launch { y.animateTo(0f) } },
                ) { c, d ->
                    c.consume()
                    scope.launch { y.snapTo((y.value + d).coerceAtMost(0f)) }
                }
            },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        val shape = RoundedCornerShape(28.dp)
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1.6f)
                .clip(shape)
                .border(if (selected) 3.dp else 0.dp, Color.White, shape)
                .pointerInput(Unit) { detectTapGestures { } },
            contentAlignment = Alignment.TopCenter,
        ) {
            if (thumb != null) Image(thumb, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, colorFilter = filter)
            Text(
                timeText, color = Color.White.copy(alpha = 0.75f), fontSize = 56.sp, fontWeight = FontWeight.Light,
                modifier = Modifier.padding(top = 18.dp),
            )
        }
        Text(profile.name, color = Ink.secondary, fontSize = 14.sp)
        GlassPill(
            if (profile.focusLabel.isBlank()) "Focus" else "${profile.focusEmoji} ${profile.focusLabel}".trim(),
            onFocus,
        )
    }
}
