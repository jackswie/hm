package com.glasslock.ui.setup

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import com.glasslock.service.LockPrefs
import com.glasslock.ui.editor.GlassPill
import com.glasslock.ui.editor.ToggleRow
import com.glasslock.ui.theme.Ink

/** What the app can currently do, re-read every time the screen resumes. */
data class SetupStatus(
    val overlay: Boolean,
    val listener: Boolean,
    val notifications: Boolean,
    val location: Boolean,
    val battery: Boolean,
    val lockEnabled: Boolean,
) {
    /** Needed before the lock replacement can be switched on. */
    val ready get() = overlay && listener

    companion object {
        fun read(c: Context): SetupStatus {
            val pm = c.getSystemService(PowerManager::class.java)
            return SetupStatus(
                overlay = Settings.canDrawOverlays(c),
                listener = NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName),
                notifications = android.os.Build.VERSION.SDK_INT < 33 ||
                    c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED,
                location = c.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED,
                battery = pm.isIgnoringBatteryOptimizations(c.packageName),
                lockEnabled = LockPrefs.isEnabled(c),
            )
        }
    }
}

/** Runtime-permission onboarding: overlay, notification access, notifications, location, battery. */
@Composable
fun SetupScreen(
    status: SetupStatus,
    onOverlay: () -> Unit,
    onListener: () -> Unit,
    onNotifications: () -> Unit,
    onLocation: () -> Unit,
    onBattery: () -> Unit,
    onToggleLock: (Boolean) -> Unit,
    onClose: () -> Unit,
) {
    Column(
        Modifier.fillMaxSize().background(Color(0xFF0B0D14)).verticalScroll(rememberScrollState()).padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Column(Modifier.widthIn(max = 560.dp)) {
            Text("Set up GlassLock", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text(
                "Android has no official way to replace the lock screen. GlassLock shows its screen above the system one, " +
                    "and your PIN, pattern or fingerprint is still checked by Android when you swipe up.",
                color = Ink.secondary, fontSize = 15.sp, modifier = Modifier.padding(top = 8.dp, bottom = 20.dp),
            )
            Step("Display over other apps", "Lets the lock screen appear when the screen wakes.", status.overlay, "Allow", onOverlay, required = true)
            Step("Notification access", "Mirrors notifications and the current song onto the lock screen.", status.listener, "Allow", onListener, required = true)
            Step("Show service notice", "Android needs a quiet notice while the lock service runs.", status.notifications, "Allow", onNotifications)
            Step("Location (weather widget)", "Approximate location only.", status.location, "Allow", onLocation)
            Step("Keep running in background", "Stops battery saver from closing the lock service.", status.battery, "Allow", onBattery)

            Spacer(Modifier.height(16.dp))
            Column(Modifier.clip(RoundedCornerShape(20.dp)).background(Color.White.copy(alpha = 0.08f)).padding(16.dp)) {
                ToggleRow(
                    label = "Use GlassLock as my lock screen",
                    checked = status.lockEnabled,
                    enabled = status.ready,
                    note = if (status.ready) "Turns on when the screen next switches off." else "Finish the first two steps to enable.",
                    onChecked = onToggleLock,
                )
            }
            Spacer(Modifier.height(20.dp))
            GlassPill("Continue", onClose, Modifier.align(Alignment.CenterHorizontally))
        }
    }
}

@Composable
private fun Step(title: String, text: String, done: Boolean, action: String, onClick: () -> Unit, required: Boolean = false) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp).clip(RoundedCornerShape(18.dp))
            .background(Color.White.copy(alpha = 0.08f)).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Text(title + if (required) "  ·  required" else "", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(text, color = Ink.secondary, fontSize = 13.sp)
        }
        if (done) Text("✓", color = Color(0xFF34C759), fontSize = 22.sp, fontWeight = FontWeight.Bold)
        else GlassPill(action, onClick)
    }
}

fun overlaySettingsIntent(c: Context) = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${c.packageName}"))
fun batterySettingsIntent(c: Context) = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${c.packageName}"))
