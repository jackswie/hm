Clock fonts (variable, loaded by ClockFonts.kt). Missing files fall back to system fonts.

  clock_sans.otf           SF Numeric          (also used, narrowed, for "Condensed")
  clock_rounded.otf        SF Rounded Numeric
  clock_serif.otf          New York Numeric
  clock_slab.otf           ADT Slab Numeric
  clock_stencil.otf        SF Stencil Numeric
  clock_rails.otf          SF Rail Numeric
  clock_sf_soft.otf        SF Soft Numeric
  clock_rails_rounded.otf  SF Rail Rounded Numeric
  clock_serif_soft.otf     New York Soft Numeric
  clock_slab_soft.otf      ADT Slab Soft Numeric
  clock_adaptive.otf       SF Adaptive Numeric
  clock_adaptive_soft.otf  SF Adaptive Soft Numeric
