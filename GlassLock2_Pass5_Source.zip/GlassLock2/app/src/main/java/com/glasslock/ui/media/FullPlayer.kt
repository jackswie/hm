package com.glasslock.ui.media

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.glasslock.data.model.GlassStyle
import com.glasslock.ui.clock.ClockPlacement

/**
 * Apple-style full-screen Now Playing, drawn over the album wallpaper and under the (smaller) clock:
 * big rounded cover with a soft shadow (it shrinks while paused, like iOS), and the glass player card.
 * Portrait: cover above the card. Landscape: cover on the left, card on the right.
 * Tap anywhere else to go back.
 */
@Composable
fun BoxScope.FullPlayer(
    np: NowPlaying,
    style: GlassStyle,
    placement: ClockPlacement,
    notificationCount: Int,
    onClose: () -> Unit,
    onOutput: () -> Unit,
) {
    val art = remember(np.art) { np.art?.asImageBitmap() } ?: return
    val density = LocalDensity.current
    val landscape = placement.screen.width >= placement.screen.height
    val topPad = with(density) { (placement.box.bottom + 12.dp.toPx()).toDp() }
    val scale by animateFloatAsState(
        targetValue = if (np.isPlaying) 1f else 0.84f,
        animationSpec = spring(dampingRatio = 0.7f, stiffness = 300f),
        label = "coverScale",
    )

    // Tap-outside-to-close layer; everything below sits above it.
    Box(
        Modifier
            .fillMaxSize()
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClose)
    )

    if (!landscape) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(top = topPad, bottom = 120.dp, start = 22.dp, end = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                CoverArt(art, minOf(maxWidth, maxHeight), scale)
            }
            Spacer(Modifier.height(14.dp))
            NowPlayingCard(
                np = np, style = style, interactive = true,
                onDismiss = onClose, onOutput = onOutput, onEditTap = {},
                expanded = true,
            )
        }
    } else {
        Row(
            Modifier
                .fillMaxSize()
                .padding(top = topPad, bottom = 110.dp, start = 64.dp, end = 64.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BoxWithConstraints(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                CoverArt(art, minOf(maxWidth, maxHeight), scale)
            }
            Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                NowPlayingCard(
                    np = np, style = style, interactive = true,
                    onDismiss = onClose, onOutput = onOutput, onEditTap = {},
                    expanded = true,
                )
            }
        }
    }

    if (notificationCount > 0) {
        Text(
            "●  $notificationCount Notifications",
            color = Color.White.copy(alpha = 0.85f),
            fontSize = 15.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 44.dp),
        )
    }
}

@Composable
private fun CoverArt(art: ImageBitmap, side: Dp, scale: Float) {
    val shape = RoundedCornerShape(26.dp)
    Image(
        art, null,
        Modifier
            .size(side)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .shadow(28.dp, shape, clip = false, ambientColor = Color.Black.copy(alpha = 0.4f), spotColor = Color.Black.copy(alpha = 0.5f))
            .clip(shape),
        contentScale = ContentScale.Crop,
    )
}
