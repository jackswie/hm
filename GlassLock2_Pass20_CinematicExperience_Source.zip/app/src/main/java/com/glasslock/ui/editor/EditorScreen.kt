package com.glasslock.ui.editor

import android.graphics.Bitmap

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.glasslock.data.model.GlassStyle
import com.glasslock.data.model.GlassMode
import com.glasslock.data.model.GlassAppearance
import com.glasslock.service.LockNotification
import com.glasslock.service.NotificationRepository
import com.glasslock.ui.LocalAppActions
import com.glasslock.ui.clock.ClockPlacement
import com.glasslock.ui.clock.ClockText
import com.glasslock.ui.clock.DepthLockScene
import com.glasslock.ui.clock.rememberNow
import com.glasslock.ui.gallery.GalleryOverlay
import com.glasslock.ui.glass.GlassGeometry
import com.glasslock.ui.glass.liquidGlass
import com.glasslock.data.model.WallpaperConfig
import com.glasslock.ui.media.AlbumBackdrop
import com.glasslock.ui.media.FullPlayer
import com.glasslock.ui.media.MediaRepository
import com.glasslock.ui.media.NowPlaying
import com.glasslock.ui.media.NowPlayingCard
import com.glasslock.ui.notifications.NotificationStack
import com.glasslock.ui.theme.Ink
import com.glasslock.ui.widgets.DateHeader
import com.glasslock.ui.widgets.HomeIndicator
import com.glasslock.ui.widgets.QuickActionButton
import com.glasslock.ui.widgets.StatusBar
import com.glasslock.ui.widgets.StatusPill
import com.glasslock.ui.widgets.WidgetRail
import com.glasslock.ui.widgets.WidgetRow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * The lock screen and its editor, shared by the app ([lockMode] = false) and the real lock window ([lockMode] = true).
 *
 * App: long-press opens the wallpaper gallery. Editing: tap any element to configure it, drag widgets to snap them
 * to the grid, drag the clock's corner handle to resize, pinch to zoom the wallpaper, swipe sideways to change filter.
 * Lock: swipe up from the bottom edge to unlock; long-press hands over to the app's gallery.
 */
@Composable
fun EditorScreen(
    vm: EditorViewModel,
    lockMode: Boolean = false,
    lockResetKey: Int = 0,
    onPickPhoto: () -> Unit = {},
    onUnlock: () -> Unit = {},
    onCustomizeFromLock: () -> Unit = {},
) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val time by rememberNow()
    val media by MediaRepository.state.collectAsStateWithLifecycle()
    val hasMediaAccess by MediaRepository.hasAccess.collectAsStateWithLifecycle()
    val notifications by NotificationRepository.state.collectAsStateWithLifecycle()
    val actions = LocalAppActions.current
    val scope = rememberCoroutineScope()
    var artOpen by remember { mutableStateOf(false) }
    val unlockY = remember(lockResetKey) { Animatable(0f) }
    val wallpaper = ui.wallpaper

    if (wallpaper == null) {
        Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Color.White)
        }
        return
    }

    LaunchedEffect(ui.notice) {
        if (ui.notice != null) {
            delay(3000)
            vm.clearNotice()
        }
    }

    val profile = ui.profile
    val editing = ui.editing && !lockMode

    // ---- what the mini player shows, and the full-screen album player (Apple-style) ----
    val shown: NowPlaying? = when {
        media.hasSession && media.key != ui.dismissedMediaKey -> media
        editing && !media.hasSession -> NowPlaying.Sample
        else -> null
    }
    LaunchedEffect(shown == null) { if (shown == null) artOpen = false }

    // Media sessions often publish a metadata frame with no artwork between tracks. Keep the
    // last good bitmap while the next one arrives so album mode never drops back to the wallpaper.
    var retainedAlbumArt by remember { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(media.art) { media.art?.let { retainedAlbumArt = it } }
    val screenCfg = LocalConfiguration.current
    val screenLandscape = screenCfg.screenWidthDp >= screenCfg.screenHeightDp
    // The edit bar can open a live album-layout preview even without a media session; the
    // current wallpaper becomes a temporary cover so layout and tap targets remain editable.
    val albumArtwork = retainedAlbumArt ?: if (editing && artOpen) wallpaper.asAndroidBitmap() else null
    val musicMode = artOpen && shown != null && albumArtwork != null

    // Rendering the blurred album backdrop is CPU work. Build it off the UI thread and retain
    // the previous backdrop until the replacement is ready (no black/main-screen flash).
    var album by remember { mutableStateOf<AlbumBackdrop?>(null) }
    LaunchedEffect(albumArtwork, screenLandscape, musicMode) {
        val source = albumArtwork
        if (musicMode && source != null) {
            val next = withContext(Dispatchers.Default) { AlbumBackdrop.render(source, screenLandscape) }
            if (next != null) album = next
        }
    }
    val albumActive = musicMode && album != null

    val wallpaperGestures = if (editing) {
        Modifier.pointerInput(Unit) {
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed = false)
                var totalDx = 0f
                var multi = false
                do {
                    val event = awaitPointerEvent()
                    if (event.changes.count { it.pressed } >= 2) {
                        multi = true
                        val pan = event.calculatePan()
                        vm.transformWallpaper(event.calculateZoom(), pan.x / size.width, pan.y / size.height)
                        event.changes.forEach { it.consume() }
                    } else if (!multi) {
                        totalDx += event.changes.first().positionChange().x
                    }
                } while (event.changes.any { it.pressed })
                if (!multi && abs(totalDx) > 160f) vm.cycleFilter(if (totalDx < 0) 1 else -1)
            }
        }
    } else Modifier

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    // Swipe-up unlock: the whole screen follows the finger, fades and shrinks slightly.
                    val p = (-unlockY.value / size.height).coerceIn(0f, 1f)
                    translationY = unlockY.value
                    alpha = 1f - p * 0.7f
                    scaleX = 1f - p * 0.05f
                    scaleY = 1f - p * 0.05f
                }
                .pointerInput(editing, ui.galleryOpen, lockMode) {
                    if (!editing && !ui.galleryOpen) {
                        detectTapGestures(onLongPress = { if (lockMode) onCustomizeFromLock() else vm.openGallery() })
                    }
                }
        ) {
            DepthLockScene(
                wallpaper = if (albumActive) album!!.image else wallpaper,
                cutout = if (albumActive) null else ui.cutout,
                wallpaperConfig = if (albumActive) WallpaperConfig() else profile.wallpaper,
                // Album mode draws its clock in the right-hand player column instead of the wallpaper clock layer.
                clock = if (albumActive) {
                    profile.clock.copy(
                        heightFraction = 0.12f,
                        widthFraction = 0.58f,
                        keepAspectRatio = true,
                        // The wallpaper clock is suppressed in album mode; FullPlayer owns its clock placement.
                        topFraction = 0.79f,
                        depthEffect = false,
                    )
                } else profile.clock,
                palette = if (albumActive) album!!.palette else ui.palette,
                time = time,
                onClockClick = if (editing) ({ vm.openSheet(Sheet.Clock) }) else null,
                wallpaperGestures = wallpaperGestures,
                renderClock = !albumActive,
            ) { placement ->
                val density = LocalDensity.current
                val landscape = placement.screen.width >= placement.screen.height

                StatusBar(Modifier.align(Alignment.TopEnd).windowInsetsPadding(WindowInsets.safeDrawing))

                if (lockMode) {
                    Text(
                        "🔒  Swipe up to unlock", color = Color.White, fontSize = 15.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.align(Alignment.TopCenter).windowInsetsPadding(WindowInsets.safeDrawing).padding(top = 12.dp),
                    )
                }

                if (!albumActive) DateHeader(
                    inline = profile.inlineText,
                    modifier = Modifier
                        .offset { IntOffset(placement.box.left.roundToInt(), (placement.box.top - 40.dp.toPx()).roundToInt()) }
                        .width(with(density) { placement.box.width.toDp() })
                        .then(if (editing) Modifier.clickable { vm.openSheet(Sheet.Status) } else Modifier),
                )

                // ---- widgets ----
                if (albumActive) {
                    // the album player takes over the middle of the screen
                } else if (landscape) {
                    // The widget rail belongs to the tablet layout, not the clock bounds.
                    // Deriving this from placement.box.left made tiles grow whenever the clock narrowed.
                    val railW = with(density) { (placement.screen.width * 0.22f).coerceIn(176.dp.toPx(), 300.dp.toPx()).toDp() }
                    val availH = with(density) { (placement.screen.height - 120.dp.toPx() - 110.dp.toPx()).coerceAtLeast(0f).toDp() }
                    WidgetRail(
                        widgets = profile.widgets,
                        editing = editing,
                        selectedId = (ui.sheet as? Sheet.Widget)?.id,
                        railWidth = railW,
                        availableHeight = availH,
                        onRows = vm::setGridRows,
                        onMove = vm::moveWidget,
                        onTap = { vm.openSheet(Sheet.Widget(it)) },
                        modifier = Modifier.offset(16.dp, 64.dp),
                    )
                } else {
                    WidgetRow(
                        widgets = profile.widgets,
                        editing = editing,
                        selectedId = (ui.sheet as? Sheet.Widget)?.id,
                        onTap = { vm.openSheet(Sheet.Widget(it)) },
                        modifier = Modifier.offset { IntOffset(0, (placement.box.bottom + 24.dp.toPx()).roundToInt()) },
                    )
                }

                // ---- notifications (bottom) + media card and focus pill (above them) ----
                val shownNotifs: List<LockNotification> = when {
                    lockMode -> notifications
                    editing -> listOf(LockNotification.Sample)
                    else -> emptyList()
                }
                // Media sizing is anchored to the screen, never to the independently resizable clock.
                val mediaWidthPx = if (landscape) placement.screen.width * 0.34f else placement.screen.width * 0.88f
                val cardW = with(density) { minOf(440.dp.toPx(), mediaWidthPx).toDp() }
                if (!albumActive) Column(
                    Modifier
                        .offset {
                            val top = if (shownNotifs.isNotEmpty()) 0.50f else 0.66f
                            IntOffset((placement.box.center.x - cardW.toPx() / 2f).roundToInt(), (placement.screen.height * top).roundToInt())
                        }
                        .width(cardW),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    if (shown != null) {
                        NowPlayingCard(
                            np = shown,
                            style = profile.mediaStyle,
                            interactive = !editing,
                            onDismiss = { vm.dismissMedia(shown.key) },
                            onOutput = { outputSwitcher(actions.launch) },
                            onEditTap = { vm.openSheet(Sheet.Media) },
                            onArtClick = { artOpen = true },
                        )
                    } else if (!hasMediaAccess && !editing && !lockMode) {
                        EnableMediaCard(actions.openNotificationAccess)
                    }
                    val pill = if (profile.focusLabel.isNotBlank()) "${profile.focusEmoji} ${profile.focusLabel}".trim() else profile.statusText
                    if (pill.isNotBlank()) {
                        StatusPill(pill, Modifier.padding(top = 10.dp).then(if (editing) Modifier.clickable { vm.openSheet(Sheet.Status) } else Modifier))
                    }
                }

                if (shownNotifs.isNotEmpty() && !albumActive) {
                    NotificationStack(
                        items = shownNotifs.take(profile.notificationLimit),
                        style = profile.notificationStyle,
                        interactive = !editing,
                        onOpen = { n -> actions.unlockThen { runCatching { n.intent?.send() }; NotificationRepository.remove(n.key) } },
                        onDismiss = { n -> NotificationRepository.dismiss(n.key) },
                        onEditTap = { vm.openSheet(Sheet.Notifications) },
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .offset { IntOffset((placement.box.center.x - cardW.toPx() / 2f).roundToInt(), -64.dp.roundToPx()) }
                            .width(cardW),
                    )
                }

                androidx.compose.animation.AnimatedVisibility(
                    visible = albumActive && shown != null,
                    enter = fadeIn(tween(350)) + scaleIn(tween(350), initialScale = 0.94f),
                    exit = fadeOut(tween(200)),
                ) {
                    if (shown != null) {
                        Box(Modifier.fillMaxSize()) {
                            FullPlayer(
                                np = shown,
                                artwork = albumArtwork,
                                style = profile.mediaStyle,
                                placement = placement,
                                clockText = ClockText.format(time, profile.albumClock.use24Hour),
                                clockConfig = profile.albumClock,
                                notifications = if (editing && notifications.isEmpty()) listOf(LockNotification.Sample) else notifications,
                                notificationStyle = profile.notificationStyle,
                                onNotificationOpen = { n -> actions.unlockThen { runCatching { n.intent?.send() }; NotificationRepository.remove(n.key) } },
                                onNotificationDismiss = { n -> NotificationRepository.dismiss(n.key) },
                                onClose = { artOpen = false },
                                onEditClock = { if (!lockMode) vm.openSheet(Sheet.AlbumClock) },
                                showEditHint = !lockMode,
                                editing = editing,
                                blendPlayerBackground = profile.albumPlayerBlend,
                                artworkStyle = profile.albumArtworkStyle,
                                notificationLimit = profile.notificationLimit,
                                onEditMedia = { if (editing) vm.openSheet(Sheet.Media) },
                                onEditNotifications = { if (editing) vm.openSheet(Sheet.Notifications) },
                                onOutput = { outputSwitcher(actions.launch) },
                            )
                        }
                    }
                }

                QuickActionButton(
                    profile.quickLeft, editing, { vm.openSheet(Sheet.Quick(true)) },
                    Modifier.align(Alignment.BottomStart).padding(start = 28.dp, bottom = 28.dp),
                )
                QuickActionButton(
                    profile.quickRight, editing, { vm.openSheet(Sheet.Quick(false)) },
                    Modifier.align(Alignment.BottomEnd).padding(end = 28.dp, bottom = 28.dp),
                )
                HomeIndicator(Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp))

                // Swipe-up unlock strip along the bottom edge (lock window only).
                if (lockMode) {
                    var lastDy by remember { mutableStateOf(0f) }
                    Box(
                        Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .height(96.dp)
                            .pointerInput(lockResetKey) {
                                detectVerticalDragGestures(
                                    onDragEnd = {
                                        scope.launch {
                                            val travelled = -unlockY.value
                                            if (travelled > placement.screen.height * 0.18f || lastDy < -22f) {
                                                unlockY.animateTo(-placement.screen.height, tween(220))
                                                onUnlock()
                                            } else {
                                                unlockY.animateTo(0f, spring(dampingRatio = 0.6f, stiffness = 300f))
                                            }
                                        }
                                    },
                                    onDragCancel = { scope.launch { unlockY.animateTo(0f, spring(dampingRatio = 0.6f)) } },
                                ) { change, dy ->
                                    change.consume()
                                    lastDy = dy
                                    // Gentle resistance when dragging down, direct follow when dragging up.
                                    val next = unlockY.value + if (dy > 0) dy * 0.3f else dy
                                    scope.launch { unlockY.snapTo(next.coerceAtMost(0f)) }
                                }
                            }
                    )
                }

                if (!editing && !lockMode) {
                    Text(
                        "Touch and hold to open the gallery",
                        color = Ink.secondary, fontSize = 13.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 30.dp),
                    )
                }
                if (editing) {
                    SelectionFrame(placement)
                    ResizeHandle(placement) { dx, dy ->
                        val heroWidth = placement.screen.width * if (landscape) 0.56f else 0.90f
                        vm.resizeClockWidth(dx / heroWidth)
                        vm.resizeClock(dy / placement.screen.height)
                    }
                    EditTopBar(
                        onCancel = vm::cancelEdit,
                        onDone = vm::finishEdit,
                        onWallpaper = { vm.openSheet(Sheet.Wallpaper) },
                        onAdd = { vm.openSheet(Sheet.AddWidget) },
                        onScenes = { vm.openSheet(Sheet.Scenes) },
                        albumPreview = artOpen,
                        onAlbumPreview = { artOpen = !artOpen },
                    )
                }

                // ---- gallery ----
                AnimatedVisibility(
                    visible = ui.galleryOpen && !lockMode,
                    enter = fadeIn(tween(220)) + scaleIn(tween(300), initialScale = 1.35f),
                    exit = fadeOut(tween(180)) + scaleOut(tween(220), targetScale = 1.35f),
                ) {
                    GalleryOverlay(
                        profiles = ui.profiles,
                        activeId = profile.id,
                        thumbs = ui.thumbs,
                        palette = ui.palette,
                        timeText = ClockText.format(time, profile.clock.use24Hour),
                        onSelect = vm::selectProfile,
                        onCustomize = vm::startEdit,
                        onAdd = { vm.openSheet(Sheet.NewProfile) },
                        onDelete = vm::deleteProfile,
                        onFocus = { vm.openSheet(Sheet.Focus(it)) },
                        onSetup = actions.openSetup,
                        onDismiss = vm::closeGallery,
                    )
                }

                // ---- sheets (always last so they sit above everything) ----
                if (ui.sheet != Sheet.None && !lockMode) {
                    Box(
                        Modifier.fillMaxSize()
                            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { vm.closeSheet() }
                    )
                    SheetHost(ui, vm, onPickPhoto)
                }

                ui.notice?.let { StatusPill(it, Modifier.align(Alignment.TopCenter).padding(top = 90.dp)) }
            }
        }
    }
}

@Composable
private fun BoxScope.SheetHost(ui: EditorUiState, vm: EditorViewModel, onPickPhoto: () -> Unit) {
    val profile = ui.profile
    val mod = Modifier
        .align(Alignment.CenterEnd)
        .windowInsetsPadding(WindowInsets.safeDrawing)
        .padding(end = 24.dp, top = 56.dp)

    when (val sheet = ui.sheet) {
        Sheet.None -> Unit
        Sheet.Clock -> ClockPopover(profile.clock, ui.palette, ui.cutout != null, ui.segmenting, vm::updateClock, vm::closeSheet, mod)
        Sheet.AlbumClock -> ClockPopover(profile.albumClock, ui.palette, false, false, vm::updateAlbumClock, vm::closeSheet, mod, title = "Album Clock")
        Sheet.AddWidget -> AddWidgetSheet(vm::addWidget, vm::closeSheet, mod)
        Sheet.Media -> MediaSheet(profile.mediaStyle, ui.palette, profile.albumPlayerBlend, profile.albumArtworkStyle, vm::setAlbumPlayerBlend, vm::setAlbumArtworkStyle, vm::updateMediaStyle, vm::closeSheet, mod)
        Sheet.Notifications -> NotificationSheet(profile.notificationStyle, ui.palette, profile.notificationLimit, vm::setNotificationLimit, vm::updateNotificationStyle, vm::closeSheet, mod)
        Sheet.Status -> StatusSheet(profile.statusText, profile.inlineText, vm::setStatusText, vm::setInlineText, vm::closeSheet, mod)
        Sheet.Wallpaper -> WallpaperSheet(profile.wallpaper, ui.palette, vm::updateWallpaper, onPickPhoto, vm::resetWallpaperView, vm::closeSheet, mod)
        Sheet.Scenes -> SceneSheet({ preset -> vm.applyScenePreset(preset); vm.closeSheet() }, vm::closeSheet, mod)
        Sheet.NewProfile -> NewProfileSheet({ kind -> if (vm.addProfile(kind)) onPickPhoto() }, vm::closeSheet, mod)
        is Sheet.Focus -> ui.profiles.firstOrNull { it.id == sheet.profileId }?.let { p ->
            FocusSheet(p.focusEmoji, p.focusLabel, { e, l -> vm.setFocus(p.id, e, l) }, vm::closeSheet, mod)
        }
        is Sheet.Quick -> QuickActionSheet(
            cfg = if (sheet.left) profile.quickLeft else profile.quickRight,
            title = if (sheet.left) "Left Button" else "Right Button",
            palette = ui.palette,
            onChange = { f -> vm.updateQuick(sheet.left, f) },
            onDismiss = vm::closeSheet,
            modifier = mod,
        )
        is Sheet.Widget -> profile.widgets.firstOrNull { it.id == sheet.id }?.let { w ->
            WidgetSheet(
                cfg = w,
                palette = ui.palette,
                onChange = { f -> vm.updateWidget(w.id, f) },
                onResize = { vm.resizeWidget(w.id, it) },
                onDelete = { vm.deleteWidget(w.id) },
                onDismiss = vm::closeSheet,
                modifier = mod,
            )
        }
    }
}

private fun outputSwitcher(launch: (android.content.Intent) -> Unit) {
    // Android's media-output panel; MainActivity/LockActivity fall back to Bluetooth settings if it is missing.
    launch(android.content.Intent("com.android.settings.panel.action.MEDIA_OUTPUT").putExtra("com.android.settings.panel.extra.PACKAGE_NAME", ""))
}

@Composable
private fun EnableMediaCard(onEnable: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .liquidGlass(GlassGeometry.Rounded(28.dp), GlassStyle(intensity = 0.5f))
            .clickable(onClick = onEnable)
            .padding(18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("♪  Show what's playing: tap to allow notification access", color = Color.White, fontSize = 14.sp)
    }
}

@Composable
private fun BoxScope.EditTopBar(onCancel: () -> Unit, onDone: () -> Unit, onWallpaper: () -> Unit, onAdd: () -> Unit, onScenes: () -> Unit, albumPreview: Boolean, onAlbumPreview: () -> Unit) {
    Box(
        Modifier
            .align(Alignment.TopCenter)
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 24.dp, vertical = 12.dp)
    ) {
        GlassPill("Cancel", onCancel, Modifier.align(Alignment.CenterStart))
        Row(Modifier.align(Alignment.Center)) {
            GlassPill("Wallpaper", onWallpaper)
            GlassPill("+ Widget", onAdd, Modifier.padding(start = 12.dp))
            GlassPill("Scenes", onScenes, Modifier.padding(start = 12.dp))
            GlassPill(if (albumPreview) "Lock Preview" else "Album Preview", onAlbumPreview, Modifier.padding(start = 12.dp))
        }
        GlassPill("Done", onDone, Modifier.align(Alignment.CenterEnd))
    }
}

/** Dashed outline around the digits so the tappable clock is obvious while editing. */
@Composable
private fun SelectionFrame(placement: ClockPlacement) {
    val density = LocalDensity.current
    val r = placement.drawn
    Canvas(
        Modifier
            .offset { IntOffset(r.left.roundToInt(), r.top.roundToInt()) }
            .size(with(density) { r.width.toDp() }, with(density) { r.height.toDp() })
    ) {
        drawRoundRect(
            color = Color.White.copy(alpha = 0.7f),
            cornerRadius = CornerRadius(18.dp.toPx()),
            style = Stroke(width = 2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 12f))),
        )
    }
}

private val HandleStyle = GlassStyle(intensity = 0.4f)

/** Bottom-right free-transform handle: horizontal and vertical movement resize independently. */
@Composable
private fun ResizeHandle(placement: ClockPlacement, onDrag: (Float, Float) -> Unit) {
    val density = LocalDensity.current
    val sizeDp = 44.dp
    val half = with(density) { sizeDp.toPx() / 2f }
    val latest by rememberUpdatedState(onDrag)

    Box(
        Modifier
            .offset { IntOffset((placement.drawn.right - half).roundToInt(), (placement.drawn.bottom - half).roundToInt()) }
            .size(sizeDp)
            .liquidGlass(GlassGeometry.Rounded(22.dp), HandleStyle)
            .pointerInput(Unit) {
                detectDragGestures { change, drag ->
                    change.consume()
                    latest(drag.x, drag.y)
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(18.dp)) {
            val w = 2.2.dp.toPx()
            val a = Offset(size.width * 0.15f, size.height * 0.85f)
            val b = Offset(size.width * 0.85f, size.height * 0.15f)
            drawLine(Color.White, a, b, w, StrokeCap.Round)
            drawLine(Color.White, b, Offset(b.x, size.height * 0.5f), w, StrokeCap.Round)
            drawLine(Color.White, b, Offset(size.width * 0.5f, b.y), w, StrokeCap.Round)
        }
    }
}
