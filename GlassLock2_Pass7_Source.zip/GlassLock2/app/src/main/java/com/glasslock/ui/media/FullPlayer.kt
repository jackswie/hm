package com.glasslock.ui.media

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.glasslock.data.model.GlassStyle
import com.glasslock.service.LockNotification
import com.glasslock.ui.clock.ClockPlacement
import com.glasslock.ui.notifications.NotificationStack

/**
 * Album mode for tablets. Artwork occupies the left half; the right column is deliberately ordered
 * clock -> playback controls -> notifications. Each region has its own constraints and entrance
 * motion, so resizing the lock-screen clock cannot affect this layout.
 */
@Composable
fun BoxScope.FullPlayer(
    np: NowPlaying,
    style: GlassStyle,
    placement: ClockPlacement,
    clockText: String,
    notifications: List<LockNotification>,
    notificationStyle: GlassStyle,
    onNotificationOpen: (LockNotification) -> Unit,
    onNotificationDismiss: (LockNotification) -> Unit,
    onClose: () -> Unit,
    onOutput: () -> Unit,
) {
    val art = remember(np.art) { np.art?.asImageBitmap() } ?: return
    val landscape = placement.screen.width >= placement.screen.height
    val scale by animateFloatAsState(
        targetValue = if (np.isPlaying) 1f else 0.985f,
        animationSpec = spring(dampingRatio = 0.78f, stiffness = 260f),
        label = "albumCoverScale",
    )

    // Background dismiss target; interactive content is composed above it.
    Box(
        Modifier.fillMaxSize().clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null,
            onClick = onClose,
        )
    )

    if (landscape) {
        Row(
            Modifier.fillMaxSize().padding(start = 54.dp, end = 54.dp, top = 66.dp, bottom = 92.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(48.dp),
        ) {
            BoxWithConstraints(Modifier.weight(1.08f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                CoverArt(art, minOf(maxWidth, maxHeight) * 0.94f, scale)
            }
            Column(
                Modifier.weight(0.92f).fillMaxHeight().padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                AnimatedVisibility(
                    visible = true,
                    enter = fadeIn(tween(380, delayMillis = 80)) + slideInVertically(animationSpec = tween(440, delayMillis = 80), initialOffsetY = { it / 5 }),
                ) {
                    Text(
                        clockText,
                        color = Color.White,
                        fontSize = 76.sp,
                        lineHeight = 80.sp,
                        fontWeight = FontWeight.Light,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.graphicsLayer { alpha = 0.98f },
                    )
                }
                Spacer(Modifier.height(16.dp))
                AnimatedVisibility(
                    visible = true,
                    enter = fadeIn(tween(400, delayMillis = 160)) + slideInVertically(animationSpec = tween(460, delayMillis = 160), initialOffsetY = { it / 5 }),
                ) {
                    NowPlayingCard(
                        np = np, style = style, interactive = true,
                        onDismiss = onClose, onOutput = onOutput, onEditTap = {},
                        expanded = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                AnimatedVisibility(
                    visible = notifications.isNotEmpty(),
                    enter = fadeIn(tween(360, delayMillis = 240)) + slideInVertically(animationSpec = tween(420, delayMillis = 240), initialOffsetY = { -it / 3 }),
                ) {
                    Column(Modifier.fillMaxWidth().padding(top = 14.dp)) {
                        NotificationStack(
                            items = notifications.take(3), style = notificationStyle,
                            interactive = true, onOpen = onNotificationOpen,
                            onDismiss = onNotificationDismiss, onEditTap = {},
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }
        }
    } else {
        Column(
            Modifier.fillMaxSize().padding(start = 22.dp, end = 22.dp, top = 54.dp, bottom = 92.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                CoverArt(art, minOf(maxWidth, maxHeight) * 0.82f, scale)
            }
            AnimatedVisibility(visible = true, enter = fadeIn(tween(380, delayMillis = 80)) + slideInVertically(initialOffsetY = { it / 5 })) {
                Text(clockText, color = Color.White, fontSize = 56.sp, fontWeight = FontWeight.Light)
            }
            AnimatedVisibility(visible = true, enter = fadeIn(tween(400, delayMillis = 160)) + slideInVertically(initialOffsetY = { it / 5 })) {
                NowPlayingCard(
                    np = np, style = style, interactive = true,
                    onDismiss = onClose, onOutput = onOutput, onEditTap = {},
                    expanded = true, modifier = Modifier.fillMaxWidth(),
                )
            }
            AnimatedVisibility(
                visible = notifications.isNotEmpty(),
                enter = fadeIn(tween(360, delayMillis = 240)) + slideInVertically(animationSpec = tween(420, delayMillis = 240), initialOffsetY = { -it / 3 }),
            ) {
                NotificationStack(
                    items = notifications.take(2), style = notificationStyle,
                    interactive = true, onOpen = onNotificationOpen,
                    onDismiss = onNotificationDismiss, onEditTap = {},
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}

@Composable
private fun CoverArt(art: ImageBitmap, side: Dp, scale: Float) {
    val shape = RoundedCornerShape(28.dp)
    Image(
        art, null,
        Modifier
            .size(side)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .shadow(30.dp, shape, clip = false, ambientColor = Color.Black.copy(alpha = 0.34f), spotColor = Color.Black.copy(alpha = 0.42f))
            .clip(shape),
        contentScale = ContentScale.Fit,
        filterQuality = FilterQuality.High,
    )
}
