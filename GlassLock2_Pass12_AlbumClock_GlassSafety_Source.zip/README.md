# GlassLock 2: Passes 1-3

Open the `GlassLock2` folder in Android Studio, let Gradle sync, run on a tablet or emulator (API 31+; refraction needs API 33+).
Long-press the screen to customise. Tap the clock for the popover, drag the corner handle to resize, "Photo" picks a wallpaper.

## Layout
    data/model   Models.kt (GlassStyle, ClockConfig, LockProfile...), ProfileStore.kt (DataStore + JSON)
    ui/glass     Agsl.kt (shaders) GlassBackdrop.kt (wallpaper capture) LiquidGlass.kt (the modifier)
                 TiltSensor.kt  WallpaperPalette.kt
    ui/clock     ClockFonts / ClockGeometry (digit outlines) / DepthLockScene (3 layers) / SubjectSegmenter (ML Kit) / Wallpaper
    ui/editor    EditorScreen, ClockPopover, GlassControls, ColorPicker, EditorViewModel
    ui/widgets   DateHeader, StatusPill, HomeIndicator (Pass 2 adds the widget grid + media player here)

## How the glass works
1. The wallpaper is recorded into one GraphicsLayer (`glassSource`).
2. Each glass surface redraws a shifted copy of it into its own padded layer.
3. RenderEffect chain on that layer: AGSL edge refraction + chromatic dispersion, then blur.
4. Compose draws saturation, frost, tint, a soft sheen and a 1dp inner rim (white 35% -> 5%) whose light direction follows accelerometer tilt.
   Tilt never re-runs the shaders; the blurred copy is cached until size, position or style changes.
Intensity 0% = nearly clear, strong refraction, bright rim. 100% = ~38dp blur, 26% frost, refraction hidden.
Clock digits use the MASK shader (edge normals estimated from a coverage mask); cards and pills use the exact rounded-rect SDF shader.
On API 31-32 the refraction step is skipped and blur/frost/tint/rim still render.

## Known limits
- SF Pro / New York are Apple-licensed; see app/src/main/assets/fonts/README.txt for OFL substitutes.
- ML Kit Subject Segmentation is built for people and objects. A skyline may be cut out only partly; the pipeline accepts any
  alpha cutout, so a different model can be swapped into SubjectSegmenter.cutout().
- Tilt uses the accelerometer only (gives the same rim motion as gyro with less code).

## Pass 2 additions
- ui/widgets: WidgetGrid (2-column rail, snap-to-grid drag, collision checks), BuiltInWidgets (analog clock with sweeping seconds,
  battery, month calendar, weather + sun arc, flip digital clock, quote, photo carousel, app shortcut), QuickActions (two corner buttons), StatusBar.
  Portrait reflows the same widgets into one horizontal row under the clock.
- ui/media + service: MediaRepository mirrors the active MediaSession; MediaListenerService authorises it. NowPlayingCard has art,
  title/artist, animated bars, seek slider, prev/play/next, output switcher and swipe-to-dismiss (audio keeps playing).
- Editing: long-press -> tap any element to configure it. "+ Widget" adds, the sheet resizes/removes. Weather uses Open-Meteo + coarse location.
- First run: tap the "Show what's playing" card to enable notification access, and tap the weather widget to allow location.
- Notifications on the lock screen, the real lock-screen window/service and the wallpaper gallery are Pass 3.

## Pass 3 additions
- Real lock window: LockService (foreground, SCREEN_ON/OFF) shows LockActivity above the system keyguard. Swipe up from the bottom edge
  (with fade/shrink and spring-back) calls KeyguardManager.requestDismissKeyguard, so Android still checks PIN/biometrics.
- Notifications: MediaListenerService mirrors them into Liquid Glass cards, grouped per app with peeking stacks. Tap expands a stack or opens
  a card (after unlock); swipe sideways dismisses and clears it from the system shade. Secret notifications are hidden, private ones show only the app name.
- Gallery: long-press (in the app) opens a carousel of lock screens. "+" adds Photo / Weather / Astronomy / Emoji / Color Gradient / Extended Photo,
  swipe a card up to delete, "Focus" links an icon + label to that lock screen, "Customize" opens the editor.
- Wallpaper editing: two-finger pinch/pan, swipe left/right for Natural / B&W / Duotone / Color Wash, plus Dim, Blur and Extend toggles.
- Setup screen: overlay permission, notification access, service notice, location, battery exemption, and the on/off switch for the lock replacement.
- Album art: tap the cover on the Now Playing card to see it enlarged; tap anywhere to close.

## Setup on a device
1. Install and open the app; follow the setup screen (the first two steps are required).
2. Turn on "Use GlassLock as my lock screen", then lock the device.
Uninstall or turn the switch off to get the stock lock screen back. If something goes wrong, boot to safe mode or use adb: `adb shell am force-stop com.glasslock`.

## Honest limits
- Android has no supported lock-screen replacement API. This overlay sits above the real keyguard; Android 14+ background-start rules, OEM battery managers
  and vendor skins can stop it appearing. Test on your tablet before relying on it.
- Weather / Astronomy wallpapers are generated pictures, not live data. "Extended Photo" is a blurred fill, not generative outpainting.
- Focus only changes the label in the pill; it does not toggle Do Not Disturb.
- Tilt uses the accelerometer. Nothing here was compiled or run in the build sandbox.


## Pass 4: clock proportions and depth-stack repair
- Added independent clock-canvas width and height controls in the Clock sheet. The width is a percentage of the available hero area; the height remains a percentage of screen height.
- Clock glyphs now scale uniformly to fit the selected bounds instead of being squeezed horizontally when the width is reduced. This keeps the numeral proportions intact at compact sizes.
- The depth compositor is retained as a true three-layer scene (wallpaper, clock, foreground subject). In the editor, the Depth Effect switch remains live and the subject cutout is drawn above the clock when segmentation is available.

## Pass 5 update (2026-11-18)

- Clock glyphs now use independent horizontal and vertical transforms, matching free-transform/photo-stretch behaviour. The width control reaches 8% of the available clock area.
- The compact album-player clock explicitly retains its original aspect ratio, so opening the album-art player does not squash the compact clock.
- Landscape widget-rail width is now derived from the tablet screen width, not the clock's left edge. Narrowing the clock can no longer enlarge the widget tiles.
- Replaced the simulated liquid/refraction material with a restrained translucent surface: subtle tint, tonal gradient and fine highlight. The old AGSL refraction/chromatic edge effect is no longer used by glass surfaces.
- Existing animation code and the wallpaper/depth subject compositor are retained.


## Pass 6 changes

- Restored the captured-wallpaper AGSL refraction path for Liquid Glass on Android 13+, with a restrained blur, edge lensing, subtle chromatic separation, tint and tilt-aware specular rim. Android 12 and shader failures use a graceful translucent fallback.
- Decoupled the now-playing card width from clock bounds; media sizing now follows the screen dimensions.
- Album-player mode reserves a lower band for the compact clock, removes the date header from the top, and keeps the expanded player clear of that lower clock area.
- Album art selection now prefers the largest artwork bitmap supplied by the active media session, and Compose renders it with high filter quality.
- Kept the outlined-font artifact as a low-priority follow-up; no font assets were altered in this pass.

This source archive has not been compiled or device-tested in this environment. Build it with the Android Gradle Plugin/SDK in Android Studio or GitHub Actions before installing.

## Pass 7: album mode hierarchy and transitions
- Album mode now suppresses the wallpaper clock layer and places a dedicated clock in the right-side player column.
- The album-mode order is clock, expanded playback card/transport controls, then up to three live notification stacks.
- Notifications use the existing notification interaction model (open after unlock, swipe to dismiss) in album mode.
- Album-mode player and notification surfaces explicitly request the Liquid/Clear material rather than inheriting an opaque Solid selection.
- Album artwork is rendered with high filter quality and `ContentScale.Fit` to preserve the complete cover without stretching or cropping it.
- Album mode keeps the artwork on the left and the independent clock/player/notification column on the right in landscape; portrait reflows vertically.
- Added delayed slide/fade entrance for notifications; existing album overlay spring/fade transition and cover-scale response remain.

Build status: source edits only. This environment does not have a Gradle executable, Gradle wrapper JAR, Android SDK, or connected Lenovo device, so this pass has not been compiled or device-tested. Run the repository's GitHub Actions Android build before installing.

## Pass 8 — seamless track changes

- Album mode now retains the last valid artwork while a media session briefly publishes metadata without a bitmap.
- Album backdrop generation runs on `Dispatchers.Default`; the previous backdrop stays visible until the next one is ready.
- Album artwork crossfades over 620 ms instead of replacing the image in a single frame.
- The blurred album-colour wallpaper crossfades over 680 ms, preventing the original lock-screen wallpaper from flashing between tracks.
- Expanded player title and artist labels crossfade with track metadata.

Build and device-test this source with Android Studio / the Android Gradle Plugin. This environment does not include the Gradle wrapper launcher or Android SDK, so no APK compilation is claimed.

## Pass 9 — album motion refinement

- Replaced the album-cover opacity-only crossfade with a spatial handoff: the incoming cover eases in from the right with a restrained scale settle while the outgoing cover moves slightly left and scales down.
- Clock, player controls, and notifications now use spring-based slide + scale + fade entrance choreography rather than fade/slide alone.
- The liquid-glass renderer is intentionally unchanged in this pass. On-device reports still show dark/black panels, so it is not marked fixed; backdrop capture and shader output need a dedicated diagnostic pass on the target Lenovo before swapping rendering libraries or claiming optical refraction works.
- Source-only update. Build and test with GitHub Actions before installing.


## Pass 11 — Optical Liquid Glass refinement

This pass revises the Android 13+ AGSL lens treatment: multi-sample edge displacement, a subtle tangent ripple, restrained chromatic dispersion, a Fresnel-like bevel glint, clearer low-frost material tuning, and a stronger tilt-responsive rim. The default material is intentionally clearer and less gray than the previous implementation. The captured wallpaper remains the source image; the shader is an optical treatment over that image, not a generated gray fill.

The current source also already contains independently controlled clock width/height and a responsive widget rail/row. Always-on display, richer spring-based scene transitions, and expanded adaptive widget rules remain separate follow-up work rather than being represented as completed in this pass.


## Pass 12 — Album clock + optical safety pass

- Added a separately persisted `albumClock` configuration to each lock-screen profile. Existing profile JSON remains compatible because the new field has a default.
- Album-mode clock typography now uses the selected clock face and weight, independently from the normal lock-screen clock. Tap the album clock or its **EDIT ALBUM CLOCK** label to open its dedicated editor sheet.
- Increased the paused album-art scale-down from 1.5% to 10%, with the existing spring animation returning it to full size during playback.
- Reduced the RenderEffect layer's composite alpha to 16% over a correctly aligned wallpaper underlay. This is a defensive mitigation for drivers that silently return opaque black RenderEffect output; it preserves the captured wallpaper as the dominant image while retaining a subtle optical contribution. It is not yet a verified full AGSL/refraction fix.
- Bumped Android versionCode/versionName for the next installable pass.

Build status: source-only update. This environment did not have Gradle or an Android SDK configured, so an APK build and device-side validation were not performed.
