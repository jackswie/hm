package com.glasslock.ui.glass

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Matrix
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.util.lerp
import com.glasslock.data.model.GlassAppearance
import com.glasslock.data.model.GlassMode
import com.glasslock.data.model.GlassStyle
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import android.graphics.RenderEffect as AndroidRenderEffect

/** The outline a glass surface takes. Coordinates are local to the modified node. */
sealed interface GlassGeometry {
    /** Cards, pills, circles (use a large radius). Gets exact SDF-based refraction. */
    data class Rounded(val cornerRadius: Dp) : GlassGeometry

    /** Any outline, e.g. clock digits. Compared by reference, so create a new one when it changes. */
    class Mask(val path: Path) : GlassGeometry
}

/** Concrete numbers derived from a [GlassStyle]; this is where "intensity 0..100%" is defined. */
internal data class GlassParams(
    val blurPx: Float,
    val refract: Float,
    val bandPx: Float,
    val dispersion: Float,
    val frost: Float,
    val tint: Color,
    val saturation: Float,
    val rimBoost: Float,
)

internal fun glassParams(style: GlassStyle, density: Float, wallpaperTint: Color): GlassParams {
    val t = style.intensity.coerceIn(0f, 1f)
    val tint = if (style.appearance == GlassAppearance.TINTED) {
        val base = style.tintColor?.let { Color(it) } ?: wallpaperTint
        base.copy(alpha = lerp(0.12f, 0.38f, t))
    } else {
        Color.Transparent
    }
    return GlassParams(
        // Apple's glass is mostly clear: a light blur, strong edge lensing, a bright specular rim.
        blurPx = lerp(0.18f, 1.65f, t.pow(1.35f)) * density,
        refract = lerp(1.55f, 1.12f, t),
        bandPx = lerp(22f, 34f, t) * density,
        dispersion = 0.035f * (1f - t * 0.22f),
        frost = lerp(0.0f, 0.018f, t),
        tint = tint,
        saturation = lerp(1.08f, 1.22f, t),
        rimBoost = lerp(2.05f, 1.45f, t),
    )
}

private data class RecordKey(val rel: Offset, val size: IntSize, val version: Int)

private data class EffectKey(
    val params: GlassParams,
    val w: Int,
    val h: Int,
    val pad: Int,
    val radius: Float,
    val geometry: Any?,
)

private class GlassEngine {
    var recordKey: RecordKey? = null
    var effectKey: EffectKey? = null
    var roundPath = Path()
    var roundKey: Triple<Float, Float, Float>? = null
}

/**
 * Liquid Glass / Solid material.
 *
 * Liquid: backdrop copy -> AGSL edge refraction -> blur -> saturation -> frost/tint -> sheen ->
 * 1dp specular rim whose light direction follows device tilt. Without AGSL (Android 12) the
 * refraction step is skipped and everything else still works.
 * Solid: flat colour at the chosen opacity with a hairline edge.
 */
@Composable
fun Modifier.liquidGlass(geometry: GlassGeometry, style: GlassStyle): Modifier {
    // Real backdrop-sampled glass: AGSL bends the captured wallpaper near the silhouette,
    // followed by a restrained blur, tint and tilt-aware specular rim.
    val engine = remember { GlassEngine() }
    val panelLayer = rememberGraphicsLayer()
    val environment = LocalGlassEnvironment.current
    var panelPosition by remember { mutableStateOf(Offset.Zero) }
    val density = LocalDensity.current.density
    val positioned = this.onGloballyPositioned { panelPosition = it.positionInRoot() }
    return positioned.drawWithContent {
        if (size.width < 1f || size.height < 1f) {
            drawContent()
            return@drawWithContent
        }
        val shape = shapePath(engine, geometry)
        if (style.mode == GlassMode.SOLID) {
            drawSolid(shape, style, density)
        } else {
            val env = environment
            val params = glassParams(style, density, env?.tint ?: Color(0xFF8794AA))
            val sampled = if (env != null) {
                val captured = runCatching {
                    drawBackdrop(engine, panelLayer, env.backdrop, panelPosition, geometry, params, shape)
                }.isSuccess
                if (!captured) {
                    // Last-resort path: draw the captured wallpaper directly in the glass node's
                    // coordinate space. It is unblurred, but it is still real wallpaper rather
                    // than a black/gray placeholder if a GPU effect fails on a particular device.
                    runCatching {
                        val rel = panelPosition - env.backdrop.origin
                        clipPath(shape) {
                            translate(-rel.x, -rel.y) { drawLayer(env.backdrop.layer) }
                        }
                    }.isSuccess
                } else true
            } else false
            if (!sampled) {
                // Graceful fallback for Android 12 / devices without RuntimeShader support.
                clipPath(shape) {
                    drawPath(shape, Color.White.copy(alpha = 0.035f))
                    drawRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.075f), Color.Transparent, Color.Black.copy(alpha = 0.035f))))
                }
            }
            val tint = if (style.appearance == GlassAppearance.TINTED) params.tint else Color.Transparent
            clipPath(shape) {
                if (tint.alpha > 0f) drawPath(shape, tint)
                drawRect(Brush.verticalGradient(
                    0f to Color.White.copy(alpha = 0.065f),
                    0.16f to Color.White.copy(alpha = 0.018f),
                    0.72f to Color.Transparent,
                    1f to Color.Black.copy(alpha = 0.028f),
                ))
            }
            drawRim(shape, env?.tilt?.value ?: Offset.Zero, params.rimBoost, density)
        }
        drawContent()
    }
}

private fun DrawScope.shapePath(engine: GlassEngine, geometry: GlassGeometry): Path = when (geometry) {
    is GlassGeometry.Mask -> geometry.path
    is GlassGeometry.Rounded -> {
        val r = min(geometry.cornerRadius.toPx(), min(size.width, size.height) / 2f)
        val key = Triple(size.width, size.height, r)
        if (engine.roundKey != key) {
            engine.roundPath = Path().apply {
                addRoundRect(RoundRect(0f, 0f, size.width, size.height, CornerRadius(r)))
            }
            engine.roundKey = key
        }
        engine.roundPath
    }
}

private fun DrawScope.drawSolid(shape: Path, style: GlassStyle, density: Float) {
    drawPath(shape, Color(style.solidColor).copy(alpha = style.opacity.coerceIn(0.1f, 1f)))
    clipPath(shape) {
        drawPath(shape, Color.White.copy(alpha = 0.16f), style = Stroke(width = 2f * density))
    }
}

private fun DrawScope.drawBackdrop(
    engine: GlassEngine,
    panelLayer: GraphicsLayer,
    backdrop: GlassBackdrop,
    panelPosition: Offset,
    geometry: GlassGeometry,
    p: GlassParams,
    shape: Path,
) {
    val w = ceil(size.width).toInt()
    val h = ceil(size.height).toInt()
    // Extra border so blur and refraction can see wallpaper that lies just outside the shape.
    val pad = ceil(p.blurPx * 2f + p.bandPx).toInt() + 2
    val layerSize = IntSize(w + 2 * pad, h + 2 * pad)
    val rel = panelPosition - backdrop.origin

    val recordKey = RecordKey(rel, layerSize, backdrop.version)
    if (recordKey != engine.recordKey) {
        panelLayer.record(this, layoutDirection, layerSize) {
            translate(pad - rel.x, pad - rel.y) { drawLayer(backdrop.layer) }
        }
        engine.recordKey = recordKey
    }

    val radius = (geometry as? GlassGeometry.Rounded)
        ?.let { min(it.cornerRadius.toPx(), min(size.width, size.height) / 2f) } ?: 0f
    val effectKey = EffectKey(p, w, h, pad, radius, (geometry as? GlassGeometry.Mask))
    if (effectKey != engine.effectKey) {
        // Keep backdrop sampling independent from the optional AGSL lens. A shader compilation
        // or device-driver failure must never replace the captured wallpaper with a gray panel.
        val renderEffect = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            runCatching { agslEffect(geometry, p, w, h, pad, radius).asComposeRenderEffect() }
                .getOrElse {
                    BlurEffect(max(p.blurPx, 0.5f), max(p.blurPx, 0.5f), TileMode.Clamp)
                }
        } else {
            BlurEffect(max(p.blurPx, 0.5f), max(p.blurPx, 0.5f), TileMode.Clamp)
        }
        panelLayer.renderEffect = renderEffect
        panelLayer.colorFilter = ColorFilter.colorMatrix(
            ColorMatrix().apply { setToSaturation(p.saturation) }
        )
        engine.effectKey = effectKey
    }

    clipPath(shape) {
        // Keep a clean, correctly aligned copy of the real wallpaper underneath the optical pass.
        translate(-rel.x, -rel.y) { drawLayer(backdrop.layer) }
        // Blend the optical pass gently: some drivers can return a black RenderEffect texture
        // without throwing, so the captured wallpaper must remain visually dominant.
        // RenderEffect failures can be silent (opaque black texture, no exception). Keep
        // the optical pass deliberately restrained so the real wallpaper remains dominant.
        panelLayer.alpha = 0.16f
        translate(-pad.toFloat(), -pad.toFloat()) { drawLayer(panelLayer) }
        panelLayer.alpha = 1f
    }
}

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
private fun agslEffect(
    geometry: GlassGeometry,
    p: GlassParams,
    w: Int,
    h: Int,
    pad: Int,
    radiusPx: Float,
): AndroidRenderEffect {
    val shader: RuntimeShader
    when (geometry) {
        is GlassGeometry.Rounded -> {
            shader = RuntimeShader(Agsl.ROUND_RECT)
            shader.setFloatUniform("uSize", w.toFloat(), h.toFloat())
            shader.setFloatUniform("uOrigin", pad.toFloat(), pad.toFloat())
            shader.setFloatUniform("uRadius", radiusPx)
        }
        is GlassGeometry.Mask -> {
            shader = RuntimeShader(Agsl.MASK)
            shader.setInputShader("mask", maskShader(geometry.path, w + 2 * pad, h + 2 * pad, pad))
        }
    }
    shader.setFloatUniform("uRefract", p.refract)
    shader.setFloatUniform("uBand", p.bandPx)
    shader.setFloatUniform("uDisp", p.dispersion)

    val radius = max(p.blurPx + p.frost * 12f, 0.18f)
    val blur = AndroidRenderEffect.createBlurEffect(radius, radius, Shader.TileMode.CLAMP)
    val refraction = AndroidRenderEffect.createRuntimeShaderEffect(shader, "content")
    // Inner effect runs first: refract the sharp backdrop, then blur the result.
    return AndroidRenderEffect.createChainEffect(blur, refraction)
}

/** Quarter-resolution coverage mask of [path], aligned with the padded glass layer. */
@RequiresApi(Build.VERSION_CODES.TIRAMISU)
private fun maskShader(path: Path, layerW: Int, layerH: Int, pad: Int): BitmapShader {
    val scale = 4
    val bitmap = Bitmap.createBitmap(
        (layerW + scale - 1) / scale,
        (layerH + scale - 1) / scale,
        Bitmap.Config.ALPHA_8,
    )
    val canvas = android.graphics.Canvas(bitmap)
    canvas.scale(1f / scale, 1f / scale)
    canvas.translate(pad.toFloat(), pad.toFloat())
    val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    paint.color = android.graphics.Color.WHITE
    canvas.drawPath(path.asAndroidPath(), paint)

    val shader = BitmapShader(bitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
    shader.setFilterMode(BitmapShader.FILTER_MODE_LINEAR)
    shader.setLocalMatrix(Matrix().apply { setScale(scale.toFloat(), scale.toFloat()) })
    return shader
}

/**
 * Specular rim: a 1dp inner gradient border (white 35% -> 5%) plus a faint counter-highlight on the
 * opposite corner and a soft sheen at the lit end. [tilt] swings the light direction.
 */
private fun DrawScope.drawRim(shape: Path, tilt: Offset, boost: Float, density: Float) {
    var dir = Offset(1f + tilt.x * 1.5f, 1f - tilt.y * 1.5f)
    val len = dir.getDistance()
    dir = if (len < 0.2f) Offset(0.707f, 0.707f) else dir / len

    val half = hypot(size.width, size.height) / 2f
    val c = center
    val brush = Brush.linearGradient(
        0f to Color.White.copy(alpha = min(1f, 0.52f * boost)),
        0.16f to Color.White.copy(alpha = 0.13f),
        0.42f to Color.White.copy(alpha = 0.025f),
        0.68f to Color.White.copy(alpha = 0.055f),
        1f to Color.White.copy(alpha = min(1f, 0.34f * boost)),
        start = c - dir * half,
        end = c + dir * half,
    )
    clipPath(shape) {
        // Soft inner glow first, then the crisp 1dp rim on top (the stroke is centred on the outline,
        // clipping to the shape keeps the inner half).
        drawPath(shape, brush, alpha = 0.48f, style = Stroke(width = 11f * density))
        drawPath(shape, brush, style = Stroke(width = 1.35f * density))
        drawRect(
            Brush.radialGradient(
                listOf(Color.White.copy(alpha = 0.16f * boost), Color.Transparent),
                center = c - dir * half * 0.8f,
                radius = half * 1.1f,
            )
        )
    }
}
