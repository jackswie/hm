package com.glasslock.ui.widgets

import android.content.pm.PackageManager
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.glasslock.data.WeatherRepository
import com.glasslock.data.WeatherState
import com.glasslock.data.model.WidgetConfig
import com.glasslock.data.model.WidgetSize
import com.glasslock.data.model.WidgetType
import com.glasslock.ui.LocalAppActions
import com.glasslock.ui.clock.WallpaperLoader
import com.glasslock.ui.clock.rememberNow
import com.glasslock.ui.theme.Ink
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun WidgetContent(cfg: WidgetConfig, editing: Boolean) {
    when (cfg.type) {
        WidgetType.ANALOG_CLOCK -> AnalogClockWidget(cfg.dialStyle)
        WidgetType.BATTERY -> BatteryWidget(cfg)
        WidgetType.CALENDAR -> CalendarWidget()
        WidgetType.WEATHER -> WeatherWidget(cfg.size)
        WidgetType.DIGITAL_CLOCK -> DigitalClockWidget()
        WidgetType.QUOTE -> QuoteWidget(cfg)
        WidgetType.PHOTO -> PhotoWidget(cfg)
        WidgetType.APP_SHORTCUT -> ShortcutWidget(cfg, editing)
    }
}

// ---- Analog clock ---------------------------------------------------------------------------

@Composable
fun AnalogClockWidget(dialStyle: Int) {
    // ~30 fps keeps the second hand sweeping without redrawing every glass panel at 60 fps.
    val nanos = produceState(LocalTime.now().toNanoOfDay()) {
        while (true) {
            value = LocalTime.now().toNanoOfDay()
            delay(33)
        }
    }
    Canvas(Modifier.fillMaxSize().padding(10.dp)) {
        val total = nanos.value / 1e9
        val sec = (total % 60).toFloat()
        val min = ((total / 60) % 60).toFloat()
        val hour = ((total / 3600) % 12).toFloat()
        val r = size.minDimension / 2f

        for (i in 0 until 60) {
            val major = i % 5 == 0
            if (dialStyle == 2 && !major) continue
            val len = if (major) r * 0.12f else r * 0.05f
            rotate(i * 6f, center) {
                if (dialStyle == 2) {
                    drawCircle(Color.White.copy(alpha = 0.85f), r * 0.025f, Offset(center.x, center.y - r + len))
                } else {
                    drawLine(
                        Color.White.copy(alpha = if (major) 0.9f else 0.4f),
                        Offset(center.x, center.y - r), Offset(center.x, center.y - r + len),
                        strokeWidth = if (major) r * 0.03f else r * 0.015f, cap = StrokeCap.Round,
                    )
                }
            }
        }
        if (dialStyle == 0) {
            val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                textAlign = android.graphics.Paint.Align.CENTER
                textSize = r * 0.24f
                color = android.graphics.Color.WHITE
                typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            }
            for (n in 1..12) {
                val a = n * 30f * PI.toFloat() / 180f
                val x = center.x + sin(a) * r * 0.72f
                val y = center.y - cos(a) * r * 0.72f + paint.textSize * 0.35f
                drawContext.canvas.nativeCanvas.drawText(n.toString(), x, y, paint)
            }
        }
        hand(hour * 30f + min * 0.5f, r * 0.45f, r * 0.07f, Color.White)
        hand(min * 6f + sec * 0.1f, r * 0.68f, r * 0.05f, Color.White)
        hand(sec * 6f, r * 0.78f, r * 0.022f, Color(0xFFFF9F0A))
        drawCircle(Color(0xFFFF9F0A), r * 0.05f, center)
    }
}

private fun DrawScope.hand(angleDeg: Float, length: Float, width: Float, color: Color) {
    val a = (angleDeg - 90f) * PI.toFloat() / 180f
    drawLine(color, center, Offset(center.x + cos(a) * length, center.y + sin(a) * length), width, StrokeCap.Round)
}

// ---- Battery --------------------------------------------------------------------------------

@Composable
fun BatteryWidget(cfg: WidgetConfig) {
    val battery by rememberBattery()
    val level = battery.percent / 100f
    if (cfg.size == WidgetSize.ONE) {
        Box(Modifier.fillMaxSize().padding(10.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val sw = size.minDimension * 0.09f
                val stroke = Stroke(width = sw, cap = StrokeCap.Round)
                val tl = Offset(sw / 2f, sw / 2f)
                val sz = Size(size.width - sw, size.height - sw)
                drawArc(Color.White.copy(alpha = 0.25f), 0f, 360f, false, tl, sz, style = stroke)
                drawArc(Color.White, -90f, 360f * level, false, tl, sz, style = stroke)
            }
            Text(
                (if (battery.charging) "⚡" else "") + battery.percent,
                color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold,
            )
        }
    } else {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.Center) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("🔋", fontSize = 14.sp)
                Text(
                    " ${battery.percent}%" + if (battery.charging) " ⚡" else "",
                    color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
                )
            }
            Text(
                listOf(cfg.title, cfg.emoji).filter { it.isNotBlank() }.joinToString(" "),
                color = Ink.secondary, fontSize = 13.sp, maxLines = 1,
            )
            Box(
                Modifier.padding(top = 8.dp).fillMaxWidth().height(5.dp)
                    .clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.25f))
            ) {
                Box(Modifier.fillMaxWidth(level.coerceIn(0.02f, 1f)).fillMaxHeight().background(Color.White))
            }
        }
    }
}

// ---- Calendar -------------------------------------------------------------------------------

@Composable
fun CalendarWidget() {
    val today = remember { LocalDate.now() }
    Canvas(Modifier.fillMaxSize().padding(14.dp)) {
        val nc = drawContext.canvas.nativeCanvas
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        val offset = today.withDayOfMonth(1).dayOfWeek.value - 1 // Monday first
        val days = today.lengthOfMonth()
        val cw = size.width / 7f
        val rh = size.height / 8f // title + header + up to 6 weeks

        paint.textAlign = android.graphics.Paint.Align.LEFT
        paint.typeface = android.graphics.Typeface.DEFAULT_BOLD
        paint.textSize = rh * 0.55f
        paint.color = android.graphics.Color.WHITE
        nc.drawText(today.month.getDisplayName(TextStyle.FULL, Locale.getDefault()).uppercase(), 0f, rh * 0.75f, paint)

        paint.textAlign = android.graphics.Paint.Align.CENTER
        paint.textSize = rh * 0.5f
        paint.color = android.graphics.Color.argb(150, 255, 255, 255)
        "MTWTFSS".forEachIndexed { i, ch -> nc.drawText(ch.toString(), cw * (i + 0.5f), rh * 1.7f, paint) }

        paint.typeface = android.graphics.Typeface.DEFAULT
        for (d in 1..days) {
            val idx = offset + d - 1
            val cx = cw * (idx % 7 + 0.5f)
            val cy = rh * (2 + idx / 7) + rh / 2f
            val isToday = d == today.dayOfMonth
            if (isToday) drawCircle(Color.White, rh * 0.46f, Offset(cx, cy))
            paint.color = if (isToday) android.graphics.Color.BLACK else android.graphics.Color.WHITE
            nc.drawText(d.toString(), cx, cy + paint.textSize * 0.35f, paint)
        }
    }
}

// ---- Weather & sun arc ----------------------------------------------------------------------

@Composable
fun WeatherWidget(size: WidgetSize) {
    val context = LocalContext.current
    val actions = LocalAppActions.current
    val scope = rememberCoroutineScope()
    val state by WeatherRepository.state.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) {
        while (true) {
            WeatherRepository.refresh(context)
            delay(10 * 60_000L)
        }
    }
    when (val s = state) {
        WeatherState.Loading -> CenterNote("Loading weather…")
        WeatherState.NeedsLocation -> Box(Modifier.fillMaxSize().clickable { actions.requestLocation() }) {
            CenterNote("Tap to allow location")
        }
        WeatherState.Unavailable -> Box(Modifier.fillMaxSize().clickable {
            scope.launch { WeatherRepository.refresh(context, force = true) }
        }) { CenterNote("Weather unavailable. Tap to retry") }
        is WeatherState.Ready -> {
            val d = s.data
            when (size) {
                WidgetSize.ONE -> Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
                    Text(d.emoji, fontSize = 18.sp)
                    Text("${d.tempC}°", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Light)
                }
                WidgetSize.WIDE -> Row(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(d.place, color = Color.White, fontSize = 14.sp, maxLines = 1)
                        Text("${d.tempC}°", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Light)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(d.emoji, fontSize = 20.sp)
                        Text(d.condition, color = Ink.secondary, fontSize = 12.sp)
                        Text("Rain ${d.rainPct}%", color = Ink.secondary, fontSize = 12.sp)
                    }
                }
                WidgetSize.LARGE -> Column(Modifier.fillMaxSize().padding(14.dp)) {
                    Text("${d.place} ${d.emoji}", color = Color.White, fontSize = 14.sp, maxLines = 1)
                    Text("${d.tempC}°", color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.Light)
                    Text("${d.condition} · Rain ${d.rainPct}%", color = Ink.secondary, fontSize = 12.sp)
                    SunArc(d.sunrise, d.sunset, Modifier.weight(1f).fillMaxWidth().padding(top = 8.dp))
                }
            }
        }
    }
}

@Composable
private fun CenterNote(text: String) {
    Box(Modifier.fillMaxSize().padding(8.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Ink.secondary, fontSize = 12.sp, textAlign = TextAlign.Center)
    }
}

/** Curved sunrise-to-sunset arc with a dot at the sun's current position. */
@Composable
fun SunArc(sunrise: LocalTime, sunset: LocalTime, modifier: Modifier = Modifier) {
    val now by rememberNow()
    val fmt = remember { DateTimeFormatter.ofPattern("HH:mm") }
    Column(modifier) {
        Text("☀ Sunrise ${sunrise.format(fmt)}", color = Color.White, fontSize = 12.sp)
        Canvas(Modifier.weight(1f).fillMaxWidth()) {
            val base = size.height * 0.75f
            val path = Path().apply {
                moveTo(0f, base)
                cubicTo(size.width * 0.3f, base - size.height * 0.95f, size.width * 0.7f, base - size.height * 0.95f, size.width, base)
            }
            drawLine(Color.White.copy(alpha = 0.3f), Offset(0f, base), Offset(size.width, base), 2f)
            drawPath(path, Color.White.copy(alpha = 0.85f), style = Stroke(3f, cap = StrokeCap.Round))
            val span = (sunset.toSecondOfDay() - sunrise.toSecondOfDay()).coerceAtLeast(1)
            val t = ((now.toSecondOfDay() - sunrise.toSecondOfDay()).toFloat() / span).coerceIn(0f, 1f)
            val u = 1f - t
            // cubic bezier point at t
            val x = 3 * u * u * t * size.width * 0.3f + 3 * u * t * t * size.width * 0.7f + t * t * t * size.width
            val y = u * u * u * base + 3 * u * u * t * (base - size.height * 0.95f) +
                3 * u * t * t * (base - size.height * 0.95f) + t * t * t * base
            drawCircle(Color.White, 6f, Offset(x, y))
        }
        Text("Sunset ${sunset.format(fmt)}", color = Ink.secondary, fontSize = 12.sp)
    }
}

// ---- Digital seconds clock ------------------------------------------------------------------

@Composable
fun DigitalClockWidget() {
    val now by rememberNow(everySecond = true)
    val date = remember(now.hour) { LocalDate.now().format(DateTimeFormatter.ofPattern("EEE, d MMM", Locale.getDefault())) }
    Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(now.hour, now.minute, now.second).forEach { FlipCard("%02d".format(Locale.ROOT, it)) }
        }
        Text(date, color = Ink.secondary, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
private fun FlipCard(text: String) {
    Box(
        Modifier.width(44.dp).height(48.dp).clip(RoundedCornerShape(8.dp)).background(Color.Black.copy(alpha = 0.55f)),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Box(Modifier.fillMaxWidth().height(1.dp).background(Color.Black.copy(alpha = 0.6f)))
    }
}

// ---- Quote / text ---------------------------------------------------------------------------

@Composable
fun QuoteWidget(cfg: WidgetConfig) {
    val family = if (cfg.serif) FontFamily.Serif else FontFamily.SansSerif
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.Center) {
        if (cfg.title.isNotBlank()) {
            Text(cfg.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, fontFamily = family, maxLines = 1)
        }
        Text(
            cfg.body.ifBlank { "Tap to edit this text" },
            color = Ink.secondary, fontSize = 12.sp, fontFamily = family,
            lineHeight = 16.sp, maxLines = if (cfg.size == WidgetSize.LARGE) 12 else 4,
        )
    }
}

// ---- Photo frame ----------------------------------------------------------------------------

@Composable
fun PhotoWidget(cfg: WidgetConfig) {
    val photos by produceState(emptyList<ImageBitmap>(), cfg.photos) {
        value = withContext(Dispatchers.Default) {
            cfg.photos.mapNotNull { path ->
                runCatching { WallpaperLoader.decode(File(path), 1024).asImageBitmap() }.getOrNull()
            }
        }
    }
    var index by remember { mutableIntStateOf(0) }
    LaunchedEffect(photos.size) {
        while (photos.size > 1) {
            delay(6_000)
            index = (index + 1) % photos.size
        }
    }
    if (photos.isEmpty()) {
        CenterNote("Add photos in Customize")
    } else {
        Crossfade(index.coerceIn(0, photos.lastIndex), label = "photo") { i ->
            Image(
                photos[i], null, Modifier.fillMaxSize().padding(6.dp).clip(RoundedCornerShape(20.dp)),
                contentScale = ContentScale.Crop,
            )
        }
    }
}

// ---- App shortcut ---------------------------------------------------------------------------

@Composable
fun ShortcutWidget(cfg: WidgetConfig, editing: Boolean) {
    val context = LocalContext.current
    val actions = LocalAppActions.current
    val pkg = cfg.packageName
    val icon by produceState<ImageBitmap?>(null, pkg) {
        value = pkg?.let { withContext(Dispatchers.Default) { monochromeIcon(context.packageManager, it) } }
    }
    val launchable = !editing && pkg != null
    Box(
        Modifier.fillMaxSize().then(
            if (launchable) Modifier.clickable {
                context.packageManager.getLaunchIntentForPackage(pkg!!)?.let(actions.launch)
            } else Modifier
        ),
        contentAlignment = Alignment.Center,
    ) {
        val img = icon
        if (img != null) {
            Image(img, null, Modifier.fillMaxSize(0.62f), colorFilter = ColorFilter.tint(Color.White))
        } else {
            Text(if (pkg == null) "＋" else "…", color = Color.White, fontSize = 26.sp)
        }
    }
}

/** White-tintable glyph: the themed monochrome layer if the app has one, else the icon foreground. */
internal fun monochromeIcon(pm: PackageManager, pkg: String): ImageBitmap? = runCatching {
    val d = pm.getApplicationIcon(pkg)
    val layer: Drawable = if (d is AdaptiveIconDrawable) {
        (if (Build.VERSION.SDK_INT >= 33) d.monochrome else null) ?: d.foreground ?: d
    } else d
    layer.toBitmap(192, 192).asImageBitmap()
}.getOrNull()
