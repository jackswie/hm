package com.glasslock.ui.glass

/**
 * AGSL sources (Android 13+). Both shaders run on the *backdrop* captured behind a glass surface
 * and bend it near the surface's edge, like the thick rim of a glass lens:
 *
 *  - ROUND_RECT : exact signed-distance field of a rounded rectangle (cards, pills, buttons).
 *  - MASK       : arbitrary shapes (the clock digits). The shape is supplied as a coverage mask and
 *                 the edge normal is estimated by sampling it on two rings around the pixel.
 *
 * The blur is applied afterwards by RenderEffect.createChainEffect, so a high "frost" setting
 * naturally hides the refraction, as real frosted glass does. Rim light, tint and frost are drawn in
 * Compose (see LiquidGlass.kt) so tilting the device never re-runs these shaders.
 */
internal object Agsl {
    private const val COMMON = """
uniform shader content;
uniform float uRefract;
uniform float uBand;
uniform float uDisp;

half4 shade(float2 p, float2 inward, float edge) {
    float k = edge * edge;
    float2 o = inward * (k * uRefract * uBand * 0.5);
    float2 od = o * uDisp;
    half r = content.eval(p + o + od).r;
    half g = content.eval(p + o).g;
    half b = content.eval(p + o - od).b;
    half3 col = half3(r, g, b) + half3(k * 0.10);
    return half4(col, 1.0);
}
"""

    const val ROUND_RECT = COMMON + """
uniform float2 uSize;
uniform float2 uOrigin;
uniform float uRadius;

float sdRoundRect(float2 p, float2 halfSize, float r) {
    float2 q = abs(p) - halfSize + float2(r);
    return min(max(q.x, q.y), 0.0) + length(max(q, float2(0.0))) - r;
}

half4 main(float2 frag) {
    float2 hs = uSize * 0.5;
    float2 p = frag - (uOrigin + hs);
    float d = sdRoundRect(p, hs, uRadius);
    float2 gr = float2(
        sdRoundRect(p + float2(1.0, 0.0), hs, uRadius) - sdRoundRect(p - float2(1.0, 0.0), hs, uRadius),
        sdRoundRect(p + float2(0.0, 1.0), hs, uRadius) - sdRoundRect(p - float2(0.0, 1.0), hs, uRadius));
    float gl = length(gr);
    float2 inward = gl > 0.0001 ? -gr / gl : float2(0.0);
    float edge = gl > 0.0001 ? 1.0 - clamp(-d / uBand, 0.0, 1.0) : 0.0;
    return shade(frag, inward, edge);
}
"""

    const val MASK = COMMON + """
uniform shader mask;

half4 main(float2 frag) {
    float2 g = float2(0.0);
    float cov = 0.0;
    for (int i = 0; i < 8; i++) {
        float a = 0.7853982 * float(i);
        float2 dir = float2(cos(a), sin(a));
        float s1 = mask.eval(frag + dir * uBand * 0.5).a;
        float s2 = mask.eval(frag + dir * uBand).a;
        g += dir * (s1 + s2);
        cov += s1 + s2;
    }
    cov = cov / 16.0;
    float gl = length(g);
    float2 inward = gl > 0.0001 ? g / gl : float2(0.0);
    float edge = gl > 0.0001 ? 1.0 - smoothstep(0.45, 0.95, cov) : 0.0;
    return shade(frag, inward, edge);
}
"""
}
