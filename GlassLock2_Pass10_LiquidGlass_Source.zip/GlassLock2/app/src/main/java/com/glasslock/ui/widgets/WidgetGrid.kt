package com.glasslock.ui.widgets

import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.glasslock.data.model.WidgetConfig
import com.glasslock.data.model.WidgetSize
import com.glasslock.ui.glass.GlassGeometry
import com.glasslock.ui.glass.liquidGlass
import kotlin.math.floor
import kotlin.math.roundToInt

/** Pure grid maths for the 2-column widget rail. */
object WidgetGrid {
    const val COLS = 2

    fun fits(all: List<WidgetConfig>, id: String, size: WidgetSize, col: Int, row: Int, rows: Int): Boolean {
        if (col < 0 || row < 0 || col + size.cols > COLS || row + size.rows > rows) return false
        return all.none { o ->
            o.id != id &&
                col < o.col + o.size.cols && o.col < col + size.cols &&
                row < o.row + o.size.rows && o.row < row + size.rows
        }
    }

    fun firstFree(all: List<WidgetConfig>, size: WidgetSize, rows: Int): Pair<Int, Int>? {
        for (r in 0 until rows) for (c in 0..COLS - size.cols) {
            if (fits(all, "", size, c, r, rows)) return c to r
        }
        return null
    }
}

private fun radiusFor(size: WidgetSize): Dp = if (size == WidgetSize.ONE) 100.dp else 26.dp

@Composable
private fun TileFrame(
    cfg: WidgetConfig,
    width: Dp,
    height: Dp,
    editing: Boolean,
    selected: Boolean,
    modifier: Modifier,
) {
    val shape = RoundedCornerShape(radiusFor(cfg.size))
    Box(
        modifier
            .size(width, height)
            .liquidGlass(GlassGeometry.Rounded(radiusFor(cfg.size)), cfg.style)
            .then(if (editing && selected) Modifier.border(2.dp, Color.White.copy(alpha = 0.9f), shape) else Modifier)
            .clip(shape)
    ) {
        Box(Modifier.fillMaxSize()) { WidgetContent(cfg, editing) }
    }
}

/**
 * Landscape widget rail (left, ~20% width). In edit mode tiles drag and snap to the grid;
 * a drop onto an occupied or out-of-range cell springs back.
 */
@Composable
fun WidgetRail(
    widgets: List<WidgetConfig>,
    editing: Boolean,
    selectedId: String?,
    railWidth: Dp,
    availableHeight: Dp,
    onRows: (Int) -> Unit,
    onMove: (id: String, col: Int, row: Int) -> Unit,
    onTap: (id: String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val gap = 14.dp
    val cell = (railWidth - gap) / 2
    val rows = floor(((availableHeight + gap) / (cell + gap))).toInt().coerceAtLeast(1)
    LaunchedEffect(rows) { onRows(rows) }
    val stepPx = with(LocalDensity.current) { (cell + gap).toPx() }

    Box(modifier.width(railWidth).height(availableHeight)) {
        widgets.forEach { cfg ->
            key(cfg.id) {
                var drag by remember { mutableStateOf(Offset.Zero) }
                var dragging by remember { mutableStateOf(false) }
                val latestCfg by rememberUpdatedState(cfg)
                val latestAll by rememberUpdatedState(widgets)

                fun finish() {
                    val c = latestCfg
                    val col = ((c.col * stepPx + drag.x) / stepPx).roundToInt()
                    val row = ((c.row * stepPx + drag.y) / stepPx).roundToInt()
                    if ((col != c.col || row != c.row) && WidgetGrid.fits(latestAll, c.id, c.size, col, row, rows)) {
                        onMove(c.id, col, row)
                    }
                    drag = Offset.Zero
                    dragging = false
                }

                TileFrame(
                    cfg = cfg,
                    width = cell * cfg.size.cols + gap * (cfg.size.cols - 1),
                    height = cell * cfg.size.rows + gap * (cfg.size.rows - 1),
                    editing = editing,
                    selected = cfg.id == selectedId,
                    modifier = Modifier
                        .offset { IntOffset((cfg.col * stepPx + drag.x).roundToInt(), (cfg.row * stepPx + drag.y).roundToInt()) }
                        .zIndex(if (dragging) 1f else 0f)
                        .alpha(if (dragging) 0.85f else 1f)
                        .then(
                            if (editing) {
                                Modifier
                                    .pointerInput(Unit) { detectTapGestures { onTap(latestCfg.id) } }
                                    .pointerInput(Unit) {
                                        detectDragGestures(
                                            onDragStart = { dragging = true },
                                            onDragEnd = { finish() },
                                            onDragCancel = { drag = Offset.Zero; dragging = false },
                                        ) { change, amount ->
                                            change.consume()
                                            drag += amount
                                        }
                                    }
                            } else Modifier
                        ),
                )
            }
        }
    }
}

/** Portrait: the same widgets reflow into one horizontal row under the clock, in rail order. */
@Composable
fun WidgetRow(
    widgets: List<WidgetConfig>,
    editing: Boolean,
    selectedId: String?,
    onTap: (id: String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val cell = 112.dp
    val gap = 14.dp
    Row(
        modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(gap),
    ) {
        widgets.sortedWith(compareBy({ it.row }, { it.col })).forEach { cfg ->
            key(cfg.id) {
                TileFrame(
                    cfg = cfg,
                    width = cell * cfg.size.cols + gap * (cfg.size.cols - 1),
                    height = cell * cfg.size.rows + gap * (cfg.size.rows - 1),
                    editing = editing,
                    selected = cfg.id == selectedId,
                    modifier = if (editing) Modifier.pointerInput(Unit) { detectTapGestures { onTap(cfg.id) } } else Modifier,
                )
            }
        }
    }
}
