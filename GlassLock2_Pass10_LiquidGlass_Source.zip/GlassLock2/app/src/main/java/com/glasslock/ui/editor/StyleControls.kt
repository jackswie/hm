package com.glasslock.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.glasslock.data.model.GlassAppearance
import com.glasslock.data.model.GlassMode
import com.glasslock.data.model.GlassStyle
import com.glasslock.ui.glass.GlassGeometry
import com.glasslock.ui.glass.Palette
import com.glasslock.ui.glass.liquidGlass
import com.glasslock.ui.theme.Ink
import kotlin.math.roundToInt

private val FrameStyle = GlassStyle(intensity = 0.85f, appearance = GlassAppearance.TINTED)

/** Floating glass popover used by every configurator. */
@Composable
fun SheetFrame(title: String, onDismiss: () -> Unit, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .widthIn(max = 400.dp)
            .fillMaxWidth()
            .liquidGlass(GlassGeometry.Rounded(32.dp), FrameStyle)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp, vertical = 18.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = Ink.primary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            GlassPill("Done", onDismiss)
        }
        content()
    }
}

/** Material section (Glass/Solid, intensity or opacity, Clear/Tinted, colour) shared by clock, widgets, media, buttons. */
@Composable
fun StyleControls(style: GlassStyle, palette: Palette, onChange: ((GlassStyle) -> GlassStyle) -> Unit) {
    SectionTitle("Material")
    Segmented(
        options = listOf(GlassMode.LIQUID to "Translucent", GlassMode.SOLID to "Solid"),
        selected = style.mode,
        onSelect = { m -> onChange { it.copy(mode = m) } },
    )
    if (style.mode == GlassMode.LIQUID) {
        Column(Modifier.padding(top = 12.dp)) {
            GlassSlider("Material softness", "${(style.intensity * 100).roundToInt()}%", style.intensity, 0f..1f) { v ->
                onChange { it.copy(intensity = v) }
            }
        }
        SectionTitle("Appearance")
        Segmented(
            options = listOf(GlassAppearance.CLEAR to "Clear", GlassAppearance.TINTED to "Tinted"),
            selected = style.appearance,
            onSelect = { a -> onChange { it.copy(appearance = a) } },
        )
    } else {
        Column(Modifier.padding(top = 12.dp)) {
            GlassSlider("Opacity", "${(style.opacity * 100).roundToInt()}%", style.opacity, 0.1f..1f) { v ->
                onChange { it.copy(opacity = v) }
            }
        }
    }
    if (style.mode == GlassMode.SOLID || style.appearance == GlassAppearance.TINTED) {
        SectionTitle(if (style.mode == GlassMode.SOLID) "Color" else "Tint")
        val current = if (style.mode == GlassMode.SOLID) Color(style.solidColor) else style.tintColor?.let { Color(it) } ?: palette.tint
        ColorPickerSection(current, palette.swatches) { picked ->
            onChange { if (it.mode == GlassMode.SOLID) it.copy(solidColor = picked.toArgb()) else it.copy(tintColor = picked.toArgb()) }
        }
    }
}

@Composable
fun GlassTextField(label: String, value: String, singleLine: Boolean = true, onChange: (String) -> Unit) {
    Column(Modifier.padding(top = 10.dp)) {
        Text(label, color = Ink.secondary, fontSize = 12.sp, modifier = Modifier.padding(bottom = 4.dp))
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = singleLine,
            textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
            cursorBrush = SolidColor(Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = if (singleLine) 0.dp else 90.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color.White.copy(alpha = 0.14f))
                .padding(12.dp),
        )
    }
}
