package com.glasslock.ui.widgets

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.glasslock.data.model.GlassStyle
import com.glasslock.ui.glass.GlassGeometry
import com.glasslock.ui.glass.liquidGlass
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/** "Thu 1" line that sits centred directly above the clock. */
@Composable
fun DateHeader(inline: String = "", modifier: Modifier = Modifier) {
    val date = LocalDate.now().format(DateTimeFormatter.ofPattern("EEE d", Locale.getDefault()))
    val text = if (inline.isBlank()) date else "$date   $inline"
    Text(
        text,
        modifier = modifier,
        color = Color.White,
        fontSize = 22.sp,
        fontWeight = FontWeight.SemiBold,
        textAlign = TextAlign.Center,
    )
}

/** Focus / custom status pill, e.g. "🌙 Do Not Disturb". Rendered as Liquid Glass. */
@Composable
fun StatusPill(text: String, modifier: Modifier = Modifier) {
    Box(
        modifier
            .liquidGlass(GlassGeometry.Rounded(100.dp), GlassStyle(intensity = 0.5f))
            .padding(horizontal = 18.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

/** Thin white rounded pill (134dp x 5dp) at the bottom centre. Swipe-to-unlock arrives in Pass 3. */
@Composable
fun HomeIndicator(modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(width = 134.dp, height = 5.dp)
            .background(Color.White.copy(alpha = 0.92f), RoundedCornerShape(100.dp))
    )
}

