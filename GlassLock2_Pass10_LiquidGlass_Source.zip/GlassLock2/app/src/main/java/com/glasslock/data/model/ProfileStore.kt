package com.glasslock.data.model

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.profileDataStore by preferencesDataStore(name = "glasslock_profiles")

/** Persists every lock screen profile as one JSON document in DataStore. */
class ProfileStore(context: Context) {
    private val appContext = context.applicationContext
    private val key = stringPreferencesKey("profiles_v1")
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    val profiles: Flow<List<LockProfile>> = appContext.profileDataStore.data.map { prefs ->
        prefs[key]
            ?.let { runCatching { json.decodeFromString<List<LockProfile>>(it) }.getOrNull() }
            ?: emptyList()
    }

    private val activeKey = stringPreferencesKey("active_profile")

    val activeId: Flow<String?> = appContext.profileDataStore.data.map { it[activeKey] }

    suspend fun save(list: List<LockProfile>, activeId: String) {
        appContext.profileDataStore.edit {
            it[key] = json.encodeToString(list)
            it[activeKey] = activeId
        }
    }
}
