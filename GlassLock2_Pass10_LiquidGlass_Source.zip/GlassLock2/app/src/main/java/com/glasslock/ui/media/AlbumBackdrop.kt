package com.glasslock.ui.media

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Rect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.glasslock.ui.glass.Palette
import com.glasslock.ui.glass.WallpaperPalette

/**
 * The "album wallpaper" shown while the full-screen player is open: the cover, centre-cropped to the screen's
 * shape, blurred into soft colour fields, made a little more vivid and slightly darker so white text and glass
 * read well. This is what Apple's Now Playing lock screen does. It replaces the wallpaper for the scene, so the
 * glass clock refracts the album colours too.
 */
class AlbumBackdrop(val image: ImageBitmap, val palette: Palette) {
    companion object {
        fun render(art: Bitmap, landscape: Boolean): AlbumBackdrop? = runCatching { build(art, landscape) }.getOrNull()

        private fun build(art: Bitmap, landscape: Boolean): AlbumBackdrop {
            val src = if (art.config == Bitmap.Config.HARDWARE) art.copy(Bitmap.Config.ARGB_8888, false) else art
            val palette = WallpaperPalette.from(src)

            val w = if (landscape) 96 else 64
            val h = if (landscape) 60 else 104

            // Centre-crop the cover to the screen's aspect ratio.
            val sw = src.width
            val sh = src.height
            val target = w.toFloat() / h
            val crop = if (sw.toFloat() / sh > target) {
                val cw = (sh * target).toInt()
                Rect((sw - cw) / 2, 0, (sw - cw) / 2 + cw, sh)
            } else {
                val ch = (sw / target).toInt()
                Rect(0, (sh - ch) / 2, sw, (sh - ch) / 2 + ch)
            }
            val small = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            Canvas(small).drawBitmap(src, crop, Rect(0, 0, w, h), Paint(Paint.FILTER_BITMAP_FLAG))

            // Big soft blur on the tiny copy (cheap), then scale up smoothly.
            val px = IntArray(w * h)
            small.getPixels(px, 0, w, 0, 0, w, h)
            val tmp = IntArray(px.size)
            val radius = maxOf(w, h) / 7
            repeat(3) {
                blurPass(px, tmp, w, h, radius, true)
                blurPass(tmp, px, w, h, radius, false)
            }
            small.setPixels(px, 0, w, 0, 0, w, h)

            val graded = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val matrix = ColorMatrix().apply { setSaturation(1.45f) }
            matrix.postConcat(
                ColorMatrix(
                    floatArrayOf(
                        0.9f, 0f, 0f, 0f, 0f,
                        0f, 0.9f, 0f, 0f, 0f,
                        0f, 0f, 0.9f, 0f, 0f,
                        0f, 0f, 0f, 1f, 0f,
                    )
                )
            )
            Canvas(graded).drawBitmap(small, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(matrix) })

            val big = Bitmap.createScaledBitmap(graded, w * 6, h * 6, true)
            return AlbumBackdrop(big.asImageBitmap(), palette)
        }

        private fun blurPass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
            val n = 2 * r + 1
            for (y in 0 until h) {
                for (x in 0 until w) {
                    var red = 0
                    var green = 0
                    var blue = 0
                    for (k in -r..r) {
                        val xx = if (horizontal) (x + k).coerceIn(0, w - 1) else x
                        val yy = if (horizontal) y else (y + k).coerceIn(0, h - 1)
                        val c = src[yy * w + xx]
                        red += (c shr 16) and 0xFF
                        green += (c shr 8) and 0xFF
                        blue += c and 0xFF
                    }
                    dst[y * w + x] = (0xFF shl 24) or ((red / n) shl 16) or ((green / n) shl 8) or (blue / n)
                }
            }
        }
    }
}
