package com.glasslock.data.model

import kotlinx.serialization.Serializable
import java.util.UUID

@Serializable
enum class WidgetSize(val cols: Int, val rows: Int, val label: String) {
    ONE(1, 1, "1×1"),
    WIDE(2, 1, "2×1"),
    LARGE(2, 2, "2×2"),
}

@Serializable
enum class WidgetType(val label: String, val sizes: List<WidgetSize>) {
    ANALOG_CLOCK("Analog Clock", listOf(WidgetSize.ONE)),
    BATTERY("Battery", listOf(WidgetSize.ONE, WidgetSize.WIDE)),
    CALENDAR("Calendar", listOf(WidgetSize.LARGE)),
    WEATHER("Weather & Sun", listOf(WidgetSize.ONE, WidgetSize.WIDE, WidgetSize.LARGE)),
    DIGITAL_CLOCK("Digital Clock", listOf(WidgetSize.WIDE)),
    QUOTE("Quote / Text", listOf(WidgetSize.WIDE, WidgetSize.LARGE)),
    PHOTO("Photo Frame", listOf(WidgetSize.LARGE, WidgetSize.WIDE)),
    APP_SHORTCUT("App Shortcut", listOf(WidgetSize.ONE)),
}

/** One widget on the 2-column rail. [col]/[row] are grid cells, snapped when dragged. */
@Serializable
data class WidgetConfig(
    val id: String = UUID.randomUUID().toString(),
    val type: WidgetType,
    val size: WidgetSize,
    val col: Int = 0,
    val row: Int = 0,
    val style: GlassStyle = GlassStyle(intensity = 0.3f),
    val title: String = "",
    val body: String = "",
    val emoji: String = "",
    val packageName: String? = null,
    val photos: List<String> = emptyList(),
    val serif: Boolean = false,
    val dialStyle: Int = 0,
)

@Serializable
enum class QuickAction(val label: String) {
    FLASHLIGHT("Flashlight"), CAMERA("Camera"), CALCULATOR("Calculator"),
    TIMER("Timer"), DND("Do Not Disturb"), APP("App"),
}

@Serializable
data class QuickActionConfig(
    val action: QuickAction,
    val packageName: String? = null,
    val style: GlassStyle = GlassStyle(intensity = 0.35f),
)

fun defaultWidgets(): List<WidgetConfig> = listOf(
    WidgetConfig(type = WidgetType.ANALOG_CLOCK, size = WidgetSize.ONE, col = 0, row = 0),
    WidgetConfig(type = WidgetType.BATTERY, size = WidgetSize.WIDE, col = 0, row = 1, title = "My iPad", emoji = "🤍"),
    WidgetConfig(type = WidgetType.CALENDAR, size = WidgetSize.LARGE, col = 0, row = 2),
)
