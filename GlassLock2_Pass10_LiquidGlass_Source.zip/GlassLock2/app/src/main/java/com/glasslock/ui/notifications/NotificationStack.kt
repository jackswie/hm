package com.glasslock.ui.notifications

import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.glasslock.data.model.GlassStyle
import com.glasslock.service.LockNotification
import com.glasslock.ui.glass.GlassGeometry
import com.glasslock.ui.glass.liquidGlass
import com.glasslock.ui.theme.Ink
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Lock screen notifications as Liquid Glass cards. Notifications from one app stack with peeking cards;
 * tapping a stack expands it, tapping a single card opens it (after unlock), swiping a card away dismisses it.
 */
@Composable
fun NotificationStack(
    items: List<LockNotification>,
    style: GlassStyle,
    interactive: Boolean,
    onOpen: (LockNotification) -> Unit,
    onDismiss: (LockNotification) -> Unit,
    onEditTap: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val groups = items.groupBy { it.pkg }.values.sortedByDescending { it.first().whenMs }.take(3)
    Column(modifier.widthIn(max = 440.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        groups.forEach { group ->
            key(group.first().pkg) { GroupStack(group, style, interactive, onOpen, onDismiss, onEditTap) }
        }
    }
}

@Composable
private fun GroupStack(
    group: List<LockNotification>,
    style: GlassStyle,
    interactive: Boolean,
    onOpen: (LockNotification) -> Unit,
    onDismiss: (LockNotification) -> Unit,
    onEditTap: () -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    val stacked = group.size > 1 && !expanded
    Box(Modifier.fillMaxWidth().animateContentSize().padding(bottom = if (stacked) 30.dp else 0.dp)) {
        if (stacked) {
            repeat(min(group.size - 1, 2)) { i ->
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = (12 * (i + 1)).dp)
                        .offset(y = (9 * (i + 1) + 40).dp)
                        .height(40.dp)
                        .liquidGlass(GlassGeometry.Rounded(22.dp), style)
                )
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            (if (expanded) group else group.take(1)).forEach { n ->
                key(n.key) {
                    NotificationCard(
                        n = n,
                        style = style,
                        badge = if (stacked) group.size - 1 else 0,
                        interactive = interactive,
                        onTap = {
                            when {
                                !interactive -> onEditTap()
                                stacked -> expanded = true
                                else -> onOpen(n)
                            }
                        },
                        onDismiss = { onDismiss(n) },
                    )
                }
            }
        }
    }
}

@Composable
private fun NotificationCard(
    n: LockNotification,
    style: GlassStyle,
    badge: Int,
    interactive: Boolean,
    onTap: () -> Unit,
    onDismiss: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val dx = remember { Animatable(0f) }
    var widthPx by remember { mutableStateOf(1f) }
    val icon = remember(n.icon) { n.icon?.asImageBitmap() }
    val time = remember(n.whenMs) {
        if (n.whenMs == 0L || System.currentTimeMillis() - n.whenMs < 60_000) "now"
        else DateTimeFormatter.ofPattern("HH:mm").format(Instant.ofEpochMilli(n.whenMs).atZone(ZoneId.systemDefault()))
    }

    Row(
        Modifier
            .fillMaxWidth()
            .offset { IntOffset(dx.value.roundToInt(), 0) }
            .graphicsLayer { alpha = 1f - (abs(dx.value) / widthPx).coerceIn(0f, 1f) }
            .liquidGlass(GlassGeometry.Rounded(24.dp), style)
            .pointerInput(interactive) {
                widthPx = size.width.toFloat()
                if (interactive) detectHorizontalDragGestures(
                    onDragEnd = {
                        scope.launch {
                            if (abs(dx.value) > widthPx * 0.35f) {
                                dx.animateTo(if (dx.value > 0) widthPx else -widthPx, tween(160))
                                onDismiss()
                            } else dx.animateTo(0f)
                        }
                    },
                    onDragCancel = { scope.launch { dx.animateTo(0f) } },
                ) { c, d ->
                    c.consume()
                    scope.launch { dx.snapTo(dx.value + d) }
                }
            }
            .clickable(onClick = onTap)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)).background(Color.White.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
            if (icon != null) Image(icon, null, Modifier.size(38.dp), contentScale = ContentScale.Crop)
            else Text("💬", fontSize = 18.sp)
        }
        Column(Modifier.weight(1f)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(n.title.ifBlank { n.app }, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, modifier = Modifier.weight(1f))
                Text(time, color = Ink.secondary, fontSize = 12.sp)
            }
            Text(n.text, color = Ink.secondary, fontSize = 14.sp, maxLines = 2)
        }
        if (badge > 0) {
            Text("+$badge", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
    }
}
