package com.glasslock

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import com.glasslock.data.WeatherRepository
import com.glasslock.service.LockService
import com.glasslock.ui.AppActions
import com.glasslock.ui.LocalAppActions
import com.glasslock.ui.editor.EditorScreen
import com.glasslock.ui.editor.EditorViewModel
import com.glasslock.ui.media.MediaRepository
import com.glasslock.ui.setup.SetupScreen
import com.glasslock.ui.setup.SetupStatus
import com.glasslock.ui.setup.batterySettingsIntent
import com.glasslock.ui.setup.overlaySettingsIntent
import com.glasslock.ui.theme.GlassLockTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val viewModel: EditorViewModel by viewModels()
    private var pendingPhotoWidget: String? = null
    private var status by mutableStateOf<SetupStatus?>(null)
    private var showSetup by mutableStateOf(false)

    private val wallpaperPicker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) viewModel.importWallpaper(uri)
    }

    private val widgetPhotoPicker = registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(8)) { uris: List<Uri> ->
        pendingPhotoWidget?.let { id -> if (uris.isNotEmpty()) viewModel.addWidgetPhotos(id, uris) }
        pendingPhotoWidget = null
    }

    private val locationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        status = SetupStatus.read(this)
        if (granted) lifecycleScope.launch { WeatherRepository.refresh(this@MainActivity, force = true) }
    }

    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        status = SetupStatus.read(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        status = SetupStatus.read(this)
        showSetup = !(status?.ready ?: false) // first launch: walk the user through the required permissions
        if (intent.getBooleanExtra(EXTRA_GALLERY, false)) viewModel.requestGalleryOnLoad()

        val actions = AppActions(
            launch = { intent ->
                try {
                    startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: ActivityNotFoundException) {
                    // e.g. no media-output panel: fall back to Bluetooth settings
                    runCatching { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                }
            },
            requestLocation = { locationPermission.launch(Manifest.permission.ACCESS_COARSE_LOCATION) },
            openNotificationAccess = { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
            pickPhotos = { id ->
                pendingPhotoWidget = id
                widgetPhotoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            },
            openSetup = { showSetup = true },
        )

        setContent {
            GlassLockTheme {
                CompositionLocalProvider(LocalAppActions provides remember { actions }) {
                    val s = status
                    if (showSetup && s != null) {
                        SetupScreen(
                            status = s,
                            onOverlay = { startActivity(overlaySettingsIntent(this)) },
                            onListener = { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
                            onNotifications = {
                                if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                            },
                            onLocation = { locationPermission.launch(Manifest.permission.ACCESS_COARSE_LOCATION) },
                            onBattery = { startActivity(batterySettingsIntent(this)) },
                            onToggleLock = { on ->
                                if (on) LockService.start(this) else LockService.stop(this)
                                status = SetupStatus.read(this)
                            },
                            onClose = { showSetup = false },
                        )
                    } else {
                        EditorScreen(
                            vm = viewModel,
                            onPickPhoto = {
                                wallpaperPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                        )
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra(EXTRA_GALLERY, false)) viewModel.openGallery()
    }

    override fun onResume() {
        super.onResume()
        status = SetupStatus.read(this) // permissions are granted in system screens, so re-read on return
        MediaRepository.start(this)
    }

    companion object {
        const val EXTRA_GALLERY = "open_gallery"
    }
}
