package com.glasslock.ui.media

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import androidx.core.app.NotificationManagerCompat
import com.glasslock.service.MediaListenerService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class NowPlaying(
    val hasSession: Boolean = false,
    val title: String = "",
    val artist: String = "",
    val art: Bitmap? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
    val speed: Float = 1f,
    /** SystemClock.elapsedRealtime() when [positionMs] was reported. */
    val stamp: Long = 0,
    val packageName: String? = null,
) {
    val key: String get() = "$packageName|$title|$artist"

    fun positionNow(): Long {
        val p = if (isPlaying) positionMs + ((SystemClock.elapsedRealtime() - stamp) * speed).toLong() else positionMs
        return if (durationMs > 0) p.coerceIn(0, durationMs) else p.coerceAtLeast(0)
    }

    companion object {
        /** Shown in edit mode when nothing is playing, so the card can still be styled. */
        val Sample = NowPlaying(
            hasSession = true, title = "Nights Like This", artist = "The Kid LAROI",
            isPlaying = false, positionMs = 45_000, durationMs = 87_000,
        )
    }
}

/**
 * Mirrors the system's active media session (Spotify, YouTube Music, ...).
 * Needs notification-listener access, because that is what authorises MediaSessionManager.getActiveSessions.
 */
object MediaRepository {
    private val _state = MutableStateFlow(NowPlaying())
    val state: StateFlow<NowPlaying> = _state.asStateFlow()

    private val _hasAccess = MutableStateFlow(false)
    val hasAccess: StateFlow<Boolean> = _hasAccess.asStateFlow()

    private var app: Context? = null
    private var controller: MediaController? = null
    private var listening = false

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { select(it.orEmpty()) }

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = publish()
        override fun onPlaybackStateChanged(state: PlaybackState?) = publish()
        override fun onSessionDestroyed() = refresh()
    }

    /** Call on the main thread (MediaController callbacks are delivered on the calling thread's looper). */
    fun start(context: Context) {
        app = context.applicationContext
        refresh()
    }

    fun refresh() {
        val ctx = app ?: return
        val granted = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
        _hasAccess.value = granted
        if (!granted) {
            detach()
            _state.value = NowPlaying()
            return
        }
        try {
            val manager = ctx.getSystemService(MediaSessionManager::class.java)
            val component = ComponentName(ctx, MediaListenerService::class.java)
            if (!listening) {
                manager.addOnActiveSessionsChangedListener(sessionsListener, component)
                listening = true
            }
            select(manager.getActiveSessions(component))
        } catch (_: SecurityException) {
            _hasAccess.value = false
            _state.value = NowPlaying()
        }
    }

    private fun detach() {
        controller?.unregisterCallback(callback)
        controller = null
        val ctx = app
        if (listening && ctx != null) {
            ctx.getSystemService(MediaSessionManager::class.java).removeOnActiveSessionsChangedListener(sessionsListener)
        }
        listening = false
    }

    private fun select(list: List<MediaController>) {
        val best = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list.firstOrNull()
        if (best?.sessionToken != controller?.sessionToken) {
            controller?.unregisterCallback(callback)
            controller = best
            best?.registerCallback(callback)
        }
        publish()
    }

    private fun publish() {
        val c = controller
        if (c == null) {
            _state.value = NowPlaying()
            return
        }
        val meta = c.metadata
        val ps = c.playbackState
        // Prefer the largest artwork variant supplied by the media session. Some apps expose
        // a tiny notification icon alongside a full-resolution album-art bitmap.
        val artwork = listOf(
            MediaMetadata.METADATA_KEY_ALBUM_ART,
            MediaMetadata.METADATA_KEY_ART,
            MediaMetadata.METADATA_KEY_DISPLAY_ICON,
        ).mapNotNull { key -> runCatching { meta?.getBitmap(key) }.getOrNull() }
            .maxByOrNull { it.width.toLong() * it.height.toLong() }
        _state.value = NowPlaying(
            hasSession = true,
            title = meta?.getString(MediaMetadata.METADATA_KEY_TITLE).orEmpty(),
            artist = (meta?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: meta?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)).orEmpty(),
            art = artwork,
            isPlaying = ps?.state == PlaybackState.STATE_PLAYING,
            positionMs = ps?.position?.takeIf { it >= 0 } ?: 0L,
            durationMs = meta?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L,
            speed = ps?.playbackSpeed?.takeIf { it > 0f } ?: 1f,
            stamp = ps?.lastPositionUpdateTime ?: SystemClock.elapsedRealtime(),
            packageName = c.packageName,
        )
    }

    fun playPause() {
        val c = controller ?: return
        if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause() else c.transportControls.play()
    }

    fun next() = controller?.transportControls?.skipToNext()
    fun previous() = controller?.transportControls?.skipToPrevious()
    fun seekTo(ms: Long) = controller?.transportControls?.seekTo(ms)
}
