Optional: drop variable fonts here to replace the Android system fallbacks.
Expected names (see ClockFonts.kt). Recommended OFL fonts:

  clock_sans.ttf       Inter (variable)            ~ SF Pro Display
  clock_rounded.ttf    Nunito (variable)           ~ SF Pro Rounded
  clock_serif.ttf      Source Serif 4 (variable)   ~ New York / SF Serif
  clock_slab.ttf       Roboto Slab (variable)      ~ SF Slab
  clock_condensed.ttf  Roboto Flex / Barlow Cond.  ~ SF Pro Condensed
  clock_stencil.ttf    Stardos Stencil             ~ Stencil
  clock_rails.ttf      any inline / striped face   ~ Rails
  clock_hand.ttf       Caveat (variable)           ~ Handwritten

Missing files are fine: the app falls back to system fonts (Roboto, Noto Serif, Dancing Script)
and emulates Rounded / Stencil / Rails by editing the digit outlines.
