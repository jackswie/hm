package com.glasslock.ui.media

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.glasslock.data.model.GlassStyle
import com.glasslock.ui.glass.GlassGeometry
import com.glasslock.ui.glass.liquidGlass
import com.glasslock.ui.theme.Ink
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
private fun rememberPosition(np: NowPlaying): State<Long> = produceState(np.positionNow(), np) {
    while (true) {
        value = np.positionNow()
        delay(250)
    }
}

private fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

/**
 * Floating Liquid Glass Now Playing card (max 440dp, 28dp corners). Swipe left or right to dismiss it
 * without touching playback. [onOutput] opens the system audio-output switcher.
 */
@Composable
fun NowPlayingCard(
    np: NowPlaying,
    style: GlassStyle,
    interactive: Boolean,
    onDismiss: () -> Unit,
    onOutput: () -> Unit,
    onEditTap: () -> Unit,
    modifier: Modifier = Modifier,
    onArtClick: (() -> Unit)? = null,
) {
    val scope = rememberCoroutineScope()
    val offsetX = remember { Animatable(0f) }
    var widthPx by remember { mutableStateOf(1f) }
    val position by rememberPosition(np)
    val latestInteractive by rememberUpdatedState(interactive)

    Column(
        modifier
            .widthIn(max = 440.dp)
            .fillMaxWidth()
            .offset { IntOffset(offsetX.value.roundToInt(), 0) }
            .graphicsLayer { alpha = 1f - (abs(offsetX.value) / widthPx).coerceIn(0f, 1f) * 0.9f }
            .liquidGlass(GlassGeometry.Rounded(28.dp), style)
            .pointerInput(Unit) {
                widthPx = size.width.toFloat()
                detectHorizontalDragGestures(
                    onDragEnd = {
                        scope.launch {
                            if (abs(offsetX.value) > widthPx * 0.3f) {
                                offsetX.animateTo(if (offsetX.value > 0) widthPx else -widthPx, tween(180))
                                onDismiss()
                                offsetX.snapTo(0f)
                            } else {
                                offsetX.animateTo(0f)
                            }
                        }
                    },
                    onDragCancel = { scope.launch { offsetX.animateTo(0f) } },
                ) { change, drag ->
                    if (latestInteractive) {
                        change.consume()
                        scope.launch { offsetX.snapTo(offsetX.value + drag) }
                    }
                }
            }
            .pointerInput(interactive) { if (!interactive) detectTapGestures { onEditTap() } }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            AlbumArt(np, onArtClick)
            Column(Modifier.weight(1f)) {
                Text(np.title.ifBlank { "Not playing" }, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(np.artist, color = Ink.secondary, fontSize = 14.sp, maxLines = 1)
            }
            SpectrumBars(np.isPlaying)
        }

        val dur = np.durationMs
        val frac = if (dur > 0) position.toFloat() / dur else 0f
        SeekBar(frac, enabled = interactive && dur > 0) { f -> MediaRepository.seekTo((f * dur).toLong()) }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmt(position), color = Ink.secondary, fontSize = 11.sp)
            Text(if (dur > 0) "-" + fmt(dur - position) else "", color = Ink.secondary, fontSize = 11.sp)
        }

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Box(Modifier.size(40.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                GlyphButton(interactive, 46.dp, { MediaRepository.previous() }) { drawSkip(false) }
                GlyphButton(interactive, 56.dp, { MediaRepository.playPause() }) { drawPlayPause(np.isPlaying) }
                GlyphButton(interactive, 46.dp, { MediaRepository.next() }) { drawSkip(true) }
            }
            GlyphButton(interactive, 40.dp, onOutput) { drawOutput() }
        }
    }
}

@Composable
private fun GlyphButton(enabled: Boolean, size: androidx.compose.ui.unit.Dp, onClick: () -> Unit, draw: DrawScope.() -> Unit) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(50)).then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(size * 0.5f)) { draw() }
    }
}

@Composable
private fun AlbumArt(np: NowPlaying, onClick: (() -> Unit)?) {
    val shape = RoundedCornerShape(10.dp)
    val art = remember(np.art) { np.art?.asImageBitmap() }
    Box(
        Modifier.size(54.dp).clip(shape).background(Color.White.copy(alpha = 0.18f))
            .then(if (onClick != null && art != null) Modifier.clickable(onClick = onClick) else Modifier),
        contentAlignment = Alignment.Center,
    ) {
        if (art != null) Image(art, null, Modifier.size(54.dp), contentScale = ContentScale.Crop) else Text("♪", color = Color.White, fontSize = 22.sp)
    }
}

/** Animated bars. They show playback state; they are not an audio-FFT (that would need RECORD_AUDIO). */
@Composable
private fun SpectrumBars(active: Boolean) {
    val t = rememberInfiniteTransition(label = "bars")
    val heights = listOf(420, 560, 360, 480).mapIndexed { i, ms ->
        t.animateFloat(0.25f, 1f, infiniteRepeatable(tween(ms, easing = LinearEasing), RepeatMode.Reverse), label = "b$i")
    }
    Canvas(Modifier.size(width = 22.dp, height = 18.dp)) {
        val bw = 3.dp.toPx()
        heights.forEachIndexed { i, h ->
            val hh = size.height * if (active) h.value else 0.2f
            drawRoundRect(
                Color.White.copy(alpha = 0.8f),
                Offset(i * (bw + 2.dp.toPx()), size.height - hh), Size(bw, hh), CornerRadius(bw / 2),
            )
        }
    }
}

@Composable
private fun SeekBar(fraction: Float, enabled: Boolean, onSeek: (Float) -> Unit) {
    var dragging by remember { mutableStateOf<Float?>(null) }
    val latestSeek by rememberUpdatedState(onSeek)
    Canvas(
        Modifier.fillMaxWidth().height(22.dp)
            .pointerInput(enabled) { if (enabled) detectTapGestures { latestSeek((it.x / size.width).coerceIn(0f, 1f)) } }
            .pointerInput(enabled) {
                if (enabled) detectHorizontalDragGestures(
                    onDragStart = { dragging = (it.x / size.width).coerceIn(0f, 1f) },
                    onDragEnd = { dragging?.let(latestSeek); dragging = null },
                    onDragCancel = { dragging = null },
                ) { c, _ ->
                    c.consume()
                    dragging = (c.position.x / size.width).coerceIn(0f, 1f)
                }
            }
    ) {
        val f = (dragging ?: fraction).coerceIn(0f, 1f)
        val th = 4.dp.toPx()
        val y = size.height / 2f
        drawLine(Color.White.copy(alpha = 0.28f), Offset(0f, y), Offset(size.width, y), th, StrokeCap.Round)
        drawLine(Color.White, Offset(0f, y), Offset(size.width * f, y), th, StrokeCap.Round)
        if (dragging != null) drawCircle(Color.White, 7.dp.toPx(), Offset(size.width * f, y))
    }
}

// ---- Canvas icons ---------------------------------------------------------------------------

private fun DrawScope.drawPlayPause(playing: Boolean) {
    if (playing) {
        val w = size.width * 0.28f
        drawRoundRect(Color.White, Offset(size.width * 0.1f, 0f), Size(w, size.height), CornerRadius(w * 0.25f))
        drawRoundRect(Color.White, Offset(size.width * 0.62f, 0f), Size(w, size.height), CornerRadius(w * 0.25f))
    } else {
        drawPath(Path().apply {
            moveTo(size.width * 0.15f, 0f); lineTo(size.width, size.height / 2f); lineTo(size.width * 0.15f, size.height); close()
        }, Color.White)
    }
}

private fun DrawScope.drawSkip(forward: Boolean) {
    val w = size.width
    val h = size.height
    fun tri(x: Float) = Path().apply {
        if (forward) { moveTo(x, h * 0.1f); lineTo(x + w * 0.5f, h / 2f); lineTo(x, h * 0.9f) }
        else { moveTo(x + w * 0.5f, h * 0.1f); lineTo(x, h / 2f); lineTo(x + w * 0.5f, h * 0.9f) }
        close()
    }
    drawPath(tri(0f), Color.White)
    drawPath(tri(w * 0.48f), Color.White)
}

/** AirPlay-style output glyph: two arcs and a triangle. */
private fun DrawScope.drawOutput() {
    val s = Stroke(2.dp.toPx(), cap = StrokeCap.Round)
    drawArc(Color.White, 200f, 140f, false, Offset(size.width * 0.05f, size.height * 0.05f), Size(size.width * 0.9f, size.height * 0.9f), style = s)
    drawArc(Color.White, 215f, 110f, false, Offset(size.width * 0.25f, size.height * 0.25f), Size(size.width * 0.5f, size.height * 0.5f), style = s)
    drawPath(Path().apply {
        moveTo(size.width * 0.25f, size.height); lineTo(size.width * 0.5f, size.height * 0.62f); lineTo(size.width * 0.75f, size.height); close()
    }, Color.White)
}
