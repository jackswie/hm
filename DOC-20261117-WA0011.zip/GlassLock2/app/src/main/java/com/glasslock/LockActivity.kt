package com.glasslock

import android.app.KeyguardManager
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.glasslock.ui.AppActions
import com.glasslock.ui.LocalAppActions
import com.glasslock.ui.editor.EditorScreen
import com.glasslock.ui.editor.EditorViewModel
import com.glasslock.ui.media.MediaRepository
import com.glasslock.ui.theme.GlassLockTheme

/**
 * The replacement lock screen. It is shown above the system keyguard; swiping up calls
 * KeyguardManager.requestDismissKeyguard, so PIN / pattern / biometrics are still handled by Android.
 */
class LockActivity : ComponentActivity() {
    private val viewModel: EditorViewModel by viewModels()
    private var resetKey by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        enableEdgeToEdge()
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = Unit // the lock screen cannot be backed out of
        })
        MediaRepository.start(this)

        val actions = AppActions(
            launch = { intent -> unlock { startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } },
            requestLocation = { unlock { startActivity(Intent(this, MainActivity::class.java)) } },
            openNotificationAccess = {
                unlock { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            },
            pickPhotos = {},
            unlockThen = { block -> unlock(block) },
        )

        setContent {
            GlassLockTheme {
                CompositionLocalProvider(LocalAppActions provides remember { actions }) {
                    EditorScreen(
                        vm = viewModel,
                        lockMode = true,
                        lockResetKey = resetKey,
                        onUnlock = { unlock() },
                        onCustomizeFromLock = {
                            unlock { startActivity(Intent(this, MainActivity::class.java).putExtra(MainActivity.EXTRA_GALLERY, true)) }
                        },
                    )
                }
            }
        }
    }

    private fun unlock(then: (() -> Unit)? = null) {
        val keyguard = getSystemService(KeyguardManager::class.java)
        keyguard.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() {
                then?.invoke()
                finish()
            }

            override fun onDismissCancelled() {
                resetKey++ // user backed out of the PIN prompt: drop the lock screen back into place
            }

            override fun onDismissError() {
                resetKey++
            }
        })
    }
}
