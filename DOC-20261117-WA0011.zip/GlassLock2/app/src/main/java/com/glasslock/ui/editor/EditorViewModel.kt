package com.glasslock.ui.editor

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import android.text.format.DateFormat
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.glasslock.data.model.CLOCK_MAX_HEIGHT
import com.glasslock.data.model.CLOCK_MIN_HEIGHT
import com.glasslock.data.model.ClockConfig
import com.glasslock.data.model.GlassStyle
import com.glasslock.data.model.LockProfile
import com.glasslock.data.model.ProfileStore
import com.glasslock.data.model.QuickActionConfig
import com.glasslock.data.model.WallpaperConfig
import com.glasslock.data.model.WallpaperFilter
import com.glasslock.data.model.WallpaperKind
import com.glasslock.data.model.WidgetConfig
import com.glasslock.data.model.WidgetSize
import com.glasslock.data.model.WidgetType
import com.glasslock.ui.clock.CutoutRepository
import com.glasslock.ui.clock.DemoWallpaper
import com.glasslock.ui.clock.WallpaperFactory
import com.glasslock.ui.clock.WallpaperLoader
import com.glasslock.ui.glass.Palette
import com.glasslock.ui.glass.WallpaperPalette
import com.glasslock.ui.widgets.WidgetGrid
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

/** Which configurator is open. */
sealed interface Sheet {
    data object None : Sheet
    data object Clock : Sheet
    data object AddWidget : Sheet
    data object Media : Sheet
    data object Notifications : Sheet
    data object Status : Sheet
    data object Wallpaper : Sheet
    data object NewProfile : Sheet
    data class Widget(val id: String) : Sheet
    data class Quick(val left: Boolean) : Sheet
    data class Focus(val profileId: String) : Sheet
}

/** Lock screen types offered by the gallery's "+" button. */
enum class NewKind(val label: String) {
    PHOTO("Photo"), WEATHER("Weather"), ASTRONOMY("Astronomy"), EMOJI("Emoji"), GRADIENT("Color Gradient"), EXTENDED("Extended Photo")
}

data class EditorUiState(
    val profiles: List<LockProfile> = listOf(LockProfile()),
    /** The active profile; always one of [profiles]. */
    val profile: LockProfile = LockProfile(),
    val committedProfiles: List<LockProfile> = emptyList(),
    val committedActiveId: String = "",
    val editing: Boolean = false,
    val galleryOpen: Boolean = false,
    val sheet: Sheet = Sheet.None,
    val thumbs: Map<String, ImageBitmap> = emptyMap(),
    val wallpaper: ImageBitmap? = null,
    val cutout: ImageBitmap? = null,
    val palette: Palette = Palette.Default,
    val segmenting: Boolean = false,
    val gridRows: Int = 6,
    val notice: String? = null,
    /** Track whose card the user swiped away; the card returns when the track changes. */
    val dismissedMediaKey: String? = null,
)

class EditorViewModel(app: Application) : AndroidViewModel(app) {
    private val store = ProfileStore(app)
    private val cutouts = CutoutRepository(app)

    private val _ui = MutableStateFlow(EditorUiState())
    val ui: StateFlow<EditorUiState> = _ui.asStateFlow()

    private var loadJob: Job? = null
    private var sourceBitmap: Bitmap? = null
    private var pendingKind: NewKind? = null
    private var openGalleryWhenReady = false

    init {
        viewModelScope.launch {
            var list = store.profiles.first()
            if (list.isEmpty()) list = listOf(LockProfile(clock = ClockConfig(use24Hour = DateFormat.is24HourFormat(app))))
            val active = list.firstOrNull { it.id == store.activeId.first() } ?: list.first()
            _ui.update { it.copy(profiles = list, profile = active, committedProfiles = list, committedActiveId = active.id) }
            loadAssets(active)
            if (openGalleryWhenReady) openGallery()
        }
    }

    private fun updateProfile(f: (LockProfile) -> LockProfile) = _ui.update { s ->
        val p = f(s.profile)
        s.copy(profile = p, profiles = s.profiles.map { if (it.id == p.id) p else it })
    }

    private fun persist() {
        val s = _ui.value
        viewModelScope.launch { store.save(s.profiles, s.profile.id) }
    }

    // ---- editing session -------------------------------------------------------------------

    fun startEdit() = _ui.update { it.copy(editing = true, galleryOpen = false, committedProfiles = it.profiles, committedActiveId = it.profile.id) }

    fun cancelEdit() {
        val s = _ui.value
        val restored = s.committedProfiles.firstOrNull { it.id == s.committedActiveId } ?: s.committedProfiles.firstOrNull() ?: return
        val neutral = { w: WallpaperConfig -> w.copy(zoom = 1f, panX = 0f, panY = 0f, filter = WallpaperFilter.NATURAL, dim = false, blur = false, extend = false) }
        val assetsChanged = neutral(restored.wallpaper) != neutral(s.profile.wallpaper)
        _ui.update { it.copy(profiles = s.committedProfiles, profile = restored, editing = false, sheet = Sheet.None) }
        if (assetsChanged) loadAssets(restored)
    }

    fun finishEdit() {
        _ui.update { it.copy(editing = false, sheet = Sheet.None, committedProfiles = it.profiles, committedActiveId = it.profile.id) }
        persist()
    }

    fun openSheet(sheet: Sheet) = _ui.update { it.copy(sheet = sheet) }
    fun closeSheet() = _ui.update { it.copy(sheet = Sheet.None) }
    fun clearNotice() = _ui.update { it.copy(notice = null) }
    fun setGridRows(rows: Int) { if (rows != _ui.value.gridRows) _ui.update { it.copy(gridRows = rows) } }

    // ---- gallery & profiles ----------------------------------------------------------------

    fun requestGalleryOnLoad() { openGalleryWhenReady = true }

    fun openGallery() {
        _ui.update { it.copy(galleryOpen = true, sheet = Sheet.None) }
        loadThumbs()
    }

    fun closeGallery() {
        _ui.update { it.copy(galleryOpen = false, sheet = Sheet.None) }
        persist()
    }

    fun selectProfile(id: String) {
        val s = _ui.value
        if (id == s.profile.id) return
        val target = s.profiles.firstOrNull { it.id == id } ?: return
        _ui.update { it.copy(profile = target) }
        loadAssets(target)
    }

    /** Returns true when the caller must open the photo picker next. */
    fun addProfile(kind: NewKind): Boolean {
        if (kind == NewKind.PHOTO || kind == NewKind.EXTENDED) {
            pendingKind = kind
            return true
        }
        val wp = WallpaperConfig(
            kind = when (kind) {
                NewKind.WEATHER -> WallpaperKind.WEATHER
                NewKind.ASTRONOMY -> WallpaperKind.ASTRONOMY
                NewKind.EMOJI -> WallpaperKind.EMOJI
                else -> WallpaperKind.GRADIENT
            }
        )
        createProfile(wp)
        return false
    }

    private fun createProfile(wp: WallpaperConfig) {
        val base = _ui.value.profile
        val p = base.copy(
            id = UUID.randomUUID().toString(),
            name = "Lock Screen ${_ui.value.profiles.size + 1}",
            wallpaper = wp,
            focusEmoji = "",
            focusLabel = "",
        )
        _ui.update { it.copy(profiles = it.profiles + p, profile = p, sheet = Sheet.None) }
        loadAssets(p)
        loadThumbs()
        persist()
    }

    fun deleteProfile(id: String) {
        val s = _ui.value
        if (s.profiles.size <= 1) {
            _ui.update { it.copy(notice = "You need at least one lock screen.") }
            return
        }
        val remaining = s.profiles.filter { it.id != id }
        val newActive = if (s.profile.id == id) remaining.first() else s.profile
        _ui.update { it.copy(profiles = remaining, profile = newActive) }
        if (s.profile.id == id) loadAssets(newActive)
        loadThumbs()
        persist()
    }

    fun setFocus(profileId: String, emoji: String, label: String) {
        _ui.update { s ->
            val profiles = s.profiles.map { if (it.id == profileId) it.copy(focusEmoji = emoji, focusLabel = label) else it }
            s.copy(profiles = profiles, profile = profiles.first { it.id == s.profile.id })
        }
    }

    private fun loadThumbs() {
        viewModelScope.launch {
            val profiles = _ui.value.profiles
            val map = withContext(Dispatchers.Default) {
                profiles.associate { p -> p.id to thumbnail(p).asImageBitmap() }
            }
            _ui.update { it.copy(thumbs = map) }
        }
    }

    private fun thumbnail(p: LockProfile): Bitmap {
        val file = p.wallpaper.file?.let(::File)?.takeIf { it.exists() }
        return when {
            p.wallpaper.kind != WallpaperKind.PHOTO -> WallpaperFactory.create(p.wallpaper, 640, 400)
            file != null -> WallpaperLoader.decode(file, 640)
            else -> DemoWallpaper.create(960, 600).first
        }
    }

    // ---- clock ---------------------------------------------------------------------------------

    fun updateClock(transform: (ClockConfig) -> ClockConfig) {
        val before = _ui.value.profile.clock
        val after = transform(before)
        updateProfile { it.copy(clock = after) }
        if (after.depthEffect && !before.depthEffect) ensureCutout()
    }

    /** Corner-drag resize. [deltaFraction] is the vertical drag as a fraction of screen height. */
    fun resizeClock(deltaFraction: Float) = updateClock {
        it.copy(heightFraction = (it.heightFraction + deltaFraction).coerceIn(CLOCK_MIN_HEIGHT, CLOCK_MAX_HEIGHT))
    }

    // ---- wallpaper editing -----------------------------------------------------------------

    fun updateWallpaper(f: (WallpaperConfig) -> WallpaperConfig) {
        val before = _ui.value.profile.wallpaper
        val after = f(before)
        updateProfile { it.copy(wallpaper = after) }
        if (after.kind != WallpaperKind.PHOTO &&
            (after.emoji != before.emoji || after.color1 != before.color1 || after.color2 != before.color2)
        ) loadAssets(_ui.value.profile)
    }

    /** Two-finger pinch/pan. Pan arrives as a fraction of the screen. */
    fun transformWallpaper(zoomFactor: Float, panX: Float, panY: Float) = updateWallpaper {
        val z = (it.zoom * zoomFactor).coerceIn(1f, 4f)
        val limit = (z - 1f) / 2f
        it.copy(zoom = z, panX = (it.panX + panX).coerceIn(-limit, limit), panY = (it.panY + panY).coerceIn(-limit, limit))
    }

    fun resetWallpaperView() = updateWallpaper { it.copy(zoom = 1f, panX = 0f, panY = 0f) }

    /** Swipe left/right while editing steps through Natural, B&W, Duotone, Color Wash. */
    fun cycleFilter(direction: Int) = updateWallpaper {
        val all = WallpaperFilter.entries
        it.copy(filter = all[(it.filter.ordinal + direction + all.size) % all.size])
    }

    fun importWallpaper(uri: Uri) {
        viewModelScope.launch {
            val file = withContext(Dispatchers.IO) { WallpaperLoader.importFrom(getApplication(), uri) }
            val kind = pendingKind
            pendingKind = null
            if (kind != null) {
                createProfile(WallpaperConfig(file = file.absolutePath, extend = kind == NewKind.EXTENDED))
            } else {
                val profile = _ui.value.profile.let { p ->
                    p.copy(wallpaper = p.wallpaper.copy(file = file.absolutePath, kind = WallpaperKind.PHOTO, zoom = 1f, panX = 0f, panY = 0f))
                }
                _ui.update { it.copy(profile = profile, profiles = it.profiles.map { o -> if (o.id == profile.id) profile else o }) }
                loadAssets(profile)
            }
        }
    }

    // ---- widgets -------------------------------------------------------------------------------

    fun addWidget(type: WidgetType) {
        val s = _ui.value
        val size = type.sizes.firstOrNull { WidgetGrid.firstFree(s.profile.widgets, it, s.gridRows) != null }
        val spot = size?.let { WidgetGrid.firstFree(s.profile.widgets, it, s.gridRows) }
        if (size == null || spot == null) {
            _ui.update { it.copy(notice = "The widget rail is full. Remove or shrink a widget first.", sheet = Sheet.None) }
            return
        }
        val widget = WidgetConfig(type = type, size = size, col = spot.first, row = spot.second)
        updateProfile { it.copy(widgets = it.widgets + widget) }
        _ui.update { it.copy(sheet = Sheet.Widget(widget.id)) }
    }

    fun updateWidget(id: String, f: (WidgetConfig) -> WidgetConfig) =
        updateProfile { p -> p.copy(widgets = p.widgets.map { if (it.id == id) f(it) else it }) }

    fun moveWidget(id: String, col: Int, row: Int) = updateWidget(id) { it.copy(col = col, row = row) }

    fun resizeWidget(id: String, size: WidgetSize) {
        val s = _ui.value
        val w = s.profile.widgets.firstOrNull { it.id == id } ?: return
        if (WidgetGrid.fits(s.profile.widgets, id, size, w.col, w.row, s.gridRows)) {
            updateWidget(id) { it.copy(size = size) }
            return
        }
        val spot = WidgetGrid.firstFree(s.profile.widgets.filter { it.id != id }, size, s.gridRows)
        if (spot != null) updateWidget(id) { it.copy(size = size, col = spot.first, row = spot.second) }
        else _ui.update { it.copy(notice = "No room for that size on the rail.") }
    }

    fun deleteWidget(id: String) {
        updateProfile { p -> p.copy(widgets = p.widgets.filter { it.id != id }) }
        closeSheet()
    }

    fun addWidgetPhotos(id: String, uris: List<Uri>) {
        viewModelScope.launch {
            val files = withContext(Dispatchers.IO) {
                uris.mapNotNull { runCatching { WallpaperLoader.importFrom(getApplication(), it).absolutePath }.getOrNull() }
            }
            updateWidget(id) { it.copy(photos = (it.photos + files).takeLast(8)) }
        }
    }

    // ---- other surfaces ------------------------------------------------------------------------

    fun updateQuick(left: Boolean, f: (QuickActionConfig) -> QuickActionConfig) =
        updateProfile { if (left) it.copy(quickLeft = f(it.quickLeft)) else it.copy(quickRight = f(it.quickRight)) }

    fun updateMediaStyle(f: (GlassStyle) -> GlassStyle) = updateProfile { it.copy(mediaStyle = f(it.mediaStyle)) }
    fun updateNotificationStyle(f: (GlassStyle) -> GlassStyle) = updateProfile { it.copy(notificationStyle = f(it.notificationStyle)) }
    fun setStatusText(text: String) = updateProfile { it.copy(statusText = text) }
    fun setInlineText(text: String) = updateProfile { it.copy(inlineText = text) }
    fun dismissMedia(key: String) = _ui.update { it.copy(dismissedMediaKey = key) }

    // ---- assets --------------------------------------------------------------------------------

    private fun loadAssets(profile: LockProfile) {
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            val wp = profile.wallpaper
            val file = wp.file?.let(::File)?.takeIf { it.exists() }
            val (background, cutout) = withContext(Dispatchers.Default) {
                when {
                    wp.kind != WallpaperKind.PHOTO -> WallpaperFactory.create(wp) to null
                    file == null -> DemoWallpaper.create()
                    else -> WallpaperLoader.decode(file) to cutouts.cached(file)
                }
            }
            val palette = withContext(Dispatchers.Default) { WallpaperPalette.from(background) }
            sourceBitmap = background
            _ui.update {
                it.copy(wallpaper = background.asImageBitmap(), cutout = cutout?.asImageBitmap(), palette = palette, segmenting = false)
            }
            if (file != null && wp.kind == WallpaperKind.PHOTO && cutout == null && profile.clock.depthEffect) ensureCutout()
        }
    }

    /** Runs ML Kit once per photo; the result is cached on disk. */
    private fun ensureCutout() {
        val state = _ui.value
        val file = state.profile.wallpaper.file?.let(::File)?.takeIf { it.exists() } ?: return
        val source = sourceBitmap ?: return
        if (state.cutout != null || state.segmenting) return
        _ui.update { it.copy(segmenting = true) }
        viewModelScope.launch {
            val cut = cutouts.generate(file, source)
            _ui.update { it.copy(segmenting = false, cutout = cut?.asImageBitmap()) }
        }
    }
}
