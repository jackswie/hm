package com.glasslock.ui.clock

import android.content.Context
import android.graphics.Typeface
import com.glasslock.data.model.ClockFontId

/** Extra outline treatment for faces Android has no system font for. */
enum class GlyphEffect { NONE, ROUND, STENCIL, RAILS }

/**
 * One selectable clock face.
 *
 * Resolution order: (1) a variable font you drop into app/src/main/assets/<assetPath>, using its
 * real `wght` axis; (2) the Android system family, with weight applied through the platform.
 * SF Pro / New York are Apple-licensed and cannot be shipped, so use OFL look-alikes (see README):
 * Inter, Nunito, Source Serif 4, Roboto Slab, Barlow Condensed / Roboto Flex, Stardos Stencil, Caveat.
 */
data class ClockFontSpec(
    val id: ClockFontId,
    val label: String,
    val systemFamily: String,
    val assetPath: String,
    val effect: GlyphEffect = GlyphEffect.NONE,
    val weightBias: Int = 0,
)

object ClockFonts {
    val all: List<ClockFontSpec> = listOf(
        ClockFontSpec(ClockFontId.SF_PRO, "SF Pro", "sans-serif", "fonts/clock_sans.ttf"),
        ClockFontSpec(ClockFontId.ROUNDED, "Rounded", "sans-serif", "fonts/clock_rounded.ttf", GlyphEffect.ROUND),
        ClockFontSpec(ClockFontId.SERIF, "Serif", "serif", "fonts/clock_serif.ttf"),
        ClockFontSpec(ClockFontId.SLAB, "Slab", "serif", "fonts/clock_slab.ttf", weightBias = 150),
        ClockFontSpec(ClockFontId.CONDENSED, "Condensed", "sans-serif-condensed", "fonts/clock_condensed.ttf"),
        ClockFontSpec(ClockFontId.STENCIL, "Stencil", "sans-serif-condensed", "fonts/clock_stencil.ttf", GlyphEffect.STENCIL, 100),
        ClockFontSpec(ClockFontId.RAILS, "Rails", "sans-serif", "fonts/clock_rails.ttf", GlyphEffect.RAILS, 100),
        ClockFontSpec(ClockFontId.HANDWRITTEN, "Handwritten", "cursive", "fonts/clock_hand.ttf"),
    )

    fun spec(id: ClockFontId): ClockFontSpec = all.first { it.id == id }

    fun effectiveWeight(spec: ClockFontSpec, weight: Int): Int = (weight + spec.weightBias).coerceIn(1, 1000)
}

object ClockTypefaces {
    private val cache = HashMap<String, Typeface>()

    @Synchronized
    fun create(context: Context, spec: ClockFontSpec, weight: Int): Typeface {
        val w = ClockFonts.effectiveWeight(spec, weight)
        return cache.getOrPut("${spec.id}:$w") {
            val fromAsset = runCatching {
                Typeface.Builder(context.applicationContext.assets, spec.assetPath)
                    .setFontVariationSettings("'wght' $w")
                    .setWeight(w)
                    .build()
            }.getOrNull()
            fromAsset ?: Typeface.create(Typeface.create(spec.systemFamily, Typeface.NORMAL), w, false)
        }
    }
}
