package com.glasslock.ui.editor

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.glasslock.data.model.GlassStyle
import com.glasslock.service.LockNotification
import com.glasslock.service.NotificationRepository
import com.glasslock.ui.LocalAppActions
import com.glasslock.ui.clock.ClockPlacement
import com.glasslock.ui.clock.ClockText
import com.glasslock.ui.clock.DepthLockScene
import com.glasslock.ui.clock.rememberNow
import com.glasslock.ui.gallery.GalleryOverlay
import com.glasslock.ui.glass.GlassGeometry
import com.glasslock.ui.glass.liquidGlass
import com.glasslock.ui.media.MediaRepository
import com.glasslock.ui.media.NowPlaying
import com.glasslock.ui.media.NowPlayingCard
import com.glasslock.ui.notifications.NotificationStack
import com.glasslock.ui.theme.Ink
import com.glasslock.ui.widgets.DateHeader
import com.glasslock.ui.widgets.HomeIndicator
import com.glasslock.ui.widgets.QuickActionButton
import com.glasslock.ui.widgets.StatusBar
import com.glasslock.ui.widgets.StatusPill
import com.glasslock.ui.widgets.WidgetRail
import com.glasslock.ui.widgets.WidgetRow
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * The lock screen and its editor, shared by the app ([lockMode] = false) and the real lock window ([lockMode] = true).
 *
 * App: long-press opens the wallpaper gallery. Editing: tap any element to configure it, drag widgets to snap them
 * to the grid, drag the clock's corner handle to resize, pinch to zoom the wallpaper, swipe sideways to change filter.
 * Lock: swipe up from the bottom edge to unlock; long-press hands over to the app's gallery.
 */
@Composable
fun EditorScreen(
    vm: EditorViewModel,
    lockMode: Boolean = false,
    lockResetKey: Int = 0,
    onPickPhoto: () -> Unit = {},
    onUnlock: () -> Unit = {},
    onCustomizeFromLock: () -> Unit = {},
) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val time by rememberNow()
    val media by MediaRepository.state.collectAsStateWithLifecycle()
    val hasMediaAccess by MediaRepository.hasAccess.collectAsStateWithLifecycle()
    val notifications by NotificationRepository.state.collectAsStateWithLifecycle()
    val actions = LocalAppActions.current
    val scope = rememberCoroutineScope()
    var artOpen by remember { mutableStateOf(false) }
    val unlockY = remember(lockResetKey) { Animatable(0f) }
    val wallpaper = ui.wallpaper

    if (wallpaper == null) {
        Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Color.White)
        }
        return
    }

    LaunchedEffect(ui.notice) {
        if (ui.notice != null) {
            delay(3000)
            vm.clearNotice()
        }
    }

    val profile = ui.profile
    val editing = ui.editing && !lockMode

    val wallpaperGestures = if (editing) {
        Modifier.pointerInput(Unit) {
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed = false)
                var totalDx = 0f
                var multi = false
                do {
                    val event = awaitPointerEvent()
                    if (event.changes.count { it.pressed } >= 2) {
                        multi = true
                        val pan = event.calculatePan()
                        vm.transformWallpaper(event.calculateZoom(), pan.x / size.width, pan.y / size.height)
                        event.changes.forEach { it.consume() }
                    } else if (!multi) {
                        totalDx += event.changes.first().positionChange().x
                    }
                } while (event.changes.any { it.pressed })
                if (!multi && abs(totalDx) > 160f) vm.cycleFilter(if (totalDx < 0) 1 else -1)
            }
        }
    } else Modifier

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    // Swipe-up unlock: the whole screen follows the finger, fades and shrinks slightly.
                    val p = (-unlockY.value / size.height).coerceIn(0f, 1f)
                    translationY = unlockY.value
                    alpha = 1f - p * 0.7f
                    scaleX = 1f - p * 0.05f
                    scaleY = 1f - p * 0.05f
                }
                .pointerInput(editing, ui.galleryOpen, lockMode) {
                    if (!editing && !ui.galleryOpen) {
                        detectTapGestures(onLongPress = { if (lockMode) onCustomizeFromLock() else vm.openGallery() })
                    }
                }
        ) {
            DepthLockScene(
                wallpaper = wallpaper,
                cutout = ui.cutout,
                wallpaperConfig = profile.wallpaper,
                clock = profile.clock,
                palette = ui.palette,
                time = time,
                onClockClick = if (editing) ({ vm.openSheet(Sheet.Clock) }) else null,
                wallpaperGestures = wallpaperGestures,
            ) { placement ->
                val density = LocalDensity.current
                val landscape = placement.screen.width >= placement.screen.height

                StatusBar(Modifier.align(Alignment.TopEnd).windowInsetsPadding(WindowInsets.safeDrawing))

                if (lockMode) {
                    Text(
                        "🔒  Swipe up to unlock", color = Color.White, fontSize = 15.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.align(Alignment.TopCenter).windowInsetsPadding(WindowInsets.safeDrawing).padding(top = 12.dp),
                    )
                }

                DateHeader(
                    inline = profile.inlineText,
                    modifier = Modifier
                        .offset { IntOffset(placement.box.left.roundToInt(), (placement.box.top - 40.dp.toPx()).roundToInt()) }
                        .width(with(density) { placement.box.width.toDp() })
                        .then(if (editing) Modifier.clickable { vm.openSheet(Sheet.Status) } else Modifier),
                )

                // ---- widgets ----
                if (landscape) {
                    val railW = with(density) { (placement.box.left - 16.dp.toPx()).coerceAtLeast(0f).toDp() }
                    val availH = with(density) { (placement.screen.height - 120.dp.toPx() - 110.dp.toPx()).coerceAtLeast(0f).toDp() }
                    WidgetRail(
                        widgets = profile.widgets,
                        editing = editing,
                        selectedId = (ui.sheet as? Sheet.Widget)?.id,
                        railWidth = railW,
                        availableHeight = availH,
                        onRows = vm::setGridRows,
                        onMove = vm::moveWidget,
                        onTap = { vm.openSheet(Sheet.Widget(it)) },
                        modifier = Modifier.offset(16.dp, 64.dp),
                    )
                } else {
                    WidgetRow(
                        widgets = profile.widgets,
                        editing = editing,
                        selectedId = (ui.sheet as? Sheet.Widget)?.id,
                        onTap = { vm.openSheet(Sheet.Widget(it)) },
                        modifier = Modifier.offset { IntOffset(0, (placement.box.bottom + 24.dp.toPx()).roundToInt()) },
                    )
                }

                // ---- notifications (bottom) + media card and focus pill (above them) ----
                val shownNotifs: List<LockNotification> = when {
                    lockMode -> notifications
                    editing -> listOf(LockNotification.Sample)
                    else -> emptyList()
                }
                val cardW = with(density) { minOf(440.dp.toPx(), placement.box.width * 0.96f).toDp() }
                val shown: NowPlaying? = when {
                    media.hasSession && media.key != ui.dismissedMediaKey -> media
                    editing && !media.hasSession -> NowPlaying.Sample
                    else -> null
                }
                LaunchedEffect(shown == null) { if (shown == null) artOpen = false }

                Column(
                    Modifier
                        .offset {
                            val top = if (shownNotifs.isNotEmpty()) 0.50f else 0.66f
                            IntOffset((placement.box.center.x - cardW.toPx() / 2f).roundToInt(), (placement.screen.height * top).roundToInt())
                        }
                        .width(cardW),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    if (shown != null) {
                        NowPlayingCard(
                            np = shown,
                            style = profile.mediaStyle,
                            interactive = !editing,
                            onDismiss = { vm.dismissMedia(shown.key) },
                            onOutput = { outputSwitcher(actions.launch) },
                            onEditTap = { vm.openSheet(Sheet.Media) },
                            onArtClick = { artOpen = true },
                        )
                    } else if (!hasMediaAccess && !editing && !lockMode) {
                        EnableMediaCard(actions.openNotificationAccess)
                    }
                    val pill = if (profile.focusLabel.isNotBlank()) "${profile.focusEmoji} ${profile.focusLabel}".trim() else profile.statusText
                    if (pill.isNotBlank()) {
                        StatusPill(pill, Modifier.padding(top = 10.dp).then(if (editing) Modifier.clickable { vm.openSheet(Sheet.Status) } else Modifier))
                    }
                }

                if (shownNotifs.isNotEmpty()) {
                    NotificationStack(
                        items = shownNotifs,
                        style = profile.notificationStyle,
                        interactive = !editing,
                        onOpen = { n -> actions.unlockThen { runCatching { n.intent?.send() }; NotificationRepository.remove(n.key) } },
                        onDismiss = { n -> NotificationRepository.dismiss(n.key) },
                        onEditTap = { vm.openSheet(Sheet.Notifications) },
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .offset { IntOffset((placement.box.center.x - cardW.toPx() / 2f).roundToInt(), -64.dp.roundToPx()) }
                            .width(cardW),
                    )
                }

                QuickActionButton(
                    profile.quickLeft, editing, { vm.openSheet(Sheet.Quick(true)) },
                    Modifier.align(Alignment.BottomStart).padding(start = 28.dp, bottom = 28.dp),
                )
                QuickActionButton(
                    profile.quickRight, editing, { vm.openSheet(Sheet.Quick(false)) },
                    Modifier.align(Alignment.BottomEnd).padding(end = 28.dp, bottom = 28.dp),
                )
                HomeIndicator(Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp))

                // Swipe-up unlock strip along the bottom edge (lock window only).
                if (lockMode) {
                    var lastDy by remember { mutableStateOf(0f) }
                    Box(
                        Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .height(96.dp)
                            .pointerInput(lockResetKey) {
                                detectVerticalDragGestures(
                                    onDragEnd = {
                                        scope.launch {
                                            val travelled = -unlockY.value
                                            if (travelled > placement.screen.height * 0.18f || lastDy < -22f) {
                                                unlockY.animateTo(-placement.screen.height, tween(220))
                                                onUnlock()
                                            } else {
                                                unlockY.animateTo(0f, spring(dampingRatio = 0.6f, stiffness = 300f))
                                            }
                                        }
                                    },
                                    onDragCancel = { scope.launch { unlockY.animateTo(0f, spring(dampingRatio = 0.6f)) } },
                                ) { change, dy ->
                                    change.consume()
                                    lastDy = dy
                                    // Gentle resistance when dragging down, direct follow when dragging up.
                                    val next = unlockY.value + if (dy > 0) dy * 0.3f else dy
                                    scope.launch { unlockY.snapTo(next.coerceAtMost(0f)) }
                                }
                            }
                    )
                }

                if (!editing && !lockMode) {
                    Text(
                        "Touch and hold to open the gallery",
                        color = Ink.secondary, fontSize = 13.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 30.dp),
                    )
                }
                if (editing) {
                    SelectionFrame(placement)
                    ResizeHandle(placement) { dy -> vm.resizeClock(dy / placement.screen.height) }
                    EditTopBar(
                        onCancel = vm::cancelEdit,
                        onDone = vm::finishEdit,
                        onWallpaper = { vm.openSheet(Sheet.Wallpaper) },
                        onAdd = { vm.openSheet(Sheet.AddWidget) },
                    )
                }

                // ---- album art, enlarged ----
                val art = remember(shown?.art) { shown?.art?.asImageBitmap() }
                AnimatedVisibility(
                    visible = artOpen && art != null,
                    enter = fadeIn(tween(180)) + scaleIn(tween(220), initialScale = 0.7f),
                    exit = fadeOut(tween(150)) + scaleOut(tween(150), targetScale = 0.7f),
                ) {
                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.6f))
                            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { artOpen = false },
                        contentAlignment = Alignment.Center,
                    ) {
                        art?.let {
                            val side = with(density) { (minOf(placement.screen.width, placement.screen.height) * 0.7f).toDp() }
                            Image(it, null, Modifier.size(side).clip(RoundedCornerShape(32.dp)), contentScale = ContentScale.Crop)
                        }
                    }
                }

                // ---- gallery ----
                AnimatedVisibility(
                    visible = ui.galleryOpen && !lockMode,
                    enter = fadeIn(tween(220)) + scaleIn(tween(300), initialScale = 1.35f),
                    exit = fadeOut(tween(180)) + scaleOut(tween(220), targetScale = 1.35f),
                ) {
                    GalleryOverlay(
                        profiles = ui.profiles,
                        activeId = profile.id,
                        thumbs = ui.thumbs,
                        palette = ui.palette,
                        timeText = ClockText.format(time, profile.clock.use24Hour),
                        onSelect = vm::selectProfile,
                        onCustomize = vm::startEdit,
                        onAdd = { vm.openSheet(Sheet.NewProfile) },
                        onDelete = vm::deleteProfile,
                        onFocus = { vm.openSheet(Sheet.Focus(it)) },
                        onSetup = actions.openSetup,
                        onDismiss = vm::closeGallery,
                    )
                }

                // ---- sheets (always last so they sit above everything) ----
                if (ui.sheet != Sheet.None && !lockMode) {
                    Box(
                        Modifier.fillMaxSize()
                            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { vm.closeSheet() }
                    )
                    SheetHost(ui, vm, onPickPhoto)
                }

                ui.notice?.let { StatusPill(it, Modifier.align(Alignment.TopCenter).padding(top = 90.dp)) }
            }
        }
    }
}

@Composable
private fun BoxScope.SheetHost(ui: EditorUiState, vm: EditorViewModel, onPickPhoto: () -> Unit) {
    val profile = ui.profile
    val mod = Modifier
        .align(Alignment.CenterEnd)
        .windowInsetsPadding(WindowInsets.safeDrawing)
        .padding(end = 24.dp, top = 56.dp)

    when (val sheet = ui.sheet) {
        Sheet.None -> Unit
        Sheet.Clock -> ClockPopover(profile.clock, ui.palette, ui.cutout != null, ui.segmenting, vm::updateClock, vm::closeSheet, mod)
        Sheet.AddWidget -> AddWidgetSheet(vm::addWidget, vm::closeSheet, mod)
        Sheet.Media -> MediaSheet(profile.mediaStyle, ui.palette, vm::updateMediaStyle, vm::closeSheet, mod)
        Sheet.Notifications -> StyleSheet("Notifications", profile.notificationStyle, ui.palette, vm::updateNotificationStyle, vm::closeSheet, mod)
        Sheet.Status -> StatusSheet(profile.statusText, profile.inlineText, vm::setStatusText, vm::setInlineText, vm::closeSheet, mod)
        Sheet.Wallpaper -> WallpaperSheet(profile.wallpaper, ui.palette, vm::updateWallpaper, onPickPhoto, vm::resetWallpaperView, vm::closeSheet, mod)
        Sheet.NewProfile -> NewProfileSheet({ kind -> if (vm.addProfile(kind)) onPickPhoto() }, vm::closeSheet, mod)
        is Sheet.Focus -> ui.profiles.firstOrNull { it.id == sheet.profileId }?.let { p ->
            FocusSheet(p.focusEmoji, p.focusLabel, { e, l -> vm.setFocus(p.id, e, l) }, vm::closeSheet, mod)
        }
        is Sheet.Quick -> QuickActionSheet(
            cfg = if (sheet.left) profile.quickLeft else profile.quickRight,
            title = if (sheet.left) "Left Button" else "Right Button",
            palette = ui.palette,
            onChange = { f -> vm.updateQuick(sheet.left, f) },
            onDismiss = vm::closeSheet,
            modifier = mod,
        )
        is Sheet.Widget -> profile.widgets.firstOrNull { it.id == sheet.id }?.let { w ->
            WidgetSheet(
                cfg = w,
                palette = ui.palette,
                onChange = { f -> vm.updateWidget(w.id, f) },
                onResize = { vm.resizeWidget(w.id, it) },
                onDelete = { vm.deleteWidget(w.id) },
                onDismiss = vm::closeSheet,
                modifier = mod,
            )
        }
    }
}

private fun outputSwitcher(launch: (android.content.Intent) -> Unit) {
    // Android's media-output panel; MainActivity/LockActivity fall back to Bluetooth settings if it is missing.
    launch(android.content.Intent("com.android.settings.panel.action.MEDIA_OUTPUT").putExtra("com.android.settings.panel.extra.PACKAGE_NAME", ""))
}

@Composable
private fun EnableMediaCard(onEnable: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .liquidGlass(GlassGeometry.Rounded(28.dp), GlassStyle(intensity = 0.5f))
            .clickable(onClick = onEnable)
            .padding(18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("♪  Show what's playing: tap to allow notification access", color = Color.White, fontSize = 14.sp)
    }
}

@Composable
private fun BoxScope.EditTopBar(onCancel: () -> Unit, onDone: () -> Unit, onWallpaper: () -> Unit, onAdd: () -> Unit) {
    Box(
        Modifier
            .align(Alignment.TopCenter)
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 24.dp, vertical = 12.dp)
    ) {
        GlassPill("Cancel", onCancel, Modifier.align(Alignment.CenterStart))
        Row(Modifier.align(Alignment.Center)) {
            GlassPill("Wallpaper", onWallpaper)
            GlassPill("+ Widget", onAdd, Modifier.padding(start = 12.dp))
        }
        GlassPill("Done", onDone, Modifier.align(Alignment.CenterEnd))
    }
}

/** Dashed outline around the digits so the tappable clock is obvious while editing. */
@Composable
private fun SelectionFrame(placement: ClockPlacement) {
    val density = LocalDensity.current
    val r = placement.drawn
    Canvas(
        Modifier
            .offset { IntOffset(r.left.roundToInt(), r.top.roundToInt()) }
            .size(with(density) { r.width.toDp() }, with(density) { r.height.toDp() })
    ) {
        drawRoundRect(
            color = Color.White.copy(alpha = 0.7f),
            cornerRadius = CornerRadius(18.dp.toPx()),
            style = Stroke(width = 2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 12f))),
        )
    }
}

private val HandleStyle = GlassStyle(intensity = 0.4f)

/** Bottom-right drag handle: down stretches the digits (up to 55% of screen height), up shrinks them. */
@Composable
private fun ResizeHandle(placement: ClockPlacement, onDragY: (Float) -> Unit) {
    val density = LocalDensity.current
    val sizeDp = 44.dp
    val half = with(density) { sizeDp.toPx() / 2f }
    val latest by rememberUpdatedState(onDragY)

    Box(
        Modifier
            .offset { IntOffset((placement.drawn.right - half).roundToInt(), (placement.drawn.bottom - half).roundToInt()) }
            .size(sizeDp)
            .liquidGlass(GlassGeometry.Rounded(22.dp), HandleStyle)
            .pointerInput(Unit) {
                detectDragGestures { change, drag ->
                    change.consume()
                    latest(drag.y)
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(18.dp)) {
            val w = 2.2.dp.toPx()
            val a = Offset(size.width * 0.15f, size.height * 0.85f)
            val b = Offset(size.width * 0.85f, size.height * 0.15f)
            drawLine(Color.White, a, b, w, StrokeCap.Round)
            drawLine(Color.White, b, Offset(b.x, size.height * 0.5f), w, StrokeCap.Round)
            drawLine(Color.White, b, Offset(size.width * 0.5f, b.y), w, StrokeCap.Round)
        }
    }
}
