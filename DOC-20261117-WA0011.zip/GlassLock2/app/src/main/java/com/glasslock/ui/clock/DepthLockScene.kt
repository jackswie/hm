package com.glasslock.ui.clock

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import com.glasslock.data.model.CLOCK_MAX_HEIGHT
import com.glasslock.data.model.CLOCK_MIN_HEIGHT
import com.glasslock.data.model.ClockConfig
import com.glasslock.data.model.WallpaperConfig
import com.glasslock.ui.glass.GlassEnvironment
import com.glasslock.ui.glass.GlassGeometry
import com.glasslock.ui.glass.LocalGlassEnvironment
import com.glasslock.ui.glass.Palette
import com.glasslock.ui.glass.glassSource
import com.glasslock.ui.glass.liquidGlass
import com.glasslock.ui.glass.rememberGlassBackdrop
import com.glasslock.ui.glass.rememberTilt
import java.time.LocalTime
import kotlin.math.roundToInt

/** Where the clock sits, in root pixels. [drawn] is the tight extent of the digits inside [box]. */
class ClockPlacement(val box: Rect, val drawn: Rect, val screen: Size)

/**
 * Area the clock may use. It is symmetric around the screen centre (as on iPadOS) and narrow enough in
 * landscape to stay clear of the ~20% widget rail on the left.
 */
fun heroRect(w: Float, h: Float): Rect =
    if (w >= h) Rect(w * 0.22f, 0f, w * 0.78f, h) else Rect(w * 0.05f, 0f, w * 0.95f, h)

/**
 * The three-layer iPadOS 26 stack:
 *   Layer 1  wallpaper (also the backdrop every glass surface refracts)
 *   Layer 2  hero clock, rendered as Liquid Glass / Solid
 *   Layer 3  subject cutout drawn over the clock, so towers and people overlap the digits
 * [foreground] is drawn above everything (widgets, media, editor chrome) and receives [ClockPlacement].
 */
@Composable
fun DepthLockScene(
    wallpaper: ImageBitmap,
    cutout: ImageBitmap?,
    wallpaperConfig: WallpaperConfig,
    clock: ClockConfig,
    palette: Palette,
    time: LocalTime,
    modifier: Modifier = Modifier,
    onClockClick: (() -> Unit)? = null,
    wallpaperGestures: Modifier = Modifier,
    foreground: @Composable BoxScope.(ClockPlacement) -> Unit = {},
) {
    val backdrop = rememberGlassBackdrop()
    val tilt = rememberTilt()
    val environment = remember(backdrop, tilt, palette.tint) { GlassEnvironment(backdrop, tilt, palette.tint) }
    val density = LocalDensity.current

    CompositionLocalProvider(LocalGlassEnvironment provides environment) {
        BoxWithConstraints(modifier.fillMaxSize().background(Color.Black)) {
            val w = constraints.maxWidth.toFloat()
            val h = constraints.maxHeight.toFloat()
            val hero = heroRect(w, h)

            val boxH = clock.heightFraction.coerceIn(CLOCK_MIN_HEIGHT, CLOCK_MAX_HEIGHT) * h
            val boxW = hero.width
            val boxLeft = hero.left + (hero.width - boxW) / 2f
            val boxTop = clock.topFraction * h

            val text = ClockText.format(time, clock.use24Hour)
            val paths = rememberClockPaths(clock, text, boxW, boxH)
            val placement = ClockPlacement(
                box = Rect(boxLeft, boxTop, boxLeft + boxW, boxTop + boxH),
                drawn = Rect(boxLeft + paths.left, boxTop, boxLeft + paths.right, boxTop + boxH),
                screen = Size(w, h),
            )

            // Layer 1
            Box(Modifier.fillMaxSize().then(wallpaperGestures).glassSource(backdrop)) {
                WallpaperImage(wallpaper, wallpaperConfig, palette)
            }

            // Layer 2
            val clockBase = Modifier
                .offset { IntOffset(boxLeft.roundToInt(), boxTop.roundToInt()) }
                .size(with(density) { boxW.toDp() }, with(density) { boxH.toDp() })
            Box(
                clockBase
                    .liquidGlass(GlassGeometry.Mask(paths.path), clock.style)
                    .then(
                        if (onClockClick != null) {
                            Modifier.clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null,
                                onClick = onClockClick,
                            )
                        } else {
                            Modifier
                        }
                    )
            )

            // Layer 3
            if (clock.depthEffect && cutout != null && !wallpaperConfig.blur) {
                WallpaperImage(cutout, wallpaperConfig, palette, isCutout = true)
            }

            foreground(placement)
        }
    }
}
