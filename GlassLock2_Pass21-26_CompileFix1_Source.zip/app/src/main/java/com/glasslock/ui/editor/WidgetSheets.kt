package com.glasslock.ui.editor

import android.content.Intent
import android.content.pm.PackageManager
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.glasslock.data.model.GlassStyle
import com.glasslock.data.model.AlbumArtworkStyle
import com.glasslock.data.model.QuickAction
import com.glasslock.data.model.QuickActionConfig
import com.glasslock.data.model.WidgetConfig
import com.glasslock.data.model.WidgetSize
import com.glasslock.data.model.WidgetType
import com.glasslock.ui.LocalAppActions
import com.glasslock.ui.glass.Palette
import com.glasslock.ui.theme.Ink
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AppEntry(val label: String, val pkg: String)

@Composable
private fun rememberLaunchableApps(): List<AppEntry> {
    val pm = LocalContext.current.packageManager
    val apps by produceState(emptyList<AppEntry>()) {
        value = withContext(Dispatchers.Default) {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
                .map { AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
                .distinctBy { it.pkg }
                .sortedBy { it.label.lowercase() }
        }
    }
    return apps
}

@Composable
private fun AppPicker(selected: String?, onPick: (String) -> Unit) {
    val apps = rememberLaunchableApps()
    LazyColumn(Modifier.height(220.dp).fillMaxWidth()) {
        items(apps, key = { it.pkg }) { app ->
            Text(
                app.label,
                color = if (app.pkg == selected) Color.White else Ink.secondary,
                fontWeight = if (app.pkg == selected) FontWeight.Bold else FontWeight.Normal,
                fontSize = 15.sp,
                modifier = Modifier.fillMaxWidth().clickable { onPick(app.pkg) }.padding(vertical = 9.dp),
            )
        }
    }
}

@Composable
fun AddWidgetSheet(onAdd: (WidgetType) -> Unit, onDismiss: () -> Unit, modifier: Modifier = Modifier) {
    SheetFrame("Add Widget", onDismiss, modifier) {
        SectionTitle("Choose a widget")
        ChipFlow<WidgetType?>(WidgetType.entries, null, { t -> t?.let(onAdd) }, { it?.label ?: "" })
    }
}

@Composable
fun WidgetSheet(
    cfg: WidgetConfig,
    palette: Palette,
    onChange: ((WidgetConfig) -> WidgetConfig) -> Unit,
    onResize: (WidgetSize) -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val actions = LocalAppActions.current
    SheetFrame(cfg.type.label, onDismiss, modifier) {
        if (cfg.type.sizes.size > 1) {
            SectionTitle("Size")
            Segmented(cfg.type.sizes.map { it to it.label }, cfg.size, onResize)
        }
        when (cfg.type) {
            WidgetType.BATTERY -> {
                GlassTextField("Device / owner name", cfg.title) { v -> onChange { it.copy(title = v) } }
                GlassTextField("Emoji", cfg.emoji) { v -> onChange { it.copy(emoji = v) } }
            }
            WidgetType.QUOTE -> {
                GlassTextField("Title", cfg.title) { v -> onChange { it.copy(title = v) } }
                GlassTextField("Text", cfg.body, singleLine = false) { v -> onChange { it.copy(body = v) } }
                SectionTitle("Typography")
                Segmented(listOf(false to "Sans", true to "Serif"), cfg.serif, onSelect = { v -> onChange { it.copy(serif = v) } })
            }
            WidgetType.ANALOG_CLOCK -> {
                SectionTitle("Dial")
                Segmented(listOf(0 to "Numbers", 1 to "Ticks", 2 to "Minimal"), cfg.dialStyle, onSelect = { v -> onChange { it.copy(dialStyle = v) } })
            }
            WidgetType.PHOTO -> {
                SectionTitle("Photos (${cfg.photos.size})")
                Row {
                    GlassPill("Choose photos", { actions.pickPhotos(cfg.id) })
                    if (cfg.photos.isNotEmpty()) GlassPill("Clear", { onChange { it.copy(photos = emptyList()) } }, Modifier.padding(start = 10.dp))
                }
            }
            WidgetType.APP_SHORTCUT -> {
                SectionTitle("App")
                AppPicker(cfg.packageName) { p -> onChange { it.copy(packageName = p) } }
            }
            else -> Unit
        }
        StyleControls(cfg.style, palette) { f -> onChange { it.copy(style = f(it.style)) } }
        SectionTitle("Widget")
        GlassPill("Remove widget", onDelete)
    }
}

@Composable
fun QuickActionSheet(
    cfg: QuickActionConfig,
    title: String,
    palette: Palette,
    onChange: ((QuickActionConfig) -> QuickActionConfig) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    SheetFrame(title, onDismiss, modifier) {
        SectionTitle("Action")
        ChipFlow(QuickAction.entries, cfg.action, { a -> onChange { it.copy(action = a) } }, { it.label })
        if (cfg.action == QuickAction.APP) {
            SectionTitle("App")
            AppPicker(cfg.packageName) { p -> onChange { it.copy(packageName = p) } }
        }
        StyleControls(cfg.style, palette) { f -> onChange { it.copy(style = f(it.style)) } }
    }
}

@Composable
fun MediaSheet(
    style: GlassStyle,
    palette: Palette,
    blendIntoAlbum: Boolean,
    artworkStyle: AlbumArtworkStyle,
    onBlendChange: (Boolean) -> Unit,
    onArtworkStyle: (AlbumArtworkStyle) -> Unit,
    onChange: ((GlassStyle) -> GlassStyle) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    SheetFrame("Now Playing", onDismiss, modifier) {
        SectionTitle("Album mode")
        ToggleRow("Blend controls into artwork", blendIntoAlbum, note = "Removes the player panel so the controls float over the blurred album background.") { onBlendChange(it) }
        SectionTitle("Artwork presentation")
        Segmented(
            options = listOf(AlbumArtworkStyle.COVER to "Album cover", AlbumArtworkStyle.VINYL to "Vinyl record"),
            selected = artworkStyle, onSelect = onArtworkStyle,
        )
        Text("Vinyl rotates gently while music is playing and settles when paused.", color = Ink.secondary, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        SectionTitle("Player material")
        StyleControls(style, palette, onChange)
    }
}

@Composable
fun StatusSheet(
    statusText: String,
    inlineText: String,
    onStatus: (String) -> Unit,
    onInline: (String) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    SheetFrame("Status & Header", onDismiss, modifier) {
        GlassTextField("Focus / status pill (emoji + text)", statusText, onChange = onStatus)
        GlassTextField("Inline text next to the date", inlineText, onChange = onInline)
        Text("Leave empty to hide.", color = Ink.secondary, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
    }
}
