# GlassLock 2: Passes 1-3

Open the `GlassLock2` folder in Android Studio, let Gradle sync, run on a tablet or emulator (API 31+; refraction needs API 33+).
Long-press the screen to customise. Tap the clock for the popover, drag the corner handle to resize, "Photo" picks a wallpaper.

## Layout
    data/model   Models.kt (GlassStyle, ClockConfig, LockProfile...), ProfileStore.kt (DataStore + JSON)
    ui/glass     Agsl.kt (shaders) GlassBackdrop.kt (wallpaper capture) LiquidGlass.kt (the modifier)
                 TiltSensor.kt  WallpaperPalette.kt
    ui/clock     ClockFonts / ClockGeometry (digit outlines) / DepthLockScene (3 layers) / SubjectSegmenter (ML Kit) / Wallpaper
    ui/editor    EditorScreen, ClockPopover, GlassControls, ColorPicker, EditorViewModel
    ui/widgets   DateHeader, StatusPill, HomeIndicator (Pass 2 adds the widget grid + media player here)

## How the glass works
1. The wallpaper is recorded into one GraphicsLayer (`glassSource`).
2. Each glass surface redraws a shifted copy of it into its own padded layer.
3. RenderEffect chain on that layer: AGSL edge refraction + chromatic dispersion, then blur.
4. Compose draws saturation, frost, tint, a soft sheen and a 1dp inner rim (white 35% -> 5%) whose light direction follows accelerometer tilt.
   Tilt never re-runs the shaders; the blurred copy is cached until size, position or style changes.
Intensity 0% = nearly clear, strong refraction, bright rim. 100% = ~38dp blur, 26% frost, refraction hidden.
Clock digits use the MASK shader (edge normals estimated from a coverage mask); cards and pills use the exact rounded-rect SDF shader.
On API 31-32 the refraction step is skipped and blur/frost/tint/rim still render.

## Known limits
- SF Pro / New York are Apple-licensed; see app/src/main/assets/fonts/README.txt for OFL substitutes.
- ML Kit Subject Segmentation is built for people and objects. A skyline may be cut out only partly; the pipeline accepts any
  alpha cutout, so a different model can be swapped into SubjectSegmenter.cutout().
- Tilt uses the accelerometer only (gives the same rim motion as gyro with less code).

## Pass 2 additions
- ui/widgets: WidgetGrid (2-column rail, snap-to-grid drag, collision checks), BuiltInWidgets (analog clock with sweeping seconds,
  battery, month calendar, weather + sun arc, flip digital clock, quote, photo carousel, app shortcut), QuickActions (two corner buttons), StatusBar.
  Portrait reflows the same widgets into one horizontal row under the clock.
- ui/media + service: MediaRepository mirrors the active MediaSession; MediaListenerService authorises it. NowPlayingCard has art,
  title/artist, animated bars, seek slider, prev/play/next, output switcher and swipe-to-dismiss (audio keeps playing).
- Editing: long-press -> tap any element to configure it. "+ Widget" adds, the sheet resizes/removes. Weather uses Open-Meteo + coarse location.
- First run: tap the "Show what's playing" card to enable notification access, and tap the weather widget to allow location.
- Notifications on the lock screen, the real lock-screen window/service and the wallpaper gallery are Pass 3.

## Pass 3 additions
- Real lock window: LockService (foreground, SCREEN_ON/OFF) shows LockActivity above the system keyguard. Swipe up from the bottom edge
  (with fade/shrink and spring-back) calls KeyguardManager.requestDismissKeyguard, so Android still checks PIN/biometrics.
- Notifications: MediaListenerService mirrors them into Liquid Glass cards, grouped per app with peeking stacks. Tap expands a stack or opens
  a card (after unlock); swipe sideways dismisses and clears it from the system shade. Secret notifications are hidden, private ones show only the app name.
- Gallery: long-press (in the app) opens a carousel of lock screens. "+" adds Photo / Weather / Astronomy / Emoji / Color Gradient / Extended Photo,
  swipe a card up to delete, "Focus" links an icon + label to that lock screen, "Customize" opens the editor.
- Wallpaper editing: two-finger pinch/pan, swipe left/right for Natural / B&W / Duotone / Color Wash, plus Dim, Blur and Extend toggles.
- Setup screen: overlay permission, notification access, service notice, location, battery exemption, and the on/off switch for the lock replacement.
- Album art: tap the cover on the Now Playing card to see it enlarged; tap anywhere to close.

## Setup on a device
1. Install and open the app; follow the setup screen (the first two steps are required).
2. Turn on "Use GlassLock as my lock screen", then lock the device.
Uninstall or turn the switch off to get the stock lock screen back. If something goes wrong, boot to safe mode or use adb: `adb shell am force-stop com.glasslock`.

## Honest limits
- Android has no supported lock-screen replacement API. This overlay sits above the real keyguard; Android 14+ background-start rules, OEM battery managers
  and vendor skins can stop it appearing. Test on your tablet before relying on it.
- Weather / Astronomy wallpapers are generated pictures, not live data. "Extended Photo" is a blurred fill, not generative outpainting.
- Focus only changes the label in the pill; it does not toggle Do Not Disturb.
- Tilt uses the accelerometer. Nothing here was compiled or run in the build sandbox.


## Pass 4: clock proportions and depth-stack repair
- Added independent clock-canvas width and height controls in the Clock sheet. The width is a percentage of the available hero area; the height remains a percentage of screen height.
- Clock glyphs now scale uniformly to fit the selected bounds instead of being squeezed horizontally when the width is reduced. This keeps the numeral proportions intact at compact sizes.
- The depth compositor is retained as a true three-layer scene (wallpaper, clock, foreground subject). In the editor, the Depth Effect switch remains live and the subject cutout is drawn above the clock when segmentation is available.

## Pass 5 update (2026-11-18)

- Clock glyphs now use independent horizontal and vertical transforms, matching free-transform/photo-stretch behaviour. The width control reaches 8% of the available clock area.
- The compact album-player clock explicitly retains its original aspect ratio, so opening the album-art player does not squash the compact clock.
- Landscape widget-rail width is now derived from the tablet screen width, not the clock's left edge. Narrowing the clock can no longer enlarge the widget tiles.
- Replaced the simulated liquid/refraction material with a restrained translucent surface: subtle tint, tonal gradient and fine highlight. The old AGSL refraction/chromatic edge effect is no longer used by glass surfaces.
- Existing animation code and the wallpaper/depth subject compositor are retained.


## Pass 6 changes

- Restored the captured-wallpaper AGSL refraction path for Liquid Glass on Android 13+, with a restrained blur, edge lensing, subtle chromatic separation, tint and tilt-aware specular rim. Android 12 and shader failures use a graceful translucent fallback.
- Decoupled the now-playing card width from clock bounds; media sizing now follows the screen dimensions.
- Album-player mode reserves a lower band for the compact clock, removes the date header from the top, and keeps the expanded player clear of that lower clock area.
- Album art selection now prefers the largest artwork bitmap supplied by the active media session, and Compose renders it with high filter quality.
- Kept the outlined-font artifact as a low-priority follow-up; no font assets were altered in this pass.

This source archive has not been compiled or device-tested in this environment. Build it with the Android Gradle Plugin/SDK in Android Studio or GitHub Actions before installing.

## Pass 7: album mode hierarchy and transitions
- Album mode now suppresses the wallpaper clock layer and places a dedicated clock in the right-side player column.
- The album-mode order is clock, expanded playback card/transport controls, then up to three live notification stacks.
- Notifications use the existing notification interaction model (open after unlock, swipe to dismiss) in album mode.
- Album-mode player and notification surfaces explicitly request the Liquid/Clear material rather than inheriting an opaque Solid selection.
- Album artwork is rendered with high filter quality and `ContentScale.Fit` to preserve the complete cover without stretching or cropping it.
- Album mode keeps the artwork on the left and the independent clock/player/notification column on the right in landscape; portrait reflows vertically.
- Added delayed slide/fade entrance for notifications; existing album overlay spring/fade transition and cover-scale response remain.

Build status: source edits only. This environment does not have a Gradle executable, Gradle wrapper JAR, Android SDK, or connected Lenovo device, so this pass has not been compiled or device-tested. Run the repository's GitHub Actions Android build before installing.

## Pass 8 — seamless track changes

- Album mode now retains the last valid artwork while a media session briefly publishes metadata without a bitmap.
- Album backdrop generation runs on `Dispatchers.Default`; the previous backdrop stays visible until the next one is ready.
- Album artwork crossfades over 620 ms instead of replacing the image in a single frame.
- The blurred album-colour wallpaper crossfades over 680 ms, preventing the original lock-screen wallpaper from flashing between tracks.
- Expanded player title and artist labels crossfade with track metadata.

Build and device-test this source with Android Studio / the Android Gradle Plugin. This environment does not include the Gradle wrapper launcher or Android SDK, so no APK compilation is claimed.

## Pass 9 — album motion refinement

- Replaced the album-cover opacity-only crossfade with a spatial handoff: the incoming cover eases in from the right with a restrained scale settle while the outgoing cover moves slightly left and scales down.
- Clock, player controls, and notifications now use spring-based slide + scale + fade entrance choreography rather than fade/slide alone.
- The liquid-glass renderer is intentionally unchanged in this pass. On-device reports still show dark/black panels, so it is not marked fixed; backdrop capture and shader output need a dedicated diagnostic pass on the target Lenovo before swapping rendering libraries or claiming optical refraction works.
- Source-only update. Build and test with GitHub Actions before installing.


## Pass 11 — Optical Liquid Glass refinement

This pass revises the Android 13+ AGSL lens treatment: multi-sample edge displacement, a subtle tangent ripple, restrained chromatic dispersion, a Fresnel-like bevel glint, clearer low-frost material tuning, and a stronger tilt-responsive rim. The default material is intentionally clearer and less gray than the previous implementation. The captured wallpaper remains the source image; the shader is an optical treatment over that image, not a generated gray fill.

The current source also already contains independently controlled clock width/height and a responsive widget rail/row. Always-on display, richer spring-based scene transitions, and expanded adaptive widget rules remain separate follow-up work rather than being represented as completed in this pass.


## Pass 12 — Album clock + optical safety pass

- Added a separately persisted `albumClock` configuration to each lock-screen profile. Existing profile JSON remains compatible because the new field has a default.
- Album-mode clock typography now uses the selected clock face and weight, independently from the normal lock-screen clock. Tap the album clock or its **EDIT ALBUM CLOCK** label to open its dedicated editor sheet.
- Increased the paused album-art scale-down from 1.5% to 10%, with the existing spring animation returning it to full size during playback.
- Reduced the RenderEffect layer's composite alpha to 16% over a correctly aligned wallpaper underlay. This is a defensive mitigation for drivers that silently return opaque black RenderEffect output; it preserves the captured wallpaper as the dominant image while retaining a subtle optical contribution. It is not yet a verified full AGSL/refraction fix.
- Bumped Android versionCode/versionName for the next installable pass.

Build status: source-only update. This environment did not have Gradle or an Android SDK configured, so an APK build and device-side validation were not performed.


## Pass 14 — Album Studio, blended player and motion polish

- Added an **Album Preview** switch to the editor toolbar. It opens the full album composition while editing, including a wallpaper-backed cover preview when no media artwork is available. Switch back with **Lock Preview**.
- Album mode is now directly editable: tap the album clock to edit its independent typography; tap the player to edit its material/blend treatment; tap the notification stack to edit notification appearance. In preview mode, empty notification lists use a sample card so the editing affordance remains discoverable.
- Added **Blend controls into artwork**. When enabled, the expanded player surface disappears and the title, timeline and transport controls float directly over the blurred album-colour backdrop. Turn it off to restore the configured player panel.
- Album mode now honours the saved media and notification material styles rather than forcibly overriding them with a liquid style.
- Added four reliable low-opacity solid presets: Crystal, Soft, Frosted and Wallpaper Tint. These are the recommended route on devices where live shader refraction is unreliable; the experimental Translucent mode remains available.
- Added subtle accelerometer-driven wallpaper parallax. The wallpaper and segmented foreground share the same transform to prevent subject-cutout drift. The existing tilt-responsive rim lighting, depth cutout, wallpaper palette sampling, adaptive widget layouts and spring-based album transitions remain in place.
- Added a separate persisted album-player blend preference with a default, so existing profile JSON continues to load.

Build status: source-only. This environment does not have Gradle or the Android SDK configured, so the GitHub Actions build is still required. A true system Always-On Display is not claimed here: Android's display power/AOD lifecycle is controlled by the OS and OEM, and needs a dedicated device-side integration rather than a fake in-app dim overlay.


## Pass 16 — Music & Notification Studio

- Added an optional vinyl-record album-art presentation for the full-screen album player. The disc rotates while playback is active and settles while paused; the original square cover presentation remains the default.
- Added a playback-state visualizer to the expanded player. These animated bars reflect play/pause state and are not an audio FFT capture. No microphone permission is requested.
- Added a notification visibility limit (2, 3, 4, or 6 cards) shared by the regular lock screen and album layout. Existing app grouping and swipe-to-dismiss behavior remain intact.
- Expanded the Now Playing editor with album artwork presentation and retained the player-background blend and independent player material controls.
- Expanded the Notifications editor with visibility and independent material controls.
- New profile fields have serialization defaults, so older Pass 1–15 profiles continue to load.

Build metadata: versionCode 16, versionName 0.6-pass16.

Build verification: source archive integrity is checked before delivery; Android compilation/device behavior still require the project's GitHub Actions build and a device test.

## Pass 17 — Scene Studio & Ambient Atmosphere (0.7-pass17)

- Added a Scene Studio entry to the editor toolbar with four one-tap scene presets: Balanced, Focus, Sleep and Cinematic. Presets adjust dimming, clock scale/depth, notification count and media/notification materials while preserving the selected wallpaper, widgets and custom labels.
- Added optional atmospheric motion to wallpaper settings, with an intensity slider. Astronomy scenes use subtle twinkling stars; Weather scenes use gentle drifting weather-like streaks; other wallpaper types use restrained particles.
- The atmosphere is a visual layer only. It does not claim to infer live weather conditions.
- Sleep is an in-app visual preset, not Android Do Not Disturb or a hardware Always-On Display. A true system AOD still requires device/OEM integration.
- New wallpaper fields have defaults for existing saved profiles.
- Version code 17, version name 0.7-pass17.

Build status: source archive checked; Android compilation/device testing still needs to be run through the project's Gradle/Android build environment.


## Pass 18 — Lyrics Mode

- Adds an optional LYRICS / ARTWORK switch to the album-player artwork area.
- Reads lyrics exposed by the active Android MediaSession through `MediaMetadata.METADATA_KEY_LYRICS`.
- Parses timestamped LRC lines and highlights the line matching the current playback position.
- Tapping a timestamped lyric seeks the active media session to that line.
- Plain-text lyrics are displayed as a readable, non-synchronized fallback.
- Lyrics remain optional: when the music app does not publish lyrics in its media metadata, the toggle is not shown. The app does not scrape lyrics or contact an unconfigured third-party service.

Build metadata: versionCode 18, versionName 0.8-pass18.

Build with the existing GitHub Actions workflow. This source archive has not been compiled or device-tested in this environment.


## Pass 19 — Lyrics Visual Polish

- Added smooth vertical crossfades and spring-like line handoffs as timestamped lyrics advance.
- The active lyric receives a soft translucent highlight and subtle glow.
- The highlight accent is sampled from the current album artwork, with a calm fallback when artwork is unavailable.
- Previous and upcoming lines remain visible with graduated opacity; timestamped lines remain tappable for seeking.
- No new permissions, network calls, or third-party dependencies were added.

Build metadata: versionCode 19, versionName 0.9-pass19.

## Pass 20 — Cinematic Experience (1.0-pass20)

- Added a restrained radial album-colour atmosphere behind the album artwork and lyrics in both landscape and portrait layouts. It uses the existing sampled artwork accent and a lightweight Compose gradient rather than a continuously blurred bitmap.
- Added progressive word emphasis to timestamped LRC lyrics. Since standard LRC metadata normally timestamps whole lines rather than individual words, the word highlight interpolates between adjacent line timestamps; it is an approximate karaoke presentation, not syllable-accurate vocal tracking. Plain-text lyrics remain readable without simulated synchronization.
- Preserved line-level lyric seeking, vinyl artwork mode, player controls, and existing notification swipe-to-dismiss/group behavior.
- Added a custom GlassLock2 adaptive launcher icon and Android 12+ splash screen using native vector resources. Updated the app label to GlassLock2.
- No new permissions, network services, or third-party dependencies were added.

Build metadata: versionCode 20, versionName 1.0-pass20.

Build status: source-only. ZIP integrity and XML well-formedness are checked for this delivery; Android compilation and Lenovo device behavior still require the GitHub Actions build and device test.


## Pass 21–26 — Unified Studio Update (1.6-pass21-26)

This combined source update folds the planned improvement areas into one install/test cycle rather than six separate builds.

- **Pass 21 — Intelligence & Personalization:** adds optional local-time scene scheduling (Balanced in the morning, Focus during daytime, Cinematic in the evening and Sleep overnight). It is a visual schedule only and does not alter system DND. It also retains the adaptive widget rail/portrait row, per-profile focus identity, grouped notification stacks, and wallpaper-derived palette/material behavior.
- **Pass 22 — Music Studio Deluxe:** retains the vinyl presentation, artwork-colour atmosphere, blended player, playback controls, lyric display, line seeking, and approximate LRC word progression. Word progression is interpolated between line timestamps; it is not vocal recognition.
- **Pass 23 — Liquid Glass Evolution:** retains independent clock/player/notification materials, solid/translucent choices, tint/opacity/intensity and rim-highlight controls. On devices where shader refraction is unreliable, the dependable translucent/solid material remains the recommended option.
- **Pass 24 — Ambient & Sleep:** retains the Sleep scene and optional wallpaper atmosphere. Added per-wallpaper **Reduce motion** and **Wallpaper parallax** controls; reduced motion disables atmospheric animation and sensor-driven movement. Sleep remains an in-app visual scene, not Android Do Not Disturb or hardware AOD.
- **Pass 25 — Animation Polish:** retains the existing spring-based player/widget interactions and scene transitions; reduced-motion mode also removes the wallpaper crossfade.
- **Pass 26 — Live Scene Studio & Theme Gallery:** retains the live lock/album preview and Scene Studio presets. Added **Export** and **Import** in edit mode. A `.glasslock` bundle contains the profile settings and, when present, the selected photo wallpaper, so a theme can be moved to another device without losing its background. Imported themes are added as a new profile rather than overwriting an existing one.

Compatibility: all new profile settings have serialization defaults, so older saved profiles continue to load. No new Android permissions or third-party dependencies were added.

Build metadata: versionCode 26, versionName `1.6-pass21-26`.

Build status: source-only. The Android SDK/Gradle build environment is not available here, so compilation and Lenovo tablet behavior still require the GitHub Actions build and device validation.


## Pass21–26 compile-fix update (1.6.1)

This maintenance revision addresses two Kotlin compilation errors reported by the CI build:
- Removed the invalid direct import of Compose `Modifier.weight`; the call remains inside its `Row` scope.
- Replaced the unavailable Android `MediaMetadata.METADATA_KEY_LYRICS` symbol with the conventional custom metadata key string `android.media.metadata.LYRICS`.

Version code is 27 so this build can be installed as an update over version code 26. The source archive has been checked for ZIP integrity; an Android build still needs to be run in the user's CI environment.
