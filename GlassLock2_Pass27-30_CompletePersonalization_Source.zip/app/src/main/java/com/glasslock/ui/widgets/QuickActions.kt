package com.glasslock.ui.widgets

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.glasslock.data.model.QuickAction
import com.glasslock.data.model.QuickActionConfig
import com.glasslock.ui.LocalAppActions
import com.glasslock.ui.glass.GlassGeometry
import com.glasslock.ui.glass.liquidGlass

private object Torch {
    var on by mutableStateOf(false)
}

fun runQuickAction(context: Context, cfg: QuickActionConfig, launch: (Intent) -> Unit) {
    when (cfg.action) {
        QuickAction.FLASHLIGHT -> runCatching {
            val cm = context.getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            cm.setTorchMode(id, !Torch.on)
            Torch.on = !Torch.on
        }
        QuickAction.CAMERA -> launch(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
        QuickAction.CALCULATOR -> launch(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALCULATOR))
        QuickAction.TIMER -> launch(Intent(AlarmClock.ACTION_SHOW_TIMERS))
        QuickAction.MUSIC -> launch(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC))
        QuickAction.ALARM -> launch(Intent(AlarmClock.ACTION_SHOW_ALARMS))
        QuickAction.SETTINGS -> launch(Intent(Settings.ACTION_SETTINGS))
        QuickAction.DND -> {
            val nm = context.getSystemService(NotificationManager::class.java)
            if (nm.isNotificationPolicyAccessGranted) {
                val on = nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_NONE
                nm.setInterruptionFilter(
                    if (on) NotificationManager.INTERRUPTION_FILTER_ALL else NotificationManager.INTERRUPTION_FILTER_NONE
                )
            } else {
                launch(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            }
        }
        QuickAction.APP -> cfg.packageName
            ?.let { context.packageManager.getLaunchIntentForPackage(it) }?.let(launch)
    }
}

/** Circular Liquid Glass button for the bottom-left / bottom-right corner. */
@Composable
fun QuickActionButton(
    cfg: QuickActionConfig,
    editing: Boolean,
    onEditTap: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val actions = LocalAppActions.current
    Box(
        modifier
            .size(60.dp)
            .liquidGlass(GlassGeometry.Rounded(30.dp), cfg.style)
            .clip(CircleShape)
            .pointerInput(editing, cfg) {
                detectTapGestures {
                    if (editing) onEditTap() else runQuickAction(context, cfg, actions.launch)
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        if (cfg.action == QuickAction.APP) {
            ShortcutWidget(
                com.glasslock.data.model.WidgetConfig(
                    type = com.glasslock.data.model.WidgetType.APP_SHORTCUT,
                    size = com.glasslock.data.model.WidgetSize.ONE,
                    packageName = cfg.packageName,
                ),
                editing = true,
            )
        } else {
            Canvas(Modifier.size(26.dp)) { drawGlyph(cfg.action, Torch.on) }
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawGlyph(action: QuickAction, torchOn: Boolean) {
    val w = Stroke(width = 2.4.dp.toPx(), cap = StrokeCap.Round)
    val s = size.minDimension
    val white = Color.White
    when (action) {
        QuickAction.FLASHLIGHT -> {
            drawRoundRect(white, Offset(s * 0.3f, s * 0.05f), Size(s * 0.4f, s * 0.25f), CornerRadius(s * 0.06f), style = w)
            drawRoundRect(
                white, Offset(s * 0.36f, s * 0.3f), Size(s * 0.28f, s * 0.65f), CornerRadius(s * 0.08f),
                style = if (torchOn) androidx.compose.ui.graphics.drawscope.Fill else w,
            )
        }
        QuickAction.CAMERA -> {
            drawRoundRect(white, Offset(s * 0.02f, s * 0.22f), Size(s * 0.96f, s * 0.64f), CornerRadius(s * 0.14f), style = w)
            drawCircle(white, s * 0.2f, Offset(s * 0.5f, s * 0.54f), style = w)
        }
        QuickAction.CALCULATOR -> {
            drawRoundRect(white, Offset(s * 0.12f, s * 0.02f), Size(s * 0.76f, s * 0.96f), CornerRadius(s * 0.12f), style = w)
            for (r in 0..1) for (c in 0..1) drawCircle(white, s * 0.05f, Offset(s * (0.35f + c * 0.3f), s * (0.5f + r * 0.22f)))
            drawLine(white, Offset(s * 0.28f, s * 0.24f), Offset(s * 0.72f, s * 0.24f), w.width, StrokeCap.Round)
        }
        QuickAction.TIMER -> {
            drawCircle(white, s * 0.42f, Offset(s * 0.5f, s * 0.56f), style = w)
            drawLine(white, Offset(s * 0.5f, s * 0.56f), Offset(s * 0.5f, s * 0.34f), w.width, StrokeCap.Round)
            drawLine(white, Offset(s * 0.4f, s * 0.04f), Offset(s * 0.6f, s * 0.04f), w.width, StrokeCap.Round)
        }
        QuickAction.DND -> {
            val moon = Path().apply { addOval(Rect(center = center, radius = s * 0.42f)) }
            val bite = Path().apply { addOval(Rect(center = Offset(s * 0.68f, s * 0.36f), radius = s * 0.36f)) }
            drawPath(Path.combine(PathOperation.Difference, moon, bite), white)
        }
        QuickAction.MUSIC -> {
            drawCircle(white, s * 0.34f, Offset(s * 0.43f, s * 0.35f), style = w)
            drawLine(white, Offset(s * 0.67f, s * 0.12f), Offset(s * 0.67f, s * 0.72f), w.width, StrokeCap.Round)
        }
        QuickAction.ALARM -> {
            drawCircle(white, s * 0.38f, Offset(s * 0.5f, s * 0.55f), style = w)
            drawLine(white, Offset(s * 0.5f, s * 0.55f), Offset(s * 0.5f, s * 0.34f), w.width, StrokeCap.Round)
            drawLine(white, Offset(s * 0.24f, s * 0.08f), Offset(s * 0.10f, s * 0.22f), w.width, StrokeCap.Round)
            drawLine(white, Offset(s * 0.76f, s * 0.08f), Offset(s * 0.90f, s * 0.22f), w.width, StrokeCap.Round)
        }
        QuickAction.SETTINGS -> {
            drawCircle(white, s * 0.28f, center, style = w)
            drawCircle(white, s * 0.08f, center)
            for (i in 0 until 8) {
                val a = Math.toRadians(i * 45.0)
                val x1 = center.x + kotlin.math.cos(a).toFloat() * s * 0.34f
                val y1 = center.y + kotlin.math.sin(a).toFloat() * s * 0.34f
                val x2 = center.x + kotlin.math.cos(a).toFloat() * s * 0.46f
                val y2 = center.y + kotlin.math.sin(a).toFloat() * s * 0.46f
                drawLine(white, Offset(x1, y1), Offset(x2, y2), w.width, StrokeCap.Round)
            }
        }
        QuickAction.APP -> Unit
    }
}
