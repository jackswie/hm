package com.glasslock.ui.media

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.SystemClock
import androidx.core.app.NotificationManagerCompat
import com.glasslock.service.MediaListenerService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class NowPlaying(
    val hasSession: Boolean = false,
    val title: String = "",
    val artist: String = "",
    val art: Bitmap? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
    val speed: Float = 1f,
    /** SystemClock.elapsedRealtime() when [positionMs] was reported. */
    val stamp: Long = 0,
    val packageName: String? = null,
    /** Optional lyrics exposed by the active media session (plain text or timestamped LRC). */
    val lyrics: String = "",
) {
    val key: String get() = "$packageName|$title|$artist"

    fun positionNow(): Long {
        val p = if (isPlaying) positionMs + ((SystemClock.elapsedRealtime() - stamp) * speed).toLong() else positionMs
        return if (durationMs > 0) p.coerceIn(0, durationMs) else p.coerceAtLeast(0)
    }

    companion object {
        /** Shown in edit mode when nothing is playing, so the card can still be styled. */
        val Sample = NowPlaying(
            hasSession = true, title = "Nights Like This", artist = "The Kid LAROI",
            isPlaying = false, positionMs = 45_000, durationMs = 87_000,
        )
    }
}

/**
 * Mirrors the system's active media session (Spotify, YouTube Music, ...).
 * Needs notification-listener access, because that is what authorises MediaSessionManager.getActiveSessions.
 */
object MediaRepository {
    private val _state = MutableStateFlow(NowPlaying())
    val state: StateFlow<NowPlaying> = _state.asStateFlow()

    private val _hasAccess = MutableStateFlow(false)
    val hasAccess: StateFlow<Boolean> = _hasAccess.asStateFlow()

    private var app: Context? = null
    private var controller: MediaController? = null
    private var listening = false
    private val lyricScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var lyricLookupJob: Job? = null
    private var lyricLookupKey: String? = null
    private var lyricLookupAttemptAt = 0L
    private val lyricCache = linkedMapOf<String, String>()

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { select(it.orEmpty()) }

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = publish()
        override fun onPlaybackStateChanged(state: PlaybackState?) = publish()
        override fun onSessionDestroyed() = refresh()
    }

    /** Call on the main thread (MediaController callbacks are delivered on the calling thread's looper). */
    fun start(context: Context) {
        app = context.applicationContext
        refresh()
    }

    fun refresh() {
        val ctx = app ?: return
        val granted = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
        _hasAccess.value = granted
        if (!granted) {
            detach()
            _state.value = NowPlaying()
            return
        }
        try {
            val manager = ctx.getSystemService(MediaSessionManager::class.java)
            val component = ComponentName(ctx, MediaListenerService::class.java)
            if (!listening) {
                manager.addOnActiveSessionsChangedListener(sessionsListener, component)
                listening = true
            }
            select(manager.getActiveSessions(component))
        } catch (_: SecurityException) {
            _hasAccess.value = false
            _state.value = NowPlaying()
        }
    }

    private fun detach() {
        controller?.unregisterCallback(callback)
        controller = null
        val ctx = app
        if (listening && ctx != null) {
            ctx.getSystemService(MediaSessionManager::class.java).removeOnActiveSessionsChangedListener(sessionsListener)
        }
        listening = false
    }

    private fun select(list: List<MediaController>) {
        val best = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list.firstOrNull()
        if (best?.sessionToken != controller?.sessionToken) {
            controller?.unregisterCallback(callback)
            controller = best
            best?.registerCallback(callback)
        }
        publish()
    }

    private fun publish() {
        val c = controller
        if (c == null) {
            lyricLookupJob?.cancel()
            lyricLookupKey = null
            _state.value = NowPlaying()
            return
        }
        val meta = c.metadata
        val ps = c.playbackState
        // Prefer the largest artwork variant supplied by the media session. Some apps expose
        // a tiny notification icon alongside a full-resolution album-art bitmap.
        val artwork = listOf(
            MediaMetadata.METADATA_KEY_ALBUM_ART,
            MediaMetadata.METADATA_KEY_ART,
            MediaMetadata.METADATA_KEY_DISPLAY_ICON,
        ).mapNotNull { key -> runCatching { meta?.getBitmap(key) }.getOrNull() }
            .maxByOrNull { it.width.toLong() * it.height.toLong() }
        val title = meta?.getString(MediaMetadata.METADATA_KEY_TITLE).orEmpty()
        val artist = (meta?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: meta?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)).orEmpty()
        val durationMs = meta?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        val mediaLyrics = meta?.getString("android.media.metadata.LYRICS").orEmpty()
        val nowPlaying = NowPlaying(
            hasSession = true,
            title = title,
            artist = artist,
            art = artwork,
            isPlaying = ps?.state == PlaybackState.STATE_PLAYING,
            positionMs = ps?.position?.takeIf { it >= 0 } ?: 0L,
            durationMs = durationMs,
            speed = ps?.playbackSpeed?.takeIf { it > 0f } ?: 1f,
            stamp = ps?.lastPositionUpdateTime ?: SystemClock.elapsedRealtime(),
            packageName = c.packageName,
            lyrics = mediaLyrics,
        )
        _state.value = nowPlaying
        if (mediaLyrics.isNotBlank()) {
            lyricLookupJob?.cancel()
            lyricLookupKey = nowPlaying.key
        } else {
            requestSpotifyLyrics(
                key = nowPlaying.key,
                packageName = c.packageName,
                title = title,
                artist = artist,
                album = meta?.getString(MediaMetadata.METADATA_KEY_ALBUM).orEmpty(),
                durationMs = durationMs,
            )
        }
    }


    /** Fetch timed lyrics for Spotify when its MediaSession does not expose lyric text. */
    private fun requestSpotifyLyrics(
        key: String,
        packageName: String,
        title: String,
        artist: String,
        album: String,
        durationMs: Long,
    ) {
        if (packageName != "com.spotify.music" || title.isBlank() || artist.isBlank() || durationMs <= 0L) {
            lyricLookupJob?.cancel()
            lyricLookupKey = null
            return
        }
        lyricCache[key]?.let { cached ->
            if (_state.value.key == key) _state.value = _state.value.copy(lyrics = cached)
            return
        }
        val now = SystemClock.elapsedRealtime()
        if (lyricLookupKey == key && now - lyricLookupAttemptAt < 5 * 60 * 1000L) return
        lyricLookupJob?.cancel()
        lyricLookupKey = key
        lyricLookupAttemptAt = now
        lyricLookupJob = lyricScope.launch {
            val lyrics = withContext(Dispatchers.IO) {
                fetchLrclibLyrics(title, artist, album, (durationMs / 1000L).toInt())
            }
            if (!lyrics.isNullOrBlank() && _state.value.key == key) {
                lyricCache[key] = lyrics
                // Keep the in-memory cache small during long listening sessions.
                while (lyricCache.size > 40) lyricCache.remove(lyricCache.keys.first())
                _state.value = _state.value.copy(lyrics = lyrics)
            }
        }
    }

    /** LRCLIB returns timestamped LRC where available, otherwise plain lyrics. */
    private fun fetchLrclibLyrics(
        title: String,
        artist: String,
        album: String,
        durationSeconds: Int,
    ): String? {
        // First try LRCLIB's strict signature match, which is the most reliable version match.
        val direct = requestLrclibJson(
            Uri.parse("https://lrclib.net/api/get").buildUpon()
                .appendQueryParameter("track_name", title)
                .appendQueryParameter("artist_name", artist)
                .apply { if (album.isNotBlank()) appendQueryParameter("album_name", album) }
                .appendQueryParameter("duration", durationSeconds.toString())
                .build().toString(),
        )
        if (direct != null) {
            // The HTTP helper returns raw response text; parse the single-track JSON object
            // before reading its lyric fields.
            val directObject = runCatching { JSONObject(direct) }.getOrNull()
            val exact = directObject?.let(::lyricsFromJson)
            if (!exact.isNullOrBlank()) return exact
        }

        // Fallback search handles small metadata/duration discrepancies while still requiring
        // a close title, artist, and duration match to avoid showing lyrics for another version.
        val searchUri = Uri.parse("https://lrclib.net/api/search").buildUpon()
            .appendQueryParameter("track_name", title)
            .appendQueryParameter("artist_name", artist)
            .apply { if (album.isNotBlank()) appendQueryParameter("album_name", album) }
            .build().toString()
        val results = requestLrclibJson(searchUri) ?: return null
        val records = runCatching { org.json.JSONArray(results) }.getOrNull() ?: return null
        val normalizedTitle = title.trim().lowercase()
        val normalizedArtist = artist.trim().lowercase()
        var best: JSONObject? = null
        var bestDifference = Int.MAX_VALUE
        for (index in 0 until records.length()) {
            val candidate = records.optJSONObject(index) ?: continue
            if (candidate.optString("trackName").trim().lowercase() != normalizedTitle) continue
            if (candidate.optString("artistName").trim().lowercase() != normalizedArtist) continue
            val difference = kotlin.math.abs(candidate.optInt("duration", -10_000) - durationSeconds)
            if (difference <= 3 && difference < bestDifference) {
                best = candidate
                bestDifference = difference
            }
        }
        return best?.let(::lyricsFromJson)
    }

    private fun requestLrclibJson(requestUrl: String): String? {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(requestUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8_000
                readTimeout = 8_000
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "GlassLock2/1.7 (Android)")
            }
            if (connection.responseCode != HttpURLConnection.HTTP_OK) return null
            connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (_: Exception) {
            null
        } finally {
            connection?.disconnect()
        }
    }

    private fun lyricsFromJson(json: JSONObject): String? {
        val synced = json.optString("syncedLyrics").takeUnless { it.isBlank() || it == "null" }
        return synced ?: json.optString("plainLyrics").takeUnless { it.isBlank() || it == "null" }
    }

    fun playPause() {
        val c = controller ?: return
        if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause() else c.transportControls.play()
    }

    fun next() = controller?.transportControls?.skipToNext()
    fun previous() = controller?.transportControls?.skipToPrevious()
    fun seekTo(ms: Long) = controller?.transportControls?.seekTo(ms)
}
