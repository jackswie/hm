# GlassLock2 3.0 — Optical Modes Development Build

Based on the 3.0 Final Release Candidate 2 source.

## Changes in this pass
- Added persisted `GlassOpticalMode` values: LIVE, REFERENCE, HYBRID.
- Added optional `GlassStyle.referenceImagePath` and selector/path controls to the material editor.
- Extended the AGSL lens shader to blend the live backdrop with a reference bitmap shader. REFERENCE uses the reference bitmap; HYBRID blends it 50/50 with live. If no readable reference bitmap is configured, both safely fall back to LIVE.
- Added a profile-level independent `textStyle` field with a backwards-compatible default.

## Important limitations
- The reference-image field currently accepts an app-private filesystem path. A system photo-picker/import workflow has not yet been added, so this is a developer-facing reference source rather than a polished end-user image picker.
- Text style is persisted but still needs to be connected to every text-rendering surface in the UI.
- This pass does not constitute the complete animation overhaul.
- No AI outpainting is included, as requested.

## Build / verification
- Source ZIP integrity and XML parsing should be checked after packaging.
- Android compilation and device testing have not been run in this environment. Validate with the existing GitHub Actions workflow and test on the Lenovo Idea Tab Pro before replacing a known-good build.
