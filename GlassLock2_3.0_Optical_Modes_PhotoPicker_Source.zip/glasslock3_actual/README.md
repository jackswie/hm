# GlassLock2 3.0 — Optical Modes Development Build

Based on the 3.0 Final Release Candidate 2 source.

## Changes in this pass
- Added persisted `GlassOpticalMode` values: LIVE, REFERENCE, HYBRID.
- Added optional `GlassStyle.referenceImagePath` and selector/path controls to the material editor.
- Extended the AGSL lens shader to blend the live backdrop with a reference bitmap shader. REFERENCE uses the reference bitmap; HYBRID blends it 50/50 with live. If no readable reference bitmap is configured, both safely fall back to LIVE.
- Added a profile-level independent `textStyle` field with a backwards-compatible default.

## Important limitations
- The reference-image field currently accepts an app-private filesystem path. A system photo-picker/import workflow has not yet been added, so this is a developer-facing reference source rather than a polished end-user image picker.
- Text style is persisted but still needs to be connected to every text-rendering surface in the UI.
- This pass does not constitute the complete animation overhaul.
- No AI outpainting is included, as requested.

## Build / verification
- Source ZIP integrity and XML parsing should be checked after packaging.
- Android compilation and device testing have not been run in this environment. Validate with the existing GitHub Actions workflow and test on the Lenovo Idea Tab Pro before replacing a known-good build.


## 3.0 optical integration follow-up
- Added an in-editor system photo picker for each GlassStyle reference source. Selected images are copied into app-private storage; no manually typed file paths are needed.
- Reference image path and optical mode are part of the shader effect cache key, so changing the selected image or Live/Reference/Hybrid mode rebuilds the optical effect.
- Connected the style through the backdrop draw path so AGSL can receive the selected optical source.
- Reference mode samples the selected image; Hybrid uses a 50/50 live/reference blend; missing or unreadable references fall back to Live.

## Remaining limitations
- This is not a completed animation overhaul. Existing motion is retained; a consistent reduced-motion pass across all surfaces remains outstanding.
- The profile has an independent text material setting, but it is not yet exposed as a dedicated editor sheet or applied to every standalone text surface.
- No Android build or tablet validation was performed in this environment.
