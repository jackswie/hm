# GlassLock2 1.8 — Focus, Motion & Glass Studio

Built from the latest Pass31–36 Motion Studio CompileFix1 source package.

## New in 1.8
- Focus Timer widget with configurable 1–180 minute sessions, pause/resume, completion state and reset.
- Stopwatch widget with start, pause and reset.
- Next Alarm widget showing the next Android system alarm, refreshed while the lock screen is open.
- Habit Tracker now stores daily check-ins locally and calculates a real consecutive-day streak instead of showing placeholder history.
- Widget editor includes settings for the new timer widgets.
- Version advanced to 1.8 / versionCode 37.
- Liquid Glass optical backdrop contribution was carefully increased from 12% to 16%; the real wallpaper remains the guaranteed base layer to avoid opaque/black fallback behavior on less compatible GPUs.

## Preserved
All previous profile, wallpaper, clock, music/lyrics, widget, quick-action, notification, scene, theme and animation features remain in the project.

## Build verification
ZIP integrity and source-level checks are performed before delivery. An Android Gradle build/device run must still be performed in GitHub Actions and on the target tablet; this environment does not provide the Android Gradle toolchain.
