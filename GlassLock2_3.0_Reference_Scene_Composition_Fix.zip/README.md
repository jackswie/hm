# GlassLock2 3.0 — Final Candidate 3

This package continues from the 3.0 optical-modes + reference photo-picker source.

## Included
- Live / Reference / Hybrid optical modes wired into the AGSL glass sampling path.
- Per-style reference image selection via Android document picker; images are copied to app-private storage.
- Per-surface glass settings for clock, widgets, media and notifications.
- Dedicated text material settings for the focus/status pill, including optical source and refraction controls.
- Reduced-motion handling for album cover scaling and player/notification entrances. Existing wallpaper reduced-motion option controls this behavior.
- Local album Smart Expansion remains on-device and does not require AI services.
- CENTER and LEFT album layouts remain available.

## Important limitations
- AI outpainting was intentionally removed from scope.
- Reference images are sampled as a source texture by the shader; they are not a full scene-aware 3D reconstruction.
- Hybrid blends the live backdrop and selected reference source evenly.
- Android build and device validation are still required. ZIP/XML checks are not a substitute for Gradle compilation or testing on the Lenovo tablet.


### Reference background composition (stability update)

- Reference mode now uses the selected image as the exclusive full-screen scene source; the live wallpaper and ambient atmosphere are not drawn underneath it.
- The full-screen cropped reference is captured once by the shared glass backdrop. Clock, media, notification, and widget surfaces sample that same captured scene and apply their own local shape masks.
- Reference mode bypasses the device-sensitive AGSL/RenderEffect pass that could produce black patches on some GPUs; it keeps the real reference pixels, shape clipping, tint, and rim. Live mode retains the normal optical path. Hybrid mode remains an intentional 50/50 reference/live composite.
