package com.glasslock.ui.glass

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.IntSize
import kotlin.math.roundToInt

/**
 * Android cannot blur "whatever is behind a view", so the wallpaper is recorded once into a
 * [GraphicsLayer]. Every glass surface then re-draws a copy of that layer, shifted so it lines up
 * with the real wallpaper, and applies its own blur/refraction to the copy.
 */
@Stable
class GlassBackdrop(val layer: GraphicsLayer) {
    /** Position of the wallpaper in root coordinates. */
    var origin by mutableStateOf(Offset.Zero)

    /** Bumped each time the wallpaper is re-recorded; glass surfaces compare it to skip work. */
    var version: Int = 0
}

/** Everything a glass surface needs from the scene it is placed in. */
class GlassEnvironment(
    val backdrop: GlassBackdrop,
    /** Device tilt in -1..1 (x = right, y = up). Read only inside draw blocks. */
    val tilt: State<Offset>,
    /** Dominant wallpaper colour used by the Tinted appearance. */
    val tint: Color,
    /** True when the selected reference image is the exclusive scene source. */
    val referenceOnly: Boolean = false,
)

val LocalGlassEnvironment = staticCompositionLocalOf<GlassEnvironment?> { null }

@Composable
fun rememberGlassBackdrop(): GlassBackdrop {
    val layer = rememberGraphicsLayer()
    return remember(layer) { GlassBackdrop(layer) }
}

/** Marks the wallpaper subtree as the thing glass surfaces look through. */
fun Modifier.glassSource(backdrop: GlassBackdrop): Modifier = this
    .onGloballyPositioned { backdrop.origin = it.positionInRoot() }
    .drawWithContent {
        backdrop.layer.record(
            this,
            layoutDirection,
            IntSize(size.width.roundToInt(), size.height.roundToInt()),
        ) {
            this@drawWithContent.drawContent()
        }
        backdrop.version++
        drawLayer(backdrop.layer)
    }
