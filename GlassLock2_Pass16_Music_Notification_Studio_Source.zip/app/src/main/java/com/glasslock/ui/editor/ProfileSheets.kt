package com.glasslock.ui.editor

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.glasslock.data.model.GlassStyle
import com.glasslock.data.model.WallpaperConfig
import com.glasslock.data.model.WallpaperFilter
import com.glasslock.data.model.WallpaperKind
import com.glasslock.ui.glass.Palette
import com.glasslock.ui.theme.Ink

@Composable
fun StyleSheet(title: String, style: GlassStyle, palette: Palette, onChange: ((GlassStyle) -> GlassStyle) -> Unit, onDismiss: () -> Unit, modifier: Modifier = Modifier) {
    SheetFrame(title, onDismiss, modifier) { StyleControls(style, palette, onChange) }
}

@Composable
fun WallpaperSheet(
    cfg: WallpaperConfig,
    palette: Palette,
    onChange: ((WallpaperConfig) -> WallpaperConfig) -> Unit,
    onPickPhoto: () -> Unit,
    onResetView: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    SheetFrame("Wallpaper", onDismiss, modifier) {
        Text(
            "Pinch with two fingers to zoom and pan. Swipe left or right on the wallpaper to change the filter.",
            color = Ink.secondary, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp),
        )
        SectionTitle("Filter")
        ChipFlow(WallpaperFilter.entries, cfg.filter, { f -> onChange { it.copy(filter = f) } }, { it.label })

        SectionTitle("Options")
        ToggleRow("Dim wallpaper", cfg.dim) { v -> onChange { it.copy(dim = v) } }
        ToggleRow("Blur wallpaper", cfg.blur, note = "Hides the Depth Effect while on") { v -> onChange { it.copy(blur = v) } }
        ToggleRow(
            "Extend wallpaper", cfg.extend, enabled = cfg.kind == WallpaperKind.PHOTO,
            note = "Fits the whole photo and fills the edges with a blurred copy",
        ) { v -> onChange { it.copy(extend = v) } }

        when (cfg.kind) {
            WallpaperKind.EMOJI -> {
                GlassTextField("Emoji", cfg.emoji) { v -> onChange { it.copy(emoji = v) } }
                SectionTitle("Background")
                ColorPickerSection(Color(cfg.color1), palette.swatches) { c -> onChange { it.copy(color1 = c.toArgb()) } }
            }
            WallpaperKind.GRADIENT -> {
                SectionTitle("Gradient start")
                ColorPickerSection(Color(cfg.color1), palette.swatches) { c -> onChange { it.copy(color1 = c.toArgb()) } }
                SectionTitle("Gradient end")
                ColorPickerSection(Color(cfg.color2), palette.swatches) { c -> onChange { it.copy(color2 = c.toArgb()) } }
            }
            else -> Unit
        }

        SectionTitle("Photo & view")
        Row {
            GlassPill("Choose photo", onPickPhoto)
            GlassPill("Reset view", onResetView, Modifier.padding(start = 10.dp))
        }
    }
}

@Composable
fun NewProfileSheet(onPick: (NewKind) -> Unit, onDismiss: () -> Unit, modifier: Modifier = Modifier) {
    SheetFrame("New Lock Screen", onDismiss, modifier) {
        SectionTitle("Choose a type")
        ChipFlow<NewKind?>(NewKind.entries, null, { k -> k?.let(onPick) }, { it?.label ?: "" })
        Text(
            "Extended Photo fits the whole picture and fills the rest with a blurred copy of it.",
            color = Ink.secondary, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp),
        )
    }
}

@Composable
fun FocusSheet(emoji: String, label: String, onChange: (String, String) -> Unit, onDismiss: () -> Unit, modifier: Modifier = Modifier) {
    SheetFrame("Focus", onDismiss, modifier) {
        Text(
            "Shown in the pill under the Now Playing card whenever this lock screen is active.",
            color = Ink.secondary, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp),
        )
        GlassTextField("Icon (emoji)", emoji) { onChange(it, label) }
        GlassTextField("Label", label) { onChange(emoji, it) }
        SectionTitle("Presets")
        ChipFlow<String?>(
            listOf("🌙 Do Not Disturb", "💼 Work", "😴 Sleep", "🚗 Driving", "📖 Reading", "★ peace"), null,
            { p ->
                p?.let { onChange(it.substringBefore(' '), it.substringAfter(' ')) }
            },
            { it ?: "" },
        )
    }
}


@Composable
fun NotificationSheet(
    style: GlassStyle,
    palette: Palette,
    limit: Int,
    onLimitChange: (Int) -> Unit,
    onStyleChange: ((GlassStyle) -> GlassStyle) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    SheetFrame("Notifications", onDismiss, modifier) {
        SectionTitle("Visible notifications")
        Segmented(
            options = listOf(2 to "2", 3 to "3", 4 to "4", 6 to "6"),
            selected = limit, onSelect = onLimitChange,
        )
        Text("Controls the maximum number of notification cards shown in both lock-screen and album layouts. App groups can still stack together.", color = Ink.secondary, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        SectionTitle("Notification material")
        StyleControls(style, palette, onStyleChange)
    }
}
