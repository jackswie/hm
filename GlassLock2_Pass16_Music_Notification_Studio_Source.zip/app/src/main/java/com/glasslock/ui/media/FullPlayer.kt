package com.glasslock.ui.media

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.glasslock.data.model.GlassStyle
import com.glasslock.data.model.AlbumArtworkStyle
import com.glasslock.data.model.ClockConfig
import com.glasslock.ui.clock.ClockFonts
import com.glasslock.ui.clock.ClockTypefaces
import com.glasslock.service.LockNotification
import com.glasslock.ui.clock.ClockPlacement
import com.glasslock.ui.notifications.NotificationStack

/**
 * Album mode for tablets. Artwork occupies the left half; the right column is deliberately ordered
 * clock -> playback controls -> notifications. Each region has its own constraints and entrance
 * motion, so resizing the lock-screen clock cannot affect this layout.
 */
@Composable
fun BoxScope.FullPlayer(
    np: NowPlaying,
    artwork: android.graphics.Bitmap?,
    style: GlassStyle,
    placement: ClockPlacement,
    clockText: String,
    clockConfig: ClockConfig,
    notifications: List<LockNotification>,
    notificationStyle: GlassStyle,
    onNotificationOpen: (LockNotification) -> Unit,
    onNotificationDismiss: (LockNotification) -> Unit,
    onClose: () -> Unit,
    onEditClock: () -> Unit,
    showEditHint: Boolean,
    editing: Boolean,
    blendPlayerBackground: Boolean,
    artworkStyle: AlbumArtworkStyle,
    notificationLimit: Int,
    onEditMedia: () -> Unit,
    onEditNotifications: () -> Unit,
    onOutput: () -> Unit,
) {
    val art = remember(artwork) { artwork?.asImageBitmap() } ?: return
    val context = LocalContext.current
    val albumFont = remember(context, clockConfig.font, clockConfig.weight) {
        FontFamily(ClockTypefaces.create(context, ClockFonts.spec(clockConfig.font), clockConfig.weight))
    }
    val landscape = placement.screen.width >= placement.screen.height
    val scale by animateFloatAsState(
        targetValue = if (np.isPlaying) 1f else 0.90f,
        animationSpec = spring(dampingRatio = 0.78f, stiffness = 260f),
        label = "albumCoverScale",
    )

    // Background dismiss target; interactive content is composed above it.
    Box(
        Modifier.fillMaxSize().clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null,
            onClick = onClose,
        )
    )

    if (landscape) {
        Row(
            Modifier.fillMaxSize().padding(start = 54.dp, end = 54.dp, top = 66.dp, bottom = 92.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(48.dp),
        ) {
            BoxWithConstraints(Modifier.weight(1.08f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                CoverArt(art, minOf(maxWidth, maxHeight) * 0.94f, scale, np.isPlaying, artworkStyle)
            }
            Column(
                Modifier.weight(0.92f).fillMaxHeight().padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                AnimatedVisibility(
                    visible = true,
                    enter = fadeIn(tween(300, delayMillis = 70)) +
                        slideInVertically(animationSpec = spring(dampingRatio = 0.82f, stiffness = 310f), initialOffsetY = { it / 7 }) +
                        scaleIn(animationSpec = spring(dampingRatio = 0.84f, stiffness = 300f), initialScale = 0.965f),
                ) {
                    Text(
                        clockText,
                        color = Color.White,
                        fontSize = 76.sp,
                        lineHeight = 80.sp,
                        fontFamily = albumFont,
                        fontWeight = FontWeight(clockConfig.weight.coerceIn(1, 1000)),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.graphicsLayer { alpha = 0.98f }.clickable(onClick = onEditClock),
                    )
                }
                if (showEditHint) {
                    Text(
                        "EDIT ALBUM CLOCK",
                        color = Color.White.copy(alpha = 0.62f),
                        fontSize = 9.sp,
                        letterSpacing = 1.8.sp,
                        modifier = Modifier.clickable(onClick = onEditClock).padding(top = 3.dp, bottom = 12.dp),
                    )
                }
                Spacer(Modifier.height(4.dp))
                if (editing) Text("TAP PLAYER TO EDIT", color = Color.White.copy(alpha = 0.54f), fontSize = 9.sp, letterSpacing = 1.5.sp)
                AnimatedVisibility(
                    visible = true,
                    enter = fadeIn(tween(280, delayMillis = 130)) +
                        slideInVertically(animationSpec = spring(dampingRatio = 0.82f, stiffness = 330f), initialOffsetY = { it / 6 }) +
                        scaleIn(animationSpec = spring(dampingRatio = 0.86f, stiffness = 320f), initialScale = 0.975f),
                ) {
                    NowPlayingCard(
                        np = np, style = style, interactive = !editing,
                        onDismiss = onClose, onOutput = onOutput, onEditTap = onEditMedia,
                        expanded = true, showSurface = !blendPlayerBackground,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                AnimatedVisibility(
                    visible = notifications.isNotEmpty(),
                    enter = fadeIn(tween(260, delayMillis = 210)) +
                        slideInVertically(animationSpec = spring(dampingRatio = 0.86f, stiffness = 360f), initialOffsetY = { -it / 5 }) +
                        scaleIn(animationSpec = spring(dampingRatio = 0.88f, stiffness = 340f), initialScale = 0.985f),
                ) {
                    Column(Modifier.fillMaxWidth().padding(top = 14.dp)) {
                        if (editing) Text("TAP NOTIFICATIONS TO EDIT", color = Color.White.copy(alpha = 0.54f), fontSize = 9.sp, letterSpacing = 1.5.sp, modifier = Modifier.padding(bottom = 5.dp))
                        NotificationStack(
                            items = notifications.take(notificationLimit), style = notificationStyle,
                            interactive = !editing, onOpen = onNotificationOpen,
                            onDismiss = onNotificationDismiss, onEditTap = onEditNotifications,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }
        }
    } else {
        Column(
            Modifier.fillMaxSize().padding(start = 22.dp, end = 22.dp, top = 54.dp, bottom = 92.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                CoverArt(art, minOf(maxWidth, maxHeight) * 0.82f, scale, np.isPlaying, artworkStyle)
            }
            AnimatedVisibility(visible = true, enter = fadeIn(tween(300, delayMillis = 70)) + slideInVertically(animationSpec = spring(dampingRatio = 0.82f, stiffness = 310f), initialOffsetY = { it / 7 }) + scaleIn(spring(dampingRatio = 0.84f, stiffness = 300f), initialScale = 0.965f)) {
                Text(clockText, color = Color.White, fontSize = 56.sp, fontFamily = albumFont, fontWeight = FontWeight(clockConfig.weight.coerceIn(1, 1000)), modifier = Modifier.clickable(onClick = onEditClock))
            }
            if (showEditHint) Text("EDIT ALBUM CLOCK", color = Color.White.copy(alpha = 0.62f), fontSize = 9.sp, letterSpacing = 1.8.sp, modifier = Modifier.clickable(onClick = onEditClock))
            if (editing) Text("TAP PLAYER TO EDIT", color = Color.White.copy(alpha = 0.54f), fontSize = 9.sp, letterSpacing = 1.5.sp)
            AnimatedVisibility(visible = true, enter = fadeIn(tween(280, delayMillis = 130)) + slideInVertically(animationSpec = spring(dampingRatio = 0.82f, stiffness = 330f), initialOffsetY = { it / 6 }) + scaleIn(spring(dampingRatio = 0.86f, stiffness = 320f), initialScale = 0.975f)) {
                NowPlayingCard(
                    np = np, style = style, interactive = !editing,
                    onDismiss = onClose, onOutput = onOutput, onEditTap = onEditMedia,
                    expanded = true, showSurface = !blendPlayerBackground, modifier = Modifier.fillMaxWidth(),
                )
            }
            AnimatedVisibility(
                visible = notifications.isNotEmpty(),
                enter = fadeIn(tween(260, delayMillis = 210)) +
                        slideInVertically(animationSpec = spring(dampingRatio = 0.86f, stiffness = 360f), initialOffsetY = { -it / 5 }) +
                        scaleIn(animationSpec = spring(dampingRatio = 0.88f, stiffness = 340f), initialScale = 0.985f),
            ) {
                Column(Modifier.fillMaxWidth()) {
                    if (editing) Text("TAP NOTIFICATIONS TO EDIT", color = Color.White.copy(alpha = 0.54f), fontSize = 9.sp, letterSpacing = 1.5.sp, modifier = Modifier.padding(bottom = 5.dp))
                    NotificationStack(
                        items = notifications.take(notificationLimit), style = notificationStyle,
                    interactive = !editing, onOpen = onNotificationOpen,
                        onDismiss = onNotificationDismiss, onEditTap = onEditNotifications,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }
    }
}

@Composable
private fun CoverArt(art: ImageBitmap, side: Dp, scale: Float, playing: Boolean, artworkStyle: AlbumArtworkStyle) {
    val shape = RoundedCornerShape(28.dp)
    // A directional, spring-settled handoff: the previous cover stays composed beneath
    // the incoming one, so metadata churn never exposes an empty/black placeholder frame.
    AnimatedContent(
        targetState = art,
        transitionSpec = {
            (fadeIn(tween(300)) +
                slideInHorizontally(animationSpec = spring(dampingRatio = 0.86f, stiffness = 260f)) { it / 12 } +
                scaleIn(animationSpec = spring(dampingRatio = 0.86f, stiffness = 280f), initialScale = 1.035f)) togetherWith
                (fadeOut(tween(240)) +
                    slideOutHorizontally(animationSpec = spring(dampingRatio = 0.9f, stiffness = 300f)) { -it / 16 } +
                    scaleOut(animationSpec = spring(dampingRatio = 0.9f, stiffness = 300f), targetScale = 0.975f))
        },
        label = "albumArtworkSpatialTransition",
    ) { cover ->
        if (artworkStyle == AlbumArtworkStyle.VINYL) {
            VinylArtwork(cover, side, scale, playing)
        } else {
            Image(
                cover, null,
                Modifier
                    .size(side)
                    .graphicsLayer { scaleX = scale; scaleY = scale }
                    .shadow(30.dp, shape, clip = false, ambientColor = Color.Black.copy(alpha = 0.34f), spotColor = Color.Black.copy(alpha = 0.42f))
                    .clip(shape),
                contentScale = ContentScale.Fit,
                filterQuality = FilterQuality.High,
            )
        }
    }
}


@Composable
private fun VinylArtwork(art: ImageBitmap, side: Dp, scale: Float, playing: Boolean) {
    val transition = rememberInfiniteTransition(label = "vinylRotation")
    val rotation by transition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(12_000, easing = LinearEasing)),
        label = "vinylRotationAngle",
    )
    Box(
        Modifier.size(side)
            .graphicsLayer { scaleX = scale; scaleY = scale; rotationZ = if (playing) rotation else 0f }
            .shadow(30.dp, CircleShape, clip = false, ambientColor = Color.Black.copy(alpha = 0.38f), spotColor = Color.Black.copy(alpha = 0.46f)),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(Color(0xFF111216))
            val maxR = size.minDimension * 0.47f
            for (i in 1..18) {
                val radius = maxR * (0.48f + i * 0.027f)
                drawCircle(Color.White.copy(alpha = if (i % 3 == 0) 0.13f else 0.055f), radius, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.dp.toPx()))
            }
            drawCircle(Color(0xFF292B30), maxR * 0.48f)
        }
        Image(
            art, null,
            Modifier.size(side * 0.46f).clip(CircleShape),
            contentScale = ContentScale.Crop, filterQuality = FilterQuality.High,
        )
    }
}
