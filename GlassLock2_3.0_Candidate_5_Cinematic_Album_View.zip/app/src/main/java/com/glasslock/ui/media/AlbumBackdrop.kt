package com.glasslock.ui.media

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.LinearGradient
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.glasslock.ui.glass.Palette
import com.glasslock.ui.glass.WallpaperPalette
import androidx.compose.ui.graphics.toArgb

/**
 * The "album wallpaper" shown while the full-screen player is open: the cover, centre-cropped to the screen's
 * shape, blurred into soft colour fields, made a little more vivid and slightly darker so white text and glass
 * read well. This is what Apple's Now Playing lock screen does. It replaces the wallpaper for the scene, so the
 * glass clock refracts the album colours too.
 */
class AlbumBackdrop(val image: ImageBitmap, val palette: Palette) {
    companion object {
        // Keep a few recently used album atmospheres in memory. Track changes back to a
        // recently played album can reuse its locally generated background immediately.
        // The cache is deliberately small because each rendered bitmap is screen-sized.
        private val cache = object : LruCache<String, AlbumBackdrop>(4) {}

        fun render(art: Bitmap, landscape: Boolean): AlbumBackdrop? = runCatching {
            val key = cacheKey(art, landscape)
            cache.get(key) ?: build(art, landscape).also { cache.put(key, it) }
        }.getOrNull()

        private fun cacheKey(bitmap: Bitmap, landscape: Boolean): String {
            if (bitmap.isRecycled || bitmap.width <= 0 || bitmap.height <= 0) {
                return "invalid-${System.identityHashCode(bitmap)}-$landscape"
            }
            // Sample pixels rather than relying on Bitmap identity: media apps often publish
            // a fresh Bitmap instance for the same album after a session reconnect.
            val readable = if (bitmap.config == Bitmap.Config.HARDWARE) {
                bitmap.copy(Bitmap.Config.ARGB_8888, false)
            } else bitmap
            val points = 8
            var hash = 17L
            try {
                for (y in 0 until points) {
                    for (x in 0 until points) {
                        val sx = (x * (readable.width - 1) / (points - 1)).coerceIn(0, readable.width - 1)
                        val sy = (y * (readable.height - 1) / (points - 1)).coerceIn(0, readable.height - 1)
                        hash = hash * 31L + readable.getPixel(sx, sy).toLong()
                    }
                }
            } finally {
                if (readable !== bitmap) readable.recycle()
            }
            return "${bitmap.width}x${bitmap.height}-$hash-$landscape"
        }

        private fun build(art: Bitmap, landscape: Boolean): AlbumBackdrop {
            val src = if (art.config == Bitmap.Config.HARDWARE) art.copy(Bitmap.Config.ARGB_8888, false) else art
            val palette = WallpaperPalette.from(src)

            // Keep enough source detail for a large tablet display while still doing all
            // expensive blur work on a compact bitmap.
            val w = if (landscape) 144 else 96
            val h = if (landscape) 90 else 160

            // Centre-crop the cover to the screen's aspect ratio.
            val sw = src.width
            val sh = src.height
            val target = w.toFloat() / h
            val crop = if (sw.toFloat() / sh > target) {
                val cw = (sh * target).toInt()
                Rect((sw - cw) / 2, 0, (sw - cw) / 2 + cw, sh)
            } else {
                val ch = (sw / target).toInt()
                Rect(0, (sh - ch) / 2, sw, (sh - ch) / 2 + ch)
            }
            val small = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            Canvas(small).drawBitmap(src, crop, Rect(0, 0, w, h), Paint(Paint.FILTER_BITMAP_FLAG))

            // Big soft blur on the tiny copy (cheap), then scale up smoothly.
            val px = IntArray(w * h)
            small.getPixels(px, 0, w, 0, 0, w, h)
            val tmp = IntArray(px.size)
            val radius = maxOf(w, h) / 8
            // Two broad passes create Apple's soft, colour-field look without destroying
            // all artwork structure; the final palette wash adds a second depth layer.
            repeat(2) {
                blurPass(px, tmp, w, h, radius, true)
                blurPass(tmp, px, w, h, radius, false)
            }
            small.setPixels(px, 0, w, 0, 0, w, h)

            val graded = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val matrix = ColorMatrix().apply { setSaturation(1.32f) }
            matrix.postConcat(
                ColorMatrix(
                    floatArrayOf(
                        0.9f, 0f, 0f, 0f, 0f,
                        0f, 0.9f, 0f, 0f, 0f,
                        0f, 0f, 0.9f, 0f, 0f,
                        0f, 0f, 0f, 1f, 0f,
                    )
                )
            )
            Canvas(graded).drawBitmap(small, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(matrix) })

            val big = Bitmap.createScaledBitmap(graded, w * 8, h * 8, true)
            // Colour-managed atmosphere: a very soft dominant-colour bloom, a secondary
            // corner glow, and a restrained vertical contrast veil. This avoids a flat
            // enlarged blur and keeps white player controls readable over bright covers.
            val glowA = palette.swatches.firstOrNull()?.toArgb() ?: palette.tint.toArgb()
            val glowB = palette.swatches.getOrNull(1)?.toArgb() ?: glowA
            val canvas = Canvas(big)
            val short = minOf(big.width, big.height).toFloat()
            val bloom = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(
                    big.width * 0.22f, big.height * 0.22f, short * 0.78f,
                    intArrayOf((glowA and 0x00FFFFFF) or 0x30000000, (glowA and 0x00FFFFFF) or 0x08000000, android.graphics.Color.TRANSPARENT),
                    floatArrayOf(0f, 0.58f, 1f), Shader.TileMode.CLAMP,
                )
            }
            canvas.drawRect(0f, 0f, big.width.toFloat(), big.height.toFloat(), bloom)
            val secondary = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(
                    big.width * 0.88f, big.height * 0.72f, short * 0.62f,
                    intArrayOf((glowB and 0x00FFFFFF) or 0x26000000, android.graphics.Color.TRANSPARENT),
                    null, Shader.TileMode.CLAMP,
                )
            }
            canvas.drawRect(0f, 0f, big.width.toFloat(), big.height.toFloat(), secondary)
            val veil = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(
                    0f, 0f, 0f, big.height.toFloat(),
                    intArrayOf(0x08000000, 0x00000000, 0x18000000, 0x52000000),
                    floatArrayOf(0f, 0.34f, 0.72f, 1f), Shader.TileMode.CLAMP,
                )
            }
            canvas.drawRect(0f, 0f, big.width.toFloat(), big.height.toFloat(), veil)
            if (src !== art) src.recycle()
            return AlbumBackdrop(big.asImageBitmap(), palette)
        }

        private fun blurPass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
            val n = 2 * r + 1
            for (y in 0 until h) {
                for (x in 0 until w) {
                    var red = 0
                    var green = 0
                    var blue = 0
                    for (k in -r..r) {
                        val xx = if (horizontal) (x + k).coerceIn(0, w - 1) else x
                        val yy = if (horizontal) y else (y + k).coerceIn(0, h - 1)
                        val c = src[yy * w + xx]
                        red += (c shr 16) and 0xFF
                        green += (c shr 8) and 0xFF
                        blue += c and 0xFF
                    }
                    dst[y * w + x] = (0xFF shl 24) or ((red / n) shl 16) or ((green / n) shl 8) or (blue / n)
                }
            }
        }
    }
}
