package com.glasslock.ui.editor

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import android.text.format.DateFormat
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.glasslock.data.model.CLOCK_MAX_HEIGHT
import com.glasslock.data.model.CLOCK_MIN_HEIGHT
import com.glasslock.data.model.ClockConfig
import com.glasslock.data.model.GlassStyle
import com.glasslock.data.model.GlassMode
import com.glasslock.data.model.LockProfile
import com.glasslock.data.model.ScenePreset
import com.glasslock.data.model.ProfileStore
import com.glasslock.data.model.ProfileThemeCodec
import com.glasslock.data.model.QuickActionConfig
import com.glasslock.data.model.WallpaperConfig
import com.glasslock.data.model.WallpaperFilter
import com.glasslock.data.model.WallpaperKind
import com.glasslock.data.model.WidgetConfig
import com.glasslock.data.model.WidgetSize
import com.glasslock.data.model.WidgetType
import com.glasslock.ui.clock.CutoutRepository
import com.glasslock.ui.clock.DemoWallpaper
import com.glasslock.ui.clock.WallpaperFactory
import com.glasslock.ui.clock.WallpaperLoader
import com.glasslock.ui.glass.Palette
import com.glasslock.ui.glass.WallpaperPalette
import com.glasslock.ui.widgets.WidgetGrid
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import java.util.UUID

/** Which configurator is open. */
sealed interface Sheet {
    data object None : Sheet
    data object Clock : Sheet
    data object AlbumClock : Sheet
    data object AddWidget : Sheet
    data object Media : Sheet
    data object Notifications : Sheet
    data object Status : Sheet
    data object Wallpaper : Sheet
    data object Scenes : Sheet
    data object NewProfile : Sheet
    data class Widget(val id: String) : Sheet
    data class Quick(val left: Boolean) : Sheet
    data class Focus(val profileId: String) : Sheet
}

/** Lock screen types offered by the gallery's "+" button. */
enum class NewKind(val label: String) {
    PHOTO("Photo"), WEATHER("Weather"), ASTRONOMY("Astronomy"), EMOJI("Emoji"), GRADIENT("Color Gradient"), EXTENDED("Extended Photo")
}

data class EditorUiState(
    val profiles: List<LockProfile> = listOf(LockProfile()),
    /** The active profile; always one of [profiles]. */
    val profile: LockProfile = LockProfile(),
    val committedProfiles: List<LockProfile> = emptyList(),
    val committedActiveId: String = "",
    val editing: Boolean = false,
    val galleryOpen: Boolean = false,
    val sheet: Sheet = Sheet.None,
    val thumbs: Map<String, ImageBitmap> = emptyMap(),
    val wallpaper: ImageBitmap? = null,
    val cutout: ImageBitmap? = null,
    val palette: Palette = Palette.Default,
    val segmenting: Boolean = false,
    val gridRows: Int = 6,
    val notice: String? = null,
    /** Track whose card the user swiped away; the card returns when the track changes. */
    val dismissedMediaKey: String? = null,
)

class EditorViewModel(app: Application) : AndroidViewModel(app) {
    private val store = ProfileStore(app)
    private val cutouts = CutoutRepository(app)

    private val _ui = MutableStateFlow(EditorUiState())
    val ui: StateFlow<EditorUiState> = _ui.asStateFlow()

    private var loadJob: Job? = null
    private var sourceBitmap: Bitmap? = null
    private var pendingKind: NewKind? = null
    private var openGalleryWhenReady = false

    init {
        viewModelScope.launch {
            var list = store.profiles.first()
            if (list.isEmpty()) list = listOf(LockProfile(clock = ClockConfig(use24Hour = DateFormat.is24HourFormat(app))))
            val active = list.firstOrNull { it.id == store.activeId.first() } ?: list.first()
            _ui.update { it.copy(profiles = list, profile = active, committedProfiles = list, committedActiveId = active.id) }
            loadAssets(active)
            if (openGalleryWhenReady) openGallery()
        }
    }

    private fun updateProfile(f: (LockProfile) -> LockProfile) = _ui.update { s ->
        val p = f(s.profile)
        s.copy(profile = p, profiles = s.profiles.map { if (it.id == p.id) p else it })
    }

    private fun persist() {
        val s = _ui.value
        viewModelScope.launch { store.save(s.profiles, s.profile.id) }
    }

    // ---- editing session -------------------------------------------------------------------

    fun startEdit() = _ui.update { it.copy(editing = true, galleryOpen = false, committedProfiles = it.profiles, committedActiveId = it.profile.id) }

    fun cancelEdit() {
        val s = _ui.value
        val restored = s.committedProfiles.firstOrNull { it.id == s.committedActiveId } ?: s.committedProfiles.firstOrNull() ?: return
        val neutral = { w: WallpaperConfig -> w.copy(zoom = 1f, panX = 0f, panY = 0f, filter = WallpaperFilter.NATURAL, dim = false, blur = false, extend = false) }
        val assetsChanged = neutral(restored.wallpaper) != neutral(s.profile.wallpaper)
        _ui.update { it.copy(profiles = s.committedProfiles, profile = restored, editing = false, sheet = Sheet.None) }
        if (assetsChanged) loadAssets(restored)
    }

    fun finishEdit() {
        _ui.update { it.copy(editing = false, sheet = Sheet.None, committedProfiles = it.profiles, committedActiveId = it.profile.id) }
        persist()
    }

    fun openSheet(sheet: Sheet) = _ui.update { it.copy(sheet = sheet) }
    fun closeSheet() = _ui.update { it.copy(sheet = Sheet.None) }
    fun clearNotice() = _ui.update { it.copy(notice = null) }
    fun setGridRows(rows: Int) { if (rows != _ui.value.gridRows) _ui.update { it.copy(gridRows = rows) } }

    // ---- gallery & profiles ----------------------------------------------------------------

    fun requestGalleryOnLoad() { openGalleryWhenReady = true }

    fun openGallery() {
        _ui.update { it.copy(galleryOpen = true, sheet = Sheet.None) }
        loadThumbs()
    }

    fun closeGallery() {
        _ui.update { it.copy(galleryOpen = false, sheet = Sheet.None) }
        persist()
    }

    fun selectProfile(id: String) {
        val s = _ui.value
        if (id == s.profile.id) return
        val target = s.profiles.firstOrNull { it.id == id } ?: return
        _ui.update { it.copy(profile = target) }
        loadAssets(target)
    }

    /** Returns true when the caller must open the photo picker next. */
    fun addProfile(kind: NewKind): Boolean {
        if (kind == NewKind.PHOTO || kind == NewKind.EXTENDED) {
            pendingKind = kind
            return true
        }
        val wp = WallpaperConfig(
            kind = when (kind) {
                NewKind.WEATHER -> WallpaperKind.WEATHER
                NewKind.ASTRONOMY -> WallpaperKind.ASTRONOMY
                NewKind.EMOJI -> WallpaperKind.EMOJI
                else -> WallpaperKind.GRADIENT
            }
        )
        createProfile(wp)
        return false
    }

    private fun createProfile(wp: WallpaperConfig) {
        val base = _ui.value.profile
        val p = base.copy(
            id = UUID.randomUUID().toString(),
            name = "Lock Screen ${_ui.value.profiles.size + 1}",
            wallpaper = wp,
            focusEmoji = "",
            focusLabel = "",
        )
        _ui.update { it.copy(profiles = it.profiles + p, profile = p, sheet = Sheet.None) }
        loadAssets(p)
        loadThumbs()
        persist()
    }

    fun deleteProfile(id: String) {
        val s = _ui.value
        if (s.profiles.size <= 1) {
            _ui.update { it.copy(notice = "You need at least one lock screen.") }
            return
        }
        val remaining = s.profiles.filter { it.id != id }
        val newActive = if (s.profile.id == id) remaining.first() else s.profile
        _ui.update { it.copy(profiles = remaining, profile = newActive) }
        if (s.profile.id == id) loadAssets(newActive)
        loadThumbs()
        persist()
    }

    fun setFocus(profileId: String, emoji: String, label: String) {
        _ui.update { s ->
            val profiles = s.profiles.map { if (it.id == profileId) it.copy(focusEmoji = emoji, focusLabel = label) else it }
            s.copy(profiles = profiles, profile = profiles.first { it.id == s.profile.id })
        }
    }

    private fun loadThumbs() {
        viewModelScope.launch {
            val profiles = _ui.value.profiles
            val map = withContext(Dispatchers.Default) {
                profiles.associate { p -> p.id to thumbnail(p).asImageBitmap() }
            }
            _ui.update { it.copy(thumbs = map) }
        }
    }

    private fun thumbnail(p: LockProfile): Bitmap {
        val file = p.wallpaper.file?.let(::File)?.takeIf { it.exists() }
        return when {
            p.wallpaper.kind != WallpaperKind.PHOTO -> WallpaperFactory.create(p.wallpaper, 640, 400)
            file != null -> WallpaperLoader.decode(file, 640)
            else -> DemoWallpaper.create(960, 600).first
        }
    }

    // ---- clock ---------------------------------------------------------------------------------

    fun updateAlbumClock(transform: (ClockConfig) -> ClockConfig) {
        updateProfile { it.copy(albumClock = transform(it.albumClock)) }
    }

    fun updateClock(transform: (ClockConfig) -> ClockConfig) {
        val before = _ui.value.profile.clock
        val after = transform(before)
        updateProfile { it.copy(clock = after) }
        if (after.depthEffect && !before.depthEffect) ensureCutout()
    }

    /** Corner-drag resize. [deltaFraction] is the vertical drag as a fraction of screen height. */
    fun resizeClock(deltaFraction: Float) = updateClock {
        it.copy(heightFraction = (it.heightFraction + deltaFraction).coerceIn(CLOCK_MIN_HEIGHT, CLOCK_MAX_HEIGHT))
    }

    /** Horizontal half of the free-transform corner drag. */
    fun resizeClockWidth(deltaFraction: Float) = updateClock {
        it.copy(widthFraction = (it.widthFraction + deltaFraction).coerceIn(0.08f, 1f))
    }

    // ---- wallpaper editing -----------------------------------------------------------------

    fun updateWallpaper(f: (WallpaperConfig) -> WallpaperConfig) {
        val before = _ui.value.profile.wallpaper
        val after = f(before)
        updateProfile { it.copy(wallpaper = after) }
        if (after.kind != WallpaperKind.PHOTO &&
            (after.emoji != before.emoji || after.color1 != before.color1 || after.color2 != before.color2)
        ) loadAssets(_ui.value.profile)
    }

    /** Two-finger pinch/pan. Pan arrives as a fraction of the screen. */
    fun transformWallpaper(zoomFactor: Float, panX: Float, panY: Float) = updateWallpaper {
        val z = (it.zoom * zoomFactor).coerceIn(1f, 4f)
        val limit = (z - 1f) / 2f
        it.copy(zoom = z, panX = (it.panX + panX).coerceIn(-limit, limit), panY = (it.panY + panY).coerceIn(-limit, limit))
    }

    fun resetWallpaperView() = updateWallpaper { it.copy(zoom = 1f, panX = 0f, panY = 0f) }

    /** Swipe left/right while editing steps through Natural, B&W, Duotone, Color Wash. */
    fun cycleFilter(direction: Int) = updateWallpaper {
        val all = WallpaperFilter.entries
        it.copy(filter = all[(it.filter.ordinal + direction + all.size) % all.size])
    }

    fun importWallpaper(uri: Uri) {
        viewModelScope.launch {
            val file = withContext(Dispatchers.IO) { WallpaperLoader.importFrom(getApplication(), uri) }
            val kind = pendingKind
            pendingKind = null
            if (kind != null) {
                createProfile(WallpaperConfig(file = file.absolutePath, extend = kind == NewKind.EXTENDED))
            } else {
                val profile = _ui.value.profile.let { p ->
                    p.copy(wallpaper = p.wallpaper.copy(file = file.absolutePath, kind = WallpaperKind.PHOTO, zoom = 1f, panX = 0f, panY = 0f))
                }
                _ui.update { it.copy(profile = profile, profiles = it.profiles.map { o -> if (o.id == profile.id) profile else o }) }
                loadAssets(profile)
            }
        }
    }

    // ---- widgets -------------------------------------------------------------------------------

    fun addWidget(type: WidgetType) {
        val s = _ui.value
        val size = type.sizes.firstOrNull { WidgetGrid.firstFree(s.profile.widgets, it, s.gridRows) != null }
        val spot = size?.let { WidgetGrid.firstFree(s.profile.widgets, it, s.gridRows) }
        if (size == null || spot == null) {
            _ui.update { it.copy(notice = "The widget rail is full. Remove or shrink a widget first.", sheet = Sheet.None) }
            return
        }
        val widget = WidgetConfig(type = type, size = size, col = spot.first, row = spot.second)
        updateProfile { it.copy(widgets = it.widgets + widget) }
        _ui.update { it.copy(sheet = Sheet.Widget(widget.id)) }
    }

    fun updateWidget(id: String, f: (WidgetConfig) -> WidgetConfig) =
        updateProfile { p -> p.copy(widgets = p.widgets.map { if (it.id == id) f(it) else it }) }

    fun moveWidget(id: String, col: Int, row: Int) = updateWidget(id) { it.copy(col = col, row = row) }

    fun resizeWidget(id: String, size: WidgetSize) {
        val s = _ui.value
        val w = s.profile.widgets.firstOrNull { it.id == id } ?: return
        if (WidgetGrid.fits(s.profile.widgets, id, size, w.col, w.row, s.gridRows)) {
            updateWidget(id) { it.copy(size = size) }
            return
        }
        val spot = WidgetGrid.firstFree(s.profile.widgets.filter { it.id != id }, size, s.gridRows)
        if (spot != null) updateWidget(id) { it.copy(size = size, col = spot.first, row = spot.second) }
        else _ui.update { it.copy(notice = "No room for that size on the rail.") }
    }

    fun deleteWidget(id: String) {
        updateProfile { p -> p.copy(widgets = p.widgets.filter { it.id != id }) }
        closeSheet()
    }

    fun addWidgetPhotos(id: String, uris: List<Uri>) {
        viewModelScope.launch {
            val files = withContext(Dispatchers.IO) {
                uris.mapNotNull { runCatching { WallpaperLoader.importFrom(getApplication(), it).absolutePath }.getOrNull() }
            }
            updateWidget(id) { it.copy(photos = (it.photos + files).takeLast(8)) }
        }
    }

    // ---- other surfaces ------------------------------------------------------------------------

    fun updateQuick(left: Boolean, f: (QuickActionConfig) -> QuickActionConfig) =
        updateProfile { if (left) it.copy(quickLeft = f(it.quickLeft)) else it.copy(quickRight = f(it.quickRight)) }

    fun updateMediaStyle(f: (GlassStyle) -> GlassStyle) = updateProfile { it.copy(mediaStyle = f(it.mediaStyle)) }
    fun setAlbumPlayerBlend(enabled: Boolean) = updateProfile { it.copy(albumPlayerBlend = enabled) }
    fun setAlbumArtworkStyle(style: com.glasslock.data.model.AlbumArtworkStyle) = updateProfile { it.copy(albumArtworkStyle = style) }
    fun setAlbumCoverPosition(position: com.glasslock.data.model.AlbumCoverPosition) = updateProfile { it.copy(albumCoverPosition = position) }
    fun setAlbumViewMode(mode: com.glasslock.data.model.AlbumViewMode) = updateProfile { it.copy(albumViewMode = mode) }
    fun setAlbumExpansionPath(path: String?) = updateProfile { it.copy(albumExpansionPath = path) }
    fun setNotificationLimit(limit: Int) = updateProfile { it.copy(notificationLimit = limit.coerceIn(1, 6)) }
    fun setAutoSceneByTime(enabled: Boolean) = updateProfile { it.copy(autoSceneByTime = enabled) }

    /** Apply a cohesive scene preset while preserving the user's wallpaper, widgets and custom labels. */
    fun applyScenePreset(preset: ScenePreset) = updateProfile { p ->
        when (preset) {
            ScenePreset.BALANCED -> p.copy(
                wallpaper = p.wallpaper.copy(dim = false, blur = false, atmosphereEnabled = false),
                clock = p.clock.copy(heightFraction = 0.38f, depthEffect = true),
                notificationLimit = 4,
                mediaStyle = p.mediaStyle.copy(mode = GlassMode.SOLID, opacity = 0.22f, rimStrength = 0.85f),
            )
            ScenePreset.FOCUS -> p.copy(
                wallpaper = p.wallpaper.copy(dim = true, blur = false, atmosphereEnabled = false),
                clock = p.clock.copy(heightFraction = 0.34f, depthEffect = true),
                notificationLimit = 2,
                mediaStyle = p.mediaStyle.copy(mode = GlassMode.SOLID, opacity = 0.18f, rimStrength = 0.65f),
            )
            ScenePreset.SLEEP -> p.copy(
                wallpaper = p.wallpaper.copy(dim = true, blur = false, atmosphereEnabled = false),
                clock = p.clock.copy(heightFraction = 0.24f, depthEffect = false),
                notificationLimit = 2,
                mediaStyle = p.mediaStyle.copy(mode = GlassMode.SOLID, opacity = 0.14f, rimStrength = 0.35f),
                notificationStyle = p.notificationStyle.copy(mode = GlassMode.SOLID, opacity = 0.16f, rimStrength = 0.35f),
                albumPlayerBlend = true,
            )
            ScenePreset.CINEMATIC -> p.copy(
                wallpaper = p.wallpaper.copy(dim = false, blur = false, atmosphereEnabled = true, atmosphereIntensity = 0.62f),
                clock = p.clock.copy(heightFraction = 0.43f, depthEffect = true),
                notificationLimit = 3,
                mediaStyle = p.mediaStyle.copy(mode = GlassMode.SOLID, opacity = 0.24f, rimStrength = 1.15f),
            )
        }
    }
    fun updateNotificationStyle(f: (GlassStyle) -> GlassStyle) = updateProfile { it.copy(notificationStyle = f(it.notificationStyle)) }
    fun updateTextStyle(f: (GlassStyle) -> GlassStyle) = updateProfile { it.copy(textStyle = f(it.textStyle)) }
    fun setStatusText(text: String) = updateProfile { it.copy(statusText = text) }
    fun setInlineText(text: String) = updateProfile { it.copy(inlineText = text) }
    fun dismissMedia(key: String) = _ui.update { it.copy(dismissedMediaKey = key) }


    /** A self-contained .glasslock bundle: profile JSON plus its optional photo wallpaper. */
    fun exportCurrentTheme(): ByteArray {
        val profile = _ui.value.profile
        val output = ByteArrayOutputStream()
        ZipOutputStream(output).use { zip ->
            zip.putNextEntry(ZipEntry("theme.json"))
            zip.write(ProfileThemeCodec.encode(profile).toByteArray(Charsets.UTF_8))
            zip.closeEntry()
            val image = profile.wallpaper.file?.let(::File)?.takeIf { it.isFile }
            if (image != null) {
                zip.putNextEntry(ZipEntry("wallpaper.bin"))
                image.inputStream().use { it.copyTo(zip) }
                zip.closeEntry()
            }
        }
        return output.toByteArray()
    }

    fun importTheme(bundle: ByteArray) {
        runCatching {
            require(bundle.size <= 40 * 1024 * 1024) { "Theme bundle is too large" }
            var json: String? = null
            var imageBytes: ByteArray? = null
            ZipInputStream(ByteArrayInputStream(bundle)).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    when (entry.name) {
                        "theme.json" -> json = zip.readBytes().toString(Charsets.UTF_8)
                        "wallpaper.bin" -> imageBytes = zip.readBytes().also { require(it.size <= 32 * 1024 * 1024) }
                    }
                    zip.closeEntry()
                }
            }
            val decoded = ProfileThemeCodec.decode(requireNotNull(json) { "Missing theme data" })
            var imported = decoded.copy(id = UUID.randomUUID().toString(), name = decoded.name.ifBlank { "Imported Scene" })
            imageBytes?.let { bytes ->
                val file = File(getApplication<Application>().filesDir, "theme_${imported.id}.jpg")
                file.writeBytes(bytes)
                imported = imported.copy(wallpaper = imported.wallpaper.copy(file = file.absolutePath))
            }
            imported
        }.onSuccess { imported ->
            val current = _ui.value
            val profiles = current.profiles + imported
            _ui.update { it.copy(profiles = profiles, profile = imported, galleryOpen = false, editing = false, notice = "Theme imported successfully.") }
            loadAssets(imported)
            loadThumbs()
            persist()
        }.onFailure {
            _ui.update { it.copy(notice = "That theme file could not be read.") }
        }
    }

    // ---- assets --------------------------------------------------------------------------------

    private fun loadAssets(profile: LockProfile) {
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            val wp = profile.wallpaper
            val file = wp.file?.let(::File)?.takeIf { it.exists() }
            val (background, cutout) = withContext(Dispatchers.Default) {
                when {
                    wp.kind != WallpaperKind.PHOTO -> WallpaperFactory.create(wp) to null
                    file == null -> DemoWallpaper.create()
                    else -> WallpaperLoader.decode(file) to cutouts.cached(file)
                }
            }
            val palette = withContext(Dispatchers.Default) { WallpaperPalette.from(background) }
            sourceBitmap = background
            _ui.update {
                it.copy(wallpaper = background.asImageBitmap(), cutout = cutout?.asImageBitmap(), palette = palette, segmenting = false)
            }
            if (file != null && wp.kind == WallpaperKind.PHOTO && cutout == null && profile.clock.depthEffect) ensureCutout()
        }
    }

    /** Runs ML Kit once per photo; the result is cached on disk. */
    private fun ensureCutout() {
        val state = _ui.value
        val file = state.profile.wallpaper.file?.let(::File)?.takeIf { it.exists() } ?: return
        val source = sourceBitmap ?: return
        if (state.cutout != null || state.segmenting) return
        _ui.update { it.copy(segmenting = true) }
        viewModelScope.launch {
            val cut = cutouts.generate(file, source)
            _ui.update { it.copy(segmenting = false, cutout = cut?.asImageBitmap()) }
        }
    }
}
