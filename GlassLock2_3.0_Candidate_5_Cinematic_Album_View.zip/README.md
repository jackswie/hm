# GlassLock2 3.0 — Final Candidate 3

This package continues from the 3.0 optical-modes + reference photo-picker source.

## Included
- Live / Reference / Hybrid optical modes wired into the AGSL glass sampling path.
- Per-style reference image selection via Android document picker; images are copied to app-private storage.
- Per-surface glass settings for clock, widgets, media and notifications.
- Dedicated text material settings for the focus/status pill, including optical source and refraction controls.
- Reduced-motion handling for album cover scaling and player/notification entrances. Existing wallpaper reduced-motion option controls this behavior.
- Local album Smart Expansion remains on-device and does not require AI services.
- CENTER and LEFT album layouts remain available.

## Important limitations
- AI outpainting was intentionally removed from scope.
- Reference images are sampled as a source texture by the shader; they are not a full scene-aware 3D reconstruction.
- Hybrid blends the live backdrop and selected reference source evenly.
- Android build and device validation are still required. ZIP/XML checks are not a substitute for Gradle compilation or testing on the Lenovo tablet.


### Reference background composition (stability update)

- Reference mode now uses the selected image as the exclusive full-screen scene source; the live wallpaper and ambient atmosphere are not drawn underneath it.
- The full-screen cropped reference is captured once by the shared glass backdrop. Clock, media, notification, and widget surfaces sample that same captured scene and apply their own local shape masks.
- Reference mode bypasses the device-sensitive AGSL/RenderEffect pass that could produce black patches on some GPUs; it keeps the real reference pixels, shape clipping, tint, and rim. Live mode retains the normal optical path. Hybrid mode remains an intentional 50/50 reference/live composite.


## Album atmosphere follow-up (build 44)

- Continues the `3.0-final-candidate-3` version line and preserves the working reference-scene composition.
- The album player continues to generate its local blurred atmosphere from the current track artwork; no Apple Music dependency or Gemini service is required.
- Album editing now exposes **Remove expansion · Use original album art** whenever a custom imported expansion is active.
- Removing an expansion clears the saved profile path and deletes the app-managed copied expansion file. The next album backdrop is regenerated from the current track artwork.
- Apple Music APK inspection was used only to study the visual approach (artwork processing, blur and palette handling); no proprietary code or assets were copied.


## Candidate 4 — Album Atmosphere + Reference Optics

- Album atmosphere is generated entirely on-device from the current media artwork. The compact blur source was increased in resolution for large tablet screens, with a two-pass soft blur, restrained saturation, palette-derived colour blooms, and a lower-screen contrast veil. Processing remains off the UI thread and the existing in-memory cache is retained.
- Album mode now explicitly disables the independent glass-reference scene override while the player is open. The album atmosphere remains the scene source, so choosing a glass reference cannot replace or erase the album background.
- Reference-only glass now enters the same guarded, low-opacity optical pass as Live glass. The clean reference scene is drawn first and remains underneath as a fallback; the optical layer is only an overlay. This restores real AGSL edge displacement and chromatic separation when the device GPU supports it.
- The Apple Music v7 APK was inspected as a visual/structural reference. Its player resources show separate artwork/player presentation layers and transition containers; GlassLock recreates the visual approach natively and does not copy Apple code, assets, or depend on Apple Music.
- Album editor retains the Remove expansion / Use original album art action from build 44.

## Validation

- Source archive root layout checked; Gradle project files are at the archive root.
- ZIP integrity and XML resource parsing checked.
- Android/Compose compilation and on-device GPU rendering were not available in this environment; run the existing GitHub Actions workflow and test Reference mode on the Lenovo tablet before treating the optical pass as device-validated.

## Candidate 5 — Optional Cinematic Album View

- Adds a persistent **Classic / Cinematic** album-view selector in the Now Playing editor. Classic remains the default, so existing Center and Left layouts are unchanged for existing profiles.
- Cinematic view uses an artwork-left / lyrics-right tablet composition with the date and clock centered above, compact playback controls below the artwork, and notifications along the bottom when present.
- The sharp cover is layered over an enlarged blurred copy; its right edge is alpha-feathered into the ambient artwork layer to soften the square boundary.
- Track changes use a soft crossfade/scale transition. The enlarged artwork atmosphere has a very slow, low-amplitude drift while playback is active; it settles to a smaller drift when paused.
- Existing Vinyl artwork style remains supported in Cinematic view.
- The Apple Music APK was inspected as a reference, but its internal artwork/player transitions are not exposed as a public background or animation API. GlassLock implements its own native motion and does not depend on Apple Music being installed.

## Candidate 5 validation

- Version: `3.0-final-candidate-5` (versionCode 46).
- New profile field defaults to `CLASSIC`, preserving previously saved profile behavior.
- ZIP integrity, root Gradle layout, and XML parsing checked. Android/Compose compilation and device rendering still require the existing GitHub Actions workflow and Lenovo tablet test.
