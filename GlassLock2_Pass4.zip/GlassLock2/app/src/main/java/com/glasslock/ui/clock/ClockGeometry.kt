package com.glasslock.ui.clock

import android.content.Context
import android.graphics.CornerPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asComposePath
import androidx.compose.ui.platform.LocalContext
import com.glasslock.data.model.ClockConfig
import com.glasslock.data.model.ClockFontId
import com.glasslock.data.model.NumeralScript
import kotlin.math.max
import kotlin.math.min
import android.graphics.Path as AndroidPath

/** Clock outline in box-local pixels, plus the horizontal extent the digits really occupy. */
class ClockPaths(val path: Path, val left: Float, val right: Float)

/**
 * Turns "19:59" into one outline, stretched independently in X and Y so the box height alone
 * controls how tall the digits are (the iPadOS 26 giant-clock behaviour). Digits are laid out in
 * equal-width cells so the clock does not jiggle as minutes change; the colon is two dots.
 */
class ClockGlyphSetup private constructor(
    private val paint: Paint,
    private val spec: ClockFontSpec,
    private val script: NumeralScript,
    private val weight: Int,
    private val top: Float,
    private val bottom: Float,
    private val cell: Float,
) {
    private val roundPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    fun layout(text: String, boxW: Float, boxH: Float): ClockPaths {
        val refH = max(bottom - top, 1f)
        val gap = cell * 0.10f
        val colonW = cell * 0.34f
        var refW = 0f
        text.forEachIndexed { i, ch ->
            refW += if (ch == ':') colonW else cell
            if (i < text.lastIndex) refW += gap
        }
        // Fit the complete glyph run uniformly inside the independently resizable canvas.
        // This keeps numerals optically correct even when the user makes the clock very narrow.
        val scale = min(boxW / refW, boxH / refH)
        val sx = scale
        val sy = scale
        val drawW = refW * scale
        val drawH = refH * scale
        val left = (boxW - drawW) / 2f
        val topOffset = (boxH - drawH) / 2f

        val out = AndroidPath()
        val tmp = AndroidPath()
        val matrix = Matrix()
        val bounds = RectF()
        var x = left
        for (ch in text) {
            if (ch == ':') {
                val stem = ((weight - 100) / 800f).coerceIn(0f, 1f)
                val d = cell * sx * (0.17f + 0.20f * stem)
                val cx = x + colonW * sx / 2f
                out.addCircle(cx, topOffset + drawH * 0.36f, d / 2f, AndroidPath.Direction.CW)
                out.addCircle(cx, topOffset + drawH * 0.64f, d / 2f, AndroidPath.Direction.CW)
                x += (colonW + gap) * sx
            } else {
                val s = script.digits[ch - '0'].toString()
                tmp.reset()
                paint.getTextPath(s, 0, s.length, 0f, 0f, tmp)
                tmp.computeBounds(bounds, true)
                matrix.reset()
                matrix.postTranslate(-(bounds.left + bounds.right) / 2f, -top)
                matrix.postScale(sx, sy)
                matrix.postTranslate(x + cell * sx / 2f, topOffset)
                tmp.transform(matrix)
                out.addPath(applyEffect(tmp, boxH))
                x += (cell + gap) * sx
            }
        }
        return ClockPaths(out.asComposePath(), left, left + drawW)
    }

    private fun applyEffect(src: AndroidPath, boxH: Float): AndroidPath = when (spec.effect) {
        GlyphEffect.NONE -> src
        GlyphEffect.ROUND -> AndroidPath().also {
            roundPaint.style = Paint.Style.FILL
            roundPaint.pathEffect = CornerPathEffect(boxH * 0.02f)
            roundPaint.getFillPath(src, it)
        }
        GlyphEffect.STENCIL -> cutGaps(src, floatArrayOf(0.5f), boxH * 0.02f)
        GlyphEffect.RAILS -> cutGaps(src, floatArrayOf(0.25f, 0.5f, 0.75f), boxH * 0.012f)
    }

    private fun cutGaps(src: AndroidPath, fractions: FloatArray, thickness: Float): AndroidPath {
        val b = RectF()
        src.computeBounds(b, true)
        val result = AndroidPath(src)
        val bar = AndroidPath()
        for (f in fractions) {
            bar.reset()
            val y = b.top + b.height() * f
            bar.addRect(b.left - 2f, y - thickness / 2f, b.right + 2f, y + thickness / 2f, AndroidPath.Direction.CW)
            result.op(bar, AndroidPath.Op.DIFFERENCE)
        }
        return result
    }

    companion object {
        private const val REF_SIZE = 200f

        fun create(context: Context, font: ClockFontId, weight: Int, script: NumeralScript): ClockGlyphSetup {
            val spec = ClockFonts.spec(font)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = REF_SIZE
                typeface = ClockTypefaces.create(context, spec, weight)
            }
            // No-op on non-variable fonts; picks the exact weight on variable ones.
            paint.setFontVariationSettings(ClockFonts.variations(spec, weight))

            // Measure all ten digits once so every digit shares one top/bottom/cell width.
            var top = Float.MAX_VALUE
            var bottom = -Float.MAX_VALUE
            var cell = 0f
            val p = AndroidPath()
            val b = RectF()
            for (ch in script.digits) {
                p.reset()
                paint.getTextPath(ch.toString(), 0, 1, 0f, 0f, p)
                p.computeBounds(b, true)
                top = min(top, b.top)
                bottom = max(bottom, b.bottom)
                cell = max(cell, b.width())
            }
            return ClockGlyphSetup(paint, spec, script, weight, top, bottom, max(cell, 1f))
        }
    }
}

@Composable
fun rememberClockPaths(config: ClockConfig, text: String, boxW: Float, boxH: Float): ClockPaths {
    val context = LocalContext.current.applicationContext
    val setup = remember(config.font, config.weight, config.script) {
        ClockGlyphSetup.create(context, config.font, config.weight, config.script)
    }
    return remember(setup, text, boxW, boxH) { setup.layout(text, boxW, boxH) }
}
