# GlassLock 2: Passes 1-3

Open the `GlassLock2` folder in Android Studio, let Gradle sync, run on a tablet or emulator (API 31+; refraction needs API 33+).
Long-press the screen to customise. Tap the clock for the popover, drag the corner handle to resize, "Photo" picks a wallpaper.

## Layout
    data/model   Models.kt (GlassStyle, ClockConfig, LockProfile...), ProfileStore.kt (DataStore + JSON)
    ui/glass     Agsl.kt (shaders) GlassBackdrop.kt (wallpaper capture) LiquidGlass.kt (the modifier)
                 TiltSensor.kt  WallpaperPalette.kt
    ui/clock     ClockFonts / ClockGeometry (digit outlines) / DepthLockScene (3 layers) / SubjectSegmenter (ML Kit) / Wallpaper
    ui/editor    EditorScreen, ClockPopover, GlassControls, ColorPicker, EditorViewModel
    ui/widgets   DateHeader, StatusPill, HomeIndicator (Pass 2 adds the widget grid + media player here)

## How the glass works
1. The wallpaper is recorded into one GraphicsLayer (`glassSource`).
2. Each glass surface redraws a shifted copy of it into its own padded layer.
3. RenderEffect chain on that layer: AGSL edge refraction + chromatic dispersion, then blur.
4. Compose draws saturation, frost, tint, a soft sheen and a 1dp inner rim (white 35% -> 5%) whose light direction follows accelerometer tilt.
   Tilt never re-runs the shaders; the blurred copy is cached until size, position or style changes.
Intensity 0% = nearly clear, strong refraction, bright rim. 100% = ~38dp blur, 26% frost, refraction hidden.
Clock digits use the MASK shader (edge normals estimated from a coverage mask); cards and pills use the exact rounded-rect SDF shader.
On API 31-32 the refraction step is skipped and blur/frost/tint/rim still render.

## Known limits
- SF Pro / New York are Apple-licensed; see app/src/main/assets/fonts/README.txt for OFL substitutes.
- ML Kit Subject Segmentation is built for people and objects. A skyline may be cut out only partly; the pipeline accepts any
  alpha cutout, so a different model can be swapped into SubjectSegmenter.cutout().
- Tilt uses the accelerometer only (gives the same rim motion as gyro with less code).

## Pass 2 additions
- ui/widgets: WidgetGrid (2-column rail, snap-to-grid drag, collision checks), BuiltInWidgets (analog clock with sweeping seconds,
  battery, month calendar, weather + sun arc, flip digital clock, quote, photo carousel, app shortcut), QuickActions (two corner buttons), StatusBar.
  Portrait reflows the same widgets into one horizontal row under the clock.
- ui/media + service: MediaRepository mirrors the active MediaSession; MediaListenerService authorises it. NowPlayingCard has art,
  title/artist, animated bars, seek slider, prev/play/next, output switcher and swipe-to-dismiss (audio keeps playing).
- Editing: long-press -> tap any element to configure it. "+ Widget" adds, the sheet resizes/removes. Weather uses Open-Meteo + coarse location.
- First run: tap the "Show what's playing" card to enable notification access, and tap the weather widget to allow location.
- Notifications on the lock screen, the real lock-screen window/service and the wallpaper gallery are Pass 3.

## Pass 3 additions
- Real lock window: LockService (foreground, SCREEN_ON/OFF) shows LockActivity above the system keyguard. Swipe up from the bottom edge
  (with fade/shrink and spring-back) calls KeyguardManager.requestDismissKeyguard, so Android still checks PIN/biometrics.
- Notifications: MediaListenerService mirrors them into Liquid Glass cards, grouped per app with peeking stacks. Tap expands a stack or opens
  a card (after unlock); swipe sideways dismisses and clears it from the system shade. Secret notifications are hidden, private ones show only the app name.
- Gallery: long-press (in the app) opens a carousel of lock screens. "+" adds Photo / Weather / Astronomy / Emoji / Color Gradient / Extended Photo,
  swipe a card up to delete, "Focus" links an icon + label to that lock screen, "Customize" opens the editor.
- Wallpaper editing: two-finger pinch/pan, swipe left/right for Natural / B&W / Duotone / Color Wash, plus Dim, Blur and Extend toggles.
- Setup screen: overlay permission, notification access, service notice, location, battery exemption, and the on/off switch for the lock replacement.
- Album art: tap the cover on the Now Playing card to see it enlarged; tap anywhere to close.

## Setup on a device
1. Install and open the app; follow the setup screen (the first two steps are required).
2. Turn on "Use GlassLock as my lock screen", then lock the device.
Uninstall or turn the switch off to get the stock lock screen back. If something goes wrong, boot to safe mode or use adb: `adb shell am force-stop com.glasslock`.

## Honest limits
- Android has no supported lock-screen replacement API. This overlay sits above the real keyguard; Android 14+ background-start rules, OEM battery managers
  and vendor skins can stop it appearing. Test on your tablet before relying on it.
- Weather / Astronomy wallpapers are generated pictures, not live data. "Extended Photo" is a blurred fill, not generative outpainting.
- Focus only changes the label in the pill; it does not toggle Do Not Disturb.
- Tilt uses the accelerometer. Nothing here was compiled or run in the build sandbox.


## Pass 4: clock proportions and depth-stack repair
- Added independent clock-canvas width and height controls in the Clock sheet. The width is a percentage of the available hero area; the height remains a percentage of screen height.
- Clock glyphs now scale uniformly to fit the selected bounds instead of being squeezed horizontally when the width is reduced. This keeps the numeral proportions intact at compact sizes.
- The depth compositor is retained as a true three-layer scene (wallpaper, clock, foreground subject). In the editor, the Depth Effect switch remains live and the subject cutout is drawn above the clock when segmentation is available.
