package com.glasslock.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.material3.Text
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.glasslock.data.model.GlassAppearance
import com.glasslock.data.model.GlassMode
import com.glasslock.data.model.GlassOpticalMode
import com.glasslock.data.model.GlassStyle
import com.glasslock.ui.glass.GlassGeometry
import com.glasslock.ui.glass.Palette
import com.glasslock.ui.glass.liquidGlass
import com.glasslock.ui.theme.Ink
import kotlin.math.roundToInt

private val FrameStyle = GlassStyle(intensity = 0.85f, appearance = GlassAppearance.TINTED)

/** Floating glass popover used by every configurator. */
@Composable
fun SheetFrame(title: String, onDismiss: () -> Unit, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .widthIn(max = 400.dp)
            .fillMaxWidth()
            .liquidGlass(GlassGeometry.Rounded(32.dp), FrameStyle)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp, vertical = 18.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = Ink.primary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            GlassPill("Done", onDismiss)
        }
        content()
    }
}

/** Material section (Glass/Solid, intensity or opacity, Clear/Tinted, colour) shared by clock, widgets, media, buttons. */
@Composable
fun StyleControls(style: GlassStyle, palette: Palette, onChange: ((GlassStyle) -> GlassStyle) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val referencePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val savedPath = withContext(Dispatchers.IO) {
                runCatching {
                    val target = File(context.filesDir, "glass_reference_${System.currentTimeMillis()}.img")
                    context.contentResolver.openInputStream(uri).use { input ->
                        requireNotNull(input) { "Unable to read selected image" }.use { source ->
                            target.outputStream().use { output -> source.copyTo(output) }
                        }
                    }
                    target.absolutePath
                }.getOrNull()
            }
            if (savedPath != null) onChange { it.copy(referenceImagePath = savedPath) }
        }
    }
    SectionTitle("Quick material presets")
    Text("Reliable translucent materials that keep the wallpaper visible without depending on live refraction.", color = Ink.secondary, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
    ChipFlow(
        options = listOf("Crystal", "Soft", "Frosted", "Wallpaper Tint"),
        selected = "",
        onSelect = { preset ->
            onChange { current -> when (preset) {
                "Crystal" -> current.copy(mode = GlassMode.SOLID, solidColor = Color.White.toArgb(), opacity = 0.13f, appearance = GlassAppearance.CLEAR)
                "Soft" -> current.copy(mode = GlassMode.SOLID, solidColor = Color.White.toArgb(), opacity = 0.21f, appearance = GlassAppearance.CLEAR)
                "Frosted" -> current.copy(mode = GlassMode.SOLID, solidColor = Color.White.toArgb(), opacity = 0.34f, appearance = GlassAppearance.CLEAR)
                else -> current.copy(mode = GlassMode.SOLID, solidColor = palette.tint.toArgb(), opacity = 0.23f, appearance = GlassAppearance.TINTED)
            } }
        },
        label = { it },
    )
    SectionTitle("Custom material")
    Segmented(
        options = listOf(GlassMode.LIQUID to "Translucent", GlassMode.SOLID to "Solid"),
        selected = style.mode,
        onSelect = { m -> onChange { it.copy(mode = m) } },
    )
    if (style.mode == GlassMode.LIQUID) {
        Column(Modifier.padding(top = 12.dp)) {
            GlassSlider("Material softness", "${(style.intensity * 100).roundToInt()}%", style.intensity, 0f..1f) { v ->
                onChange { it.copy(intensity = v) }
            }
        }
        SectionTitle("Appearance")
        Segmented(
            options = listOf(GlassAppearance.CLEAR to "Clear", GlassAppearance.TINTED to "Tinted"),
            selected = style.appearance,
            onSelect = { a -> onChange { it.copy(appearance = a) } },
        )
        SectionTitle("Optical source")
        Segmented(
            options = listOf(
                GlassOpticalMode.LIVE to "Live",
                GlassOpticalMode.REFERENCE to "Reference",
                GlassOpticalMode.HYBRID to "Hybrid",
            ),
            selected = style.opticalMode,
            onSelect = { mode -> onChange { it.copy(opticalMode = mode) } },
        )
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(1f)) {
                Text("Reference image", color = Ink.primary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                Text(
                    style.referenceImagePath?.substringAfterLast('/') ?: "No image selected",
                    color = Ink.secondary, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            GlassPill("Choose photo", onClick = { referencePicker.launch(arrayOf("image/*")) })
        }
        if (style.referenceImagePath != null) {
            GlassPill("Remove reference", onClick = { onChange { it.copy(referenceImagePath = null) } })
        }
        Text("Reference mode samples this image; Hybrid blends it with the live wallpaper. Missing or unreadable images safely fall back to Live.", color = Ink.secondary, fontSize = 11.sp)
        SectionTitle("Optics")
        GlassSlider("Refraction", "${(style.refractionStrength * 100).roundToInt()}%", style.refractionStrength, 0f..2f) { v ->
            onChange { it.copy(refractionStrength = v) }
        }
        GlassSlider("Edge displacement", "${(style.edgeDisplacement * 100).roundToInt()}%", style.edgeDisplacement, 0.25f..2f) { v ->
            onChange { it.copy(edgeDisplacement = v) }
        }
        GlassSlider("Colour dispersion", "${(style.dispersionStrength * 100).roundToInt()}%", style.dispersionStrength, 0f..2f) { v ->
            onChange { it.copy(dispersionStrength = v) }
        }
        Text("Refraction and edge controls affect the optical sampling pass. Hybrid balances the live wallpaper and reference image.", color = Ink.secondary, fontSize = 11.sp)
    } else {
        Column(Modifier.padding(top = 12.dp)) {
            GlassSlider("Opacity", "${(style.opacity * 100).roundToInt()}%", style.opacity, 0.1f..1f) { v ->
                onChange { it.copy(opacity = v) }
            }
        }
    }
    Column(Modifier.padding(top = 10.dp)) {
        SectionTitle("Edge highlight")
        GlassSlider("Rim & top sheen", "${(style.rimStrength * 100).roundToInt()}%", style.rimStrength, 0f..1.6f) { v ->
            onChange { it.copy(rimStrength = v) }
        }
        Text("Controls the soft top reflection and outline. Set to zero for a flatter surface.", color = Ink.secondary, fontSize = 11.sp)
    }
    if (style.mode == GlassMode.SOLID || style.appearance == GlassAppearance.TINTED) {
        SectionTitle(if (style.mode == GlassMode.SOLID) "Color" else "Tint")
        val current = if (style.mode == GlassMode.SOLID) Color(style.solidColor) else style.tintColor?.let { Color(it) } ?: palette.tint
        ColorPickerSection(current, palette.swatches) { picked ->
            onChange { if (it.mode == GlassMode.SOLID) it.copy(solidColor = picked.toArgb()) else it.copy(tintColor = picked.toArgb()) }
        }
    }
}

@Composable
fun GlassTextField(label: String, value: String, singleLine: Boolean = true, onChange: (String) -> Unit) {
    Column(Modifier.padding(top = 10.dp)) {
        Text(label, color = Ink.secondary, fontSize = 12.sp, modifier = Modifier.padding(bottom = 4.dp))
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = singleLine,
            textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
            cursorBrush = SolidColor(Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = if (singleLine) 0.dp else 90.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color.White.copy(alpha = 0.14f))
                .padding(12.dp),
        )
    }
}
